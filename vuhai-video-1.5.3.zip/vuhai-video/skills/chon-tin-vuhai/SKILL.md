---
name: "chon-tin-vuhai"
description: "Cổng 1 của dây chuyền video: lấy tin ngành Fitness từ app SỨC BẬT, lọc theo độ nóng và độ hợp với chủ phòng gym, trình 5 tin ứng viên kèm nguồn và số liệu đã kiểm, rồi chờ Vũ Hải chốt một tin và đưa CTA. Dùng khi anh nói tìm tin hot, có tin gì mới, chọn tin làm video, chạy Cổng 1, hoặc đưa một brief đã chốt từ trang Cổng 1 trên điện thoại. Không dùng khi anh đã đưa sẵn nội dung và chỉ muốn dựng video, lúc đó vào thẳng remotion-video-vuhai."
---

# Cổng 1, chọn tin

Một video đi qua hai cổng Vũ Hải duyệt. Skill này là cổng thứ nhất. Cổng thứ hai là duyệt video xuất ra, nằm trong `remotion-video-vuhai`.

Giữa hai cổng, chạy liền mạch, không hỏi thêm. Chỉ dừng khi bị chặn thật: thiếu CTA, một con số không tìm được nguồn, hoặc máy lỗi. Lúc đó nói rõ chặn ở đâu.

## Đi tắt: anh Hải dán sẵn một brief

Trang Cổng 1 trên điện thoại xuất ra khối chữ bắt đầu bằng "CỔNG 1 ĐÃ CHỐT". Nhận được khối đó thì **bỏ qua bước 1 và 2**, vì tin đã chốt rồi. Vào thẳng bước 3 kiểm số liệu ở bài gốc, rồi sang `remotion-video-vuhai`.

## Bước 1, lấy tin

```
python3 tools/lay_tin.py                      # cả hai nguồn, cửa sổ 6 ngày
python3 tools/lay_tin.py --nguon vn --so 8    # chỉ tin Việt Nam
python3 tools/lay_tin.py --ngay 14            # tuần ít tin thì nới cửa sổ
```

Công cụ đọc hai file công khai của app SỨC BẬT, không cần xác thực, chạy được ở mọi máy. Nó xếp hạng rồi in ra ứng viên kèm điểm.

Cách chấm điểm, để biết mà đọc kết quả:

- **Tin Việt Nam:** mức app chấm (cao 40, vừa 20, thấp 5) cộng độ mới (hôm nay 20, mỗi ngày cũ trừ 3) cộng số báo cùng đưa (mỗi báo thêm 8, trần 30) cộng từ khóa vận hành (mỗi từ 6).
- **Tin Thế giới:** app chấm mức như nhau cho tất cả nên mức vô dụng. Chấm bằng từ khóa kinh doanh có trọng số (phá sản 14, đóng cửa 11, mua lại 11, giữ chân 11, nợ 10), trừ điểm tin thông cáo sản phẩm (tưởng niệm trừ 14, ra mắt trừ 8), cộng độ mới và số nguồn.

Điểm chỉ là gợi ý xếp thứ tự. Tin đầu bảng vẫn có thể mỏng, đọc rồi mới biết.

## Bước 2, kiểm số liệu ở bài gốc

**Bắt buộc, không được bỏ.** Với mỗi tin định trình, mở link gốc và rút ra mọi con số kèm tên báo và ngày đăng. Tóm tắt trong kho tin thường cụt hoặc là văn thông cáo.

- Link Google News là địa chỉ chuyển tiếp chạy bằng JavaScript, tải thẳng sẽ ra trang trắng. Tìm bài thật bằng cách tra tên báo cộng tiêu đề.
- Tin pháp lý và thuế phải đối chiếu văn bản gốc, không tin bài báo tóm tắt lại. Chưa đối chiếu được thì nói rõ, và nếu vẫn chọn tin đó thì bỏ hẳn phần điều khoản ra khỏi video.
- Số nào không tìm được nguồn thì bỏ, đừng ước chừng.

## Bước 3, trình 5 tin ứng viên

Mỗi tin một khối, đủ năm dòng:

1. **Tiêu đề.**
2. **Nguồn và ngày.** Nhiều báo cùng đưa thì kể hết, vì đó là dấu hiệu nóng thật.
3. **Vì sao hot.** Dựa trên số báo cùng đưa, tốc độ của con số, hoặc chỗ tin này lật một điều người trong ngành đang tin.
4. **Chạm nỗi đau nào ở mức NẶNG.** Nỗi đau của chân dung, không phải của người trong tin. Chủ một phòng sợ hệ thống hỏng mà không biết hỏng ở đâu; chủ chuỗi sợ mỗi cơ sở một kiểu; quản lý cấp trung sợ không biết nói gì với nhân viên.
5. **Góc video đề xuất.** Một câu. Góc tốt là góc kéo tin của người khác về thành thước đo cho phòng của người xem.

Kèm con số đã kiểm ở bước 2, giữ nguyên từng chữ cùng tên báo và ngày.

Tin thế giới thì ghi rõ bài gốc tiếng Anh, và góc video phải kéo được về bối cảnh phòng tập Việt Nam, nếu không thì đừng trình.

## Bước 4, chờ Vũ Hải chốt

Anh chọn một tin, hoặc sửa góc. Rồi anh đưa CTA gồm bốn phần: làm gì (đúng **một** việc), ở đâu, nhận được gì (món cho trước có thật), hạn (chỉ khi là hạn thật).

Luật về CTA, lặp lại từ `remotion-video-vuhai` vì đây là chỗ hay hỏng:

- **Không tự bịa CTA.** Không tự nghĩ ưu đãi, tên tài liệu, số chỗ hay hạn chót.
- **Thiếu CTA thì dùng CTA trung tính** và nói rõ ở đầu bài giao, rồi đề nghị dựng lại cảnh cuối khi anh gửi CTA thật.
- **"Làm gì" phải là một việc.** "Lưu video rồi tối nay mở sổ" là hai việc và bị trừ điểm nặng ở khâu chấm.
- CTA không có hành động liên hệ thì cảnh cuối bỏ khối liên hệ 5 thông tin, chỉ giữ chữ ký.

Chưa chốt xong cổng này thì chưa viết kịch bản.

## Bước 5, giao sang dựng video

Lập `facts.md` từ số liệu đã kiểm ở bước 2, mỗi dòng một con số kèm link nguồn và ngày lấy. Ghi luôn danh sách thứ cố ý không đưa vào video và lý do.

Rồi chạy `remotion-video-vuhai` từ bước 1 của skill đó, mang theo tin đã chốt, CTA, khung hình và độ dài.

## Nguồn tin

App SỨC BẬT quét 7 giờ sáng mỗi ngày rồi xuất hai file công khai:

| File | Nội dung |
|---|---|
| `du-lieu/tin-cong-khai.json` | tin trong nước, có mức app chấm và dòng "vì sao đáng đọc" |
| `du-lieu/tin-the-gioi.json` | tin ngành quốc tế từ Athletech News, Health Club Management, Fitt Insider, Club Solutions, IHRSA, Global Wellness Institute |

Cả hai đều ở `https://suc-bat.netlify.app/`. Không file nào chứa Góc nhìn H-OE.
