# Bước 5, duyệt, render, giao (đọc khi chuẩn bị giao)

## Thứ tự
1. **Chạy `tools/verify.py out/<tên>.mp4`.** Script kiểm bằng máy mọi thứ đo được: khung hình, thời lượng, có tiếng, độ lớn và đỉnh, giọng đọc ở mọi cảnh, đuôi giọng không bị cắt, khung 0 là banner, cảnh CTA đứng đủ 6 giây, khung đen và đứng hình, đệm chữ trong thẻ, chữ tối trên nền đỏ và chữ đỏ trên nền tối, mascot không lặp tư thế và không quá một nửa số cảnh, từ cấm và gạch dài, CTA đúng nguyên văn. Còn lỗi P0 thì sửa và chạy lại, chưa được gọi người chấm. Nó cũng tạo `out/contact.png` và `out/phone.png`.
2. **Tự soi ba ảnh** (contact sheet, ảnh điện thoại, cảnh CTA cuối) từ chính file MP4. Câu hỏi tự phê: khung này có đáng đăng làm ảnh tĩnh không, có cảnh nào chỉ là chữ trượt trên nền không, có đoạn nào đứng yên quá 2 giây không, chữ có đọc kịp không, các cảnh có nối logic không.
3. **Người chấm độc lập** (agent chỉ đọc, chưa thấy quá trình làm). Chỉ đưa cho nó `contact.png`, `phone.png`, `verify.json`, `vo.json`, `cta.json` và bảng tiêu chí dưới đây, không cho nó tự trích khung. Dùng mô hình nhỏ. Các video cùng một khuôn: chấm đầy đủ video đầu; video sau chỉ chấm các cảnh khác khuôn, cộng ảnh bìa, hook và CTA của từng video.
4. Sửa, chỉ dựng lại cảnh bị ảnh hưởng (`make_video.py ... --scenes sK --force`), chấm lại phần đó. Không đụng cảnh đã từ 9 điểm.
5. **Giao một lần** khi đã qua `verify.py` và người chấm. Không gửi từng vòng nháp, trừ khi anh Hải muốn xem sớm.

## Bảng tiêu chí cho người chấm (phần cần mắt)
Chấm 1 đến 10, mọi điểm phải từ 8 trở lên: hook trong 2 giây đầu; dễ đọc ở chiều rộng 360px; chất lượng chuyển động; độ đa dạng (có thứ mới sau mỗi 2 đến 4 giây); bố cục (không dồn lên trên, không nửa khung trống); đúng dữ liệu và nguồn; khớp âm thanh; giữ chân (khoảng trống mở sớm, đóng ở cuối, có điều mới mỗi 8 đến 10 giây, điều đáng giá nhất nằm cuối); CTA (đúng một bước, đúng nguyên văn anh Hải đưa, có món cho trước, không bịa khan hiếm). Nêu tối đa 3 lỗi nặng nhất kèm mốc giờ, mức P0, P1, P2. Một agent khác kể lại thông điệp chỉ từ các khung hình và nêu người xem cần làm gì ở cuối; kể không được thì video chưa đạt.
Lưu ý: người chấm có thể sai (đã có lần báo lỗi chính tả không có thật). Mọi lỗi nó nêu phải đối chiếu với MP4 hoặc nguồn trước khi sửa. Máy chưa có agent riêng thì ghi rõ khi giao là chưa chấm độc lập.

## Render
Máy 2 nhân, không GPU. Chụp JPEG chất lượng 95, 2 tiến trình. Chạy ở nền (`nohup`) rồi đọc log, mỗi lần chờ dưới 120 giây. Việc nặng xếp hàng qua `flock /tmp/render.lock` (`make_video.py` làm sẵn), chạy nhiều agent song song không làm render nhanh hơn. Ghép MP4 bằng `tools/mux.py` (thay khung 0 bằng banner trong cùng một lượt mã hóa, cắt đúng độ dài video). Công cụ gửi file giới hạn 30 MB: lớn hơn thì nén `-crf 24`.

## Banner (thumbnail)
`tools/banner.py` đọc `banner.json` và dựng `banner.png` 1920x1080. **Chỉ có đúng ba mẫu** (từ 1.3.5), đều khớp design system Vũ Hải:
- **A giant-lon**: tấm đỏ chứa tiêu đề 2 dòng, mascot lớn đứng ngoài đè lên mép tấm đỏ. Khẳng định mạnh.
- **B giant-ngang** (mặc định): tấm đỏ chạy hết chiều ngang, mascot nhỏ ở góc phải dưới.
- **C giant-dai**: tiêu đề mực trên nền kem, dải đỏ ở đáy chứa số liệu, mascot nhỏ đứng trên dải đỏ. Hợp câu hỏi, chủ đề ngắn.
Quy tắc cứng: có mascot nền trong suốt khớp thông điệp, không che chữ; ĐÚNG MỘT thông điệp chính cỡ lớn (tối đa 2 dòng, in hoa, tối đa 5 từ); ĐÚNG MỘT hook (một câu dưới 15 từ); thêm được nhãn nhỏ `label` (ví dụ "Buổi 1 · Video 3") và tối đa 3 số liệu `stats` lấy từ nguồn của video, không thêm gì khác (không liên hệ, CTA). Chữ trên nền đỏ luôn trắng. Tiêu đề giãn dòng từ 1,04 để dấu tiếng Việt không chạm dòng trên. Xem ảnh thật. Video dọc 9:16: banner 16:9 được `mux.py` đặt giữa nền kem, không kéo méo.

## Share copy
`share-copy.txt`: 1 đến 3 câu, đăng được ngay, đúng giọng anh Hải, lặp đúng CTA của anh (cùng hành động, cùng nơi làm). Đúng sự thật, không ghi "làm trong 10 phút" nếu thực tế nhiều vòng sửa.

## Lưu và giao
- Lưu vào thư mục dự án trên máy anh: `video\<ngày>-<tên-video>\` gồm MP4, banner.png, share-copy.txt, hook-options.md, nguon (không kèm khung hình). Không nối được thư mục thì gửi file qua chat và nói rõ chưa lưu được.
- Gửi MP4 bằng SendUserFile, nói thời lượng chính xác. Ghi kèm: kiểu kịch bản và lý do, xung đột, hook đã chọn và hai hook dự phòng, thông điệp và hook của banner, CTA nguyên văn và hai vị trí đặt CTA, cảnh nào có mascot, các quyết định tự chọn (giọng, tốc độ), và những gì chưa làm (chưa nghe thử bằng tai, chưa chấm độc lập, CTA trung tính nếu chưa có CTA thật).
- Thêm một dòng vào `video-output/INDEX.md` (tên, ngày, thời lượng, khung hình, giọng, kiểu kịch bản, hook, CTA, một dòng bài học). Video sau bắt đầu bằng việc đọc `INDEX.md` và lấy `scenes.py` gần nhất làm khuôn.
- Hàng đợi artifact: đặt status `chay` khi bắt đầu, `xong` kèm `report`, hoặc `loi` kèm lý do. Trước khi làm, chạy `tools/dupcheck.py` để loại việc trùng nội dung.


## Khung mẫu và dải ảnh (v1.5)
- Trước khi render cả video: `python3 tools/make_video.py mau`. Ra `out/khung-mau.png` gồm 3 khung (hook, cảnh đáng nhớ nhất, CTA). Chọn cảnh bằng `video.json` `"mau"`. Gửi anh Hải duyệt, sửa xong mới chạy cả chuỗi.
- Sau verify: `strip.py` lấy khung cách nhau 0,2 giây từ chính MP4 quanh mỗi chỗ chuyển cảnh và mỗi lần mascot vào (`out/strip.png`). Xem ảnh này để soi chuyển động, không đoán từ code.
- Thời gian giữ chữ: mỗi thẻ cần ký tự chia `toc_do_doc` (mặc định 15) cộng `giu_chu_nen` (mặc định 1,5) giây. Con số 15 là mức tiếng Anh của lemo-opuscar, chưa đo cho tiếng Việt. Vi phạm là P1, xử lý bằng `fixed`, `khoang_lang` hoặc rút chữ.
