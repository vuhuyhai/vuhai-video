#!/usr/bin/env python3
"""Lấy tin ngành Fitness từ app SỨC BẬT rồi xếp hạng, phục vụ Cổng 1 của skill chon-tin-vuhai.

Đọc hai file công khai, không cần xác thực, nên chạy được ở bất cứ đâu:
  tin trong nước  https://suc-bat.netlify.app/du-lieu/tin-cong-khai.json
  tin thế giới    https://suc-bat.netlify.app/du-lieu/tin-the-gioi.json

Dùng:
  python3 tools/lay_tin.py                      # cả hai nguồn, cửa sổ 6 ngày, 5 ứng viên mỗi nguồn
  python3 tools/lay_tin.py --nguon vn --so 8    # chỉ tin Việt Nam, 8 ứng viên
  python3 tools/lay_tin.py --ngay 14            # nới cửa sổ khi tuần ít tin
  python3 tools/lay_tin.py --json ung-vien.json # ghi thêm ra file để đọc lại

Chỉ dùng thư viện chuẩn của Python.
"""
import argparse
import json
import re
import sys
import unicodedata
import urllib.request
from datetime import datetime, timedelta

URL_VN = "https://suc-bat.netlify.app/du-lieu/tin-cong-khai.json"
URL_TG = "https://suc-bat.netlify.app/du-lieu/tin-the-gioi.json"

# Tin Việt Nam: app đã chấm mức, nên mức là tín hiệu chính.
DIEM_IMP = {"cao": 40, "vua": 20, "thap": 5}
KHOA_VN = ["đóng cửa", "tái cấu trúc", "phá sản", "nợ bảo hiểm", "hội viên", "hợp đồng",
           "trả góp", "nhượng quyền", "chuỗi phòng tập", "chuỗi", "mặt bằng", "thuê",
           "nhân sự", "doanh thu", "lỗ", "vốn", "thị trường", "giá", "thuế", "quy định",
           "nghị định"]

# Tin Thế giới: app chấm mức "vừa" cho tất cả nên mức vô dụng.
# Phải chấm bằng từ khóa kinh doanh, và trừ điểm tin thông cáo sản phẩm.
KHOA_TG = [("bankruptcy", 14), ("chapter 11", 14), ("insolvency", 14), ("administration", 10),
           ("closes", 11), ("closure", 11), ("shuts", 11), ("shut", 9), ("acquire", 11),
           ("acquires", 11), ("acquisition", 11), ("merger", 10), ("buys", 9), ("sells", 9),
           ("stake", 8), ("private equity", 10), ("funding", 8), ("raises", 8), ("investment", 8),
           ("layoff", 11), ("layoffs", 11), ("debt", 10), ("lease", 10), ("landlord", 9),
           ("rent", 8), ("franchise", 9), ("franchisee", 9), ("membership", 9), ("memberships", 9),
           ("members", 6), ("retention", 11), ("churn", 11), ("attrition", 10), ("pricing", 9),
           ("revenue", 9), ("margin", 8), ("profit", 8), ("loss", 8), ("expansion", 7),
           ("expands", 7), ("chain", 7), ("chains", 7), ("operator", 7), ("operators", 7),
           ("consolidation", 9), ("report", 6), ("survey", 6), ("trends", 5)]
PHAT_TG = [("remembered", -14), ("obituary", -14), ("partners", -10), ("partnership", -9),
           ("launches", -8), ("unveils", -8), ("introduces", -8), ("best inventions", -12),
           ("joins", -7), ("supplement", -9), ("supplements", -9), ("protein", -9),
           ("recipe", -10), ("peptide", -6), ("peptides", -6)]

# Feed FitTechGlobal có lúc trả nguyên trang tìm kiếm lỗi, hàng chục bản giống nhau.
RAC = [re.compile(r"searcj results", re.I), re.compile(r"^fit tech:\s*$", re.I)]


def tai(url):
    with urllib.request.urlopen(url, timeout=30) as r:
        return json.loads(r.read().decode("utf-8"))


def thuong(s):
    return (s or "").lower()


def khong_dau(s):
    return "".join(c for c in unicodedata.normalize("NFD", thuong(s))
                   if unicodedata.category(c) != "Mn")


def cum(t):
    """Khóa gộp tin trùng chủ đề: 6 từ dài đầu tiên của tiêu đề, bỏ dấu."""
    tu = re.sub(r"[^a-z0-9\s]", " ", khong_dau(t)).split()
    return " ".join([w for w in tu if len(w) > 3][:6])


def la_rac(x):
    t = (x.get("t") or "").strip()
    return len(t) < 15 or any(r.search(t) for r in RAC)


def tron_tu(vb, k):
    # Khớp trọn từ. Khớp chuỗi con làm "rent" trúng trong "Parent", đã dính thật.
    return re.search(r"\b" + re.escape(k) + r"\b", vb) is not None


def xep_hang(tin, nguon, ngay, so):
    tin = [x for x in tin if not la_rac(x)]
    if not tin:
        return []
    moi_nhat = max(x["d"] for x in tin)
    neo = datetime.strptime(moi_nhat, "%Y-%m-%d")
    moc = (neo - timedelta(days=ngay - 1)).strftime("%Y-%m-%d")

    nhom = {}
    for x in tin:
        if x["d"] < moc:
            continue
        cach = (neo - datetime.strptime(x["d"], "%Y-%m-%d")).days
        trung = []
        if nguon == "vn":
            vb = thuong(x["t"] + " " + (x.get("s") or "") + " " + " ".join(x.get("khoa") or []))
            trung = [k for k in KHOA_VN if k in vb]
            diem = DIEM_IMP.get(x.get("imp"), 0) + max(0, 20 - cach * 3) + len(trung) * 6
        else:
            vb = thuong(x["t"] + " " + (x.get("s") or ""))
            diem = 0
            for k, w in KHOA_TG:
                if tron_tu(vb, k):
                    diem += w
                    trung.append(k)
            for k, w in PHAT_TG:
                if tron_tu(vb, k):
                    diem += w
            diem += max(0, 14 - cach * 4)

        k = cum(x["t"])
        g = nhom.get(k)
        if g is None:
            nhom[k] = {"tin": x, "diem": diem, "khoa_hop": trung, "bao": [x["src"]]}
        else:
            if x["src"] not in g["bao"]:
                g["bao"].append(x["src"])
            if diem > g["diem"]:
                g.update({"tin": x, "diem": diem, "khoa_hop": trung})

    # Nhiều nguồn cùng đưa một tin trong một ngày là dấu hiệu nóng thật.
    tran = 30 if nguon == "vn" else 20
    for g in nhom.values():
        g["diem"] += min(tran, (len(g["bao"]) - 1) * 8)
    return sorted(nhom.values(), key=lambda g: -g["diem"])[:so]


def ngay_vn(d):
    p = d.split("-")
    return f"{p[2]}/{p[1]}/{p[0]}"


def in_nhom(nhan, ds):
    print(f"\n== {nhan} ==")
    if not ds:
        print("  (không có tin nào trong cửa sổ này)")
        return
    for i, g in enumerate(ds, 1):
        x = g["tin"]
        print(f"[{g['diem']}] Tin {i}. {x['t']}")
        print(f"    nguồn: {', '.join(g['bao'])} | ngày {ngay_vn(x['d'])} | mức {x.get('imp')}")
        if x.get("s"):
            print(f"    tóm tắt: {x['s'][:200]}")
        if x.get("w"):
            print(f"    app ghi: {x['w'][:200]}")
        if g["khoa_hop"]:
            print(f"    khóa hợp: {', '.join(g['khoa_hop'][:8])}")
        print(f"    {x['u']}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--nguon", choices=["vn", "tg", "ca"], default="ca")
    ap.add_argument("--ngay", type=int, default=6, help="cửa sổ thời gian, mặc định 6")
    ap.add_argument("--so", type=int, default=5, help="số ứng viên mỗi nguồn, mặc định 5")
    ap.add_argument("--json", metavar="FILE", help="ghi thêm kết quả ra file JSON")
    a = ap.parse_args()

    ra = {"lay_luc": datetime.now().isoformat(timespec="seconds"), "cua_so_ngay": a.ngay}
    try:
        if a.nguon in ("vn", "ca"):
            kho = tai(URL_VN)
            ra["kho_cap_nhat_luc"] = kho.get("capNhatLuc")
            ra["ung_vien_viet_nam"] = xep_hang(kho["tin"], "vn", a.ngay, a.so)
        if a.nguon in ("tg", "ca"):
            kho_tg = tai(URL_TG)
            ra.setdefault("kho_cap_nhat_luc", kho_tg.get("capNhatLuc"))
            ra["ung_vien_the_gioi"] = xep_hang(kho_tg["tin"], "tg", a.ngay, a.so)
    except Exception as e:
        sys.exit(f"Không lấy được tin: {e}\nKiểm mạng, hoặc app SỨC BẬT đang deploy.")

    print(f"Kho SỨC BẬT cập nhật: {ra.get('kho_cap_nhat_luc')} | cửa sổ {a.ngay} ngày")
    if "ung_vien_viet_nam" in ra:
        in_nhom("VIỆT NAM", ra["ung_vien_viet_nam"])
    if "ung_vien_the_gioi" in ra:
        in_nhom("THẾ GIỚI, tiếng Anh", ra["ung_vien_the_gioi"])

    if a.json:
        with open(a.json, "w", encoding="utf-8") as f:
            json.dump(ra, f, ensure_ascii=False, indent=1)
        print(f"\nĐã ghi {a.json}")


if __name__ == "__main__":
    main()
