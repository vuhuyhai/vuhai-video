#!/usr/bin/env python3
"""Tìm việc trùng nội dung trong hàng đợi. Dùng: python3 dupcheck.py <thư mục chứa <mã>.json> [ngưỡng=0.6]
So khớp cụm 3 từ của trường source (độ giống Jaccard). In các cặp trùng, giữ việc cũ nhất, đánh dấu việc sau là loi."""
import json, glob, re, sys, os, unicodedata
d = sys.argv[1]; th = float(sys.argv[2]) if len(sys.argv) > 2 else 0.6
def sh(t):
    t = unicodedata.normalize("NFC", t.lower()); w = re.findall(r"\w+", t)
    return {" ".join(w[i:i+3]) for i in range(max(1, len(w) - 2))}
jobs = []
for f in glob.glob(os.path.join(d, "*.json")):
    j = json.load(open(f)); s = j.get("source", "") or ""
    if len(s) > 80: jobs.append((j.get("createdAt", ""), os.path.basename(f)[:-5], j.get("status", ""), sh(s)))
jobs.sort(); dup = 0
for i, a in enumerate(jobs):
    for b in jobs[i+1:]:
        u = len(a[3] | b[3]) or 1; sim = len(a[3] & b[3]) / u
        if sim >= th: dup += 1; print(f"TRUNG {sim:.2f}: giữ {a[1]} ({a[2]}), bỏ {b[1]} ({b[2]})")
print("cặp trùng:", dup, "trên", len(jobs), "việc")
