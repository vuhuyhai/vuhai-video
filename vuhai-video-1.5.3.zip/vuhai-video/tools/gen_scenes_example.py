#!/usr/bin/env python3
# Bản dọc 9:16 (1080x1920). Đọc vo.json, durs_t.json, pauses.json. Sinh index.html (setT theo thời gian) và timing.json.
import json, re, os
W = os.path.dirname(os.path.abspath(__file__))
vo = json.load(open(f"{W}/vo.json")); durs = json.load(open(f"{W}/durs_t.json")); pauses = json.load(open(f"{W}/pauses.json"))
LEAD, TAIL, EXTRA_LAST = 0.15, 0.1, 3.5
KEYS = ["g%d"%i for i in range(1,12)]
DUR, START = {}, {}; t = 0.0
for k in KEYS:
    DUR[k] = round(LEAD + durs[k] + TAIL + (EXTRA_LAST if k == "g11" else 0), 3); START[k] = round(t, 3); t += DUR[k]
TOTAL = round(t, 3)
json.dump({"START":START,"DUR":DUR,"TOTAL":TOTAL,"LEAD":LEAD}, open(f"{W}/timing.json","w"), indent=1)
INK, CREAM, RED, PET = "#1A1A1A", "#F7F4EF", "#c73937", "#245B6B"

def icon(name):
    s = open(f"{W}/icons/{name}.svg").read()
    s = re.sub(r"<!--.*?-->", "", s, flags=re.S).strip(); s = re.sub(r'\s(width|height)="24"', "", s, count=2)
    s = s.replace("<svg", '<svg class="ico"', 1); assert 'class="ico"' in s and "<path" in s, name; return s

def cues(key, cuts):
    txt, dur, pa = vo[key], durs[key], pauses[key]; res, pos = [], 0
    for c in cuts:
        i = txt.find(c, pos); assert i >= 0, (key, c); pos = i
        est = i / len(txt) * dur
        if i == 0: tt = 0.0
        else:
            cand = [b for a, b in pa if abs(b - est) < 0.55]; tt = min(cand, key=lambda b: abs(b - est)) if cand else est
        res.append(round(tt + LEAD, 2))
    return res
def seg_end(k): return round(LEAD + durs[k], 2)
def sub(a, d=0.12, lo=0.35): return max(lo, round(a - d, 2))

EV = {}   # id -> config (theo từng cảnh)
ALL = []
def archive():
    for k_, e_ in EV.items(): ALL.append((k_, e_))
    EV.clear()
def ev(sc, i, kind, t, **kw): EV[i] = dict(sc=sc, k=kind, t=round(START[sc] + t, 3), **kw)

# ---- phần tử HTML ----
def card(i, x, y, w, h, cls="", inner="", sh=16, bw=5):
    return f'<div class="card {cls}" id="{i}" data-sh="{sh}" style="left:{x}px;top:{y}px;width:{w}px;height:{h}px;border-width:{bw}px">{inner}</div>'
def ibox(i, x, y, s, name):
    return f'<div class="ibox" id="{i}" style="left:{x}px;top:{y}px;width:{s}px;height:{s}px"><div class="bw" style="width:64%;height:64%">{icon(name)}</div></div>'
def t_(i, x, y, s, cls="", style=""): return f'<div class="t {cls}" id="{i}" style="left:{x}px;top:{y}px;{style}">{s}</div>'
def chip(i, x, y, s, kind="pet", h=56): return f'<div class="chip {kind}" id="{i}" style="left:{x}px;top:{y}px;height:{h}px">{s}</div>'
def small_ibox(s, name): return f'<div class="abs ibx" style="left:24px;top:24px;width:{s}px;height:{s}px"><div class="bw" style="width:64%;height:64%">{icon(name)}</div></div>'
def tagchip(): return chip("tag", 80, 250, "LỊCH SỬ GIÁO DỤC THỂ CHẤT", "cr", 52)
def mas(i, src, h, right, bottom_y):
    from PIL import Image
    w0, h0 = Image.open(f"{W}/assets/{src}.png").size; w = round(h * w0 / h0)
    return f'<img class="mas" id="{i}" src="assets/{src}.png" style="height:{h}px;width:{w}px;left:{right-w}px;top:{bottom_y-h}px">'

LABELS = ["HY LẠP", "1811", "1813", "1861", "1893", "1978"]
RY = 1425; RC = [94 + i * (852) / 5 for i in range(6)]
def rail(active, sc):
    h = f'<div class="rl" style="left:{RC[0]:.1f}px;top:{RY+11}px;width:{RC[-1]-RC[0]:.1f}px"></div>'
    prev = RC[active-1]-RC[0] if active > 0 else 0
    h += f'<div class="rf" id="rfill{sc}" style="left:{RC[0]:.1f}px;top:{RY+11}px;width:{prev:.1f}px"></div>'
    for i, lab in enumerate(LABELS):
        st = "past" if i < active else ("act" if i == active else "fut")
        h += f'<div class="rn {st}" id="rn{sc}{i}" style="left:{RC[i]-14:.1f}px;top:{RY}px"></div>'
        lx = RC[i] - 70; al = "center"
        if i == 0: lx, al = RC[i]-14, "left"
        if i == 5: lx, al = RC[i]+14-140, "right"
        h += f'<div class="rt {st}" style="left:{lx:.1f}px;top:{RY+44}px;text-align:{al}">{lab}</div>'
    EV[f"rail{sc}"] = dict(sc=sc, k="rail", t=round(START[sc] + 0.45, 3), a=prev, b=RC[active]-RC[0], id=f"rfill{sc}", node=f"rn{sc}{active}")
    return h

def row_dur(a, b): return max(.5, round(b - a - .5, 2))
def add_row(sc, i, a0, b):  # card + bar + lift
    ev(sc, i, "land", a0, dy=60)
    EV[i]["bar"] = [round(START[sc] + a0 + .45, 3), row_dur(a0, b)]
    EV[i]["lift"] = [round(START[sc] + a0 + .45, 3), row_dur(a0, b)]

SC = {}
ARROW = icon("arrow-right").replace('class="ico"', 'class="ico ink"')
def topic(sc, label, t=.3):
    return chip("topic", 120, 100, label, "cr", 52)
def numbox(n, x=28, y=28, s=68): return f'<div class="abs nm" style="left:{x}px;top:{y}px;width:{s}px;height:{s}px;font-size:36px">{n}</div>'
def ib(s, name, x, y): return f'<div class="abs ibx" style="left:{x}px;top:{y}px;width:{s}px;height:{s}px"><div class="bw" style="width:64%;height:64%">{icon(name)}</div></div>'
def mk(i, kind, sc, t, **kw): ev(sc, i, kind, t, **kw)
H = lambda s, size, extra="": f'<div class="h" style="font-size:{size}px;line-height:1.08;{extra}">{s}</div>'

archive()
# ---------- g1 ----------
c = cues("g1", ["Vấn đề"])
SC["g1"] = (chip("topic", 120, 100, "BÀI VIẾT CỦA VŨ HẢI", "pet", 52)
  + t_("pre", 120, 185, "GÓI TẬP CÀNG", "h", "font-size:60px")
  + t_("l1", 120, 255, "CHIỀU KHÁCH,", "h", "font-size:140px")
  + t_("l2", 120, 410, "CÀNG BỊ MẶC CẢ", "h", f"font-size:120px;color:{RED}")
  + f'<div class="strike" id="u1" style="left:120px;top:555px;width:640px;height:16px;background:{INK}"></div>'
  + card("k1", 120, 640, 1000, 320, "pet", ib(100, "tag", 36, 36) + '<div class="abs h" style="left:170px;top:40px;font-size:50px;line-height:1.12">Vấn đề không nằm ở<br>con số trên bảng giá</div><div class="abs" style="left:36px;top:190px;font-size:36px;font-weight:700;line-height:1.2">mà ở chỗ khách chưa hình dung<br>được mình nhận lại điều gì</div>')
  + mas("m1", "n1", 880, 1860, 1040))
mk("topic", "tag", "g1", .25); mk("pre", "rev", "g1", .3, dy=30); mk("l1", "rev", "g1", .45, dy=40); mk("l2", "rev", "g1", .7, dy=40); mk("u1", "strike", "g1", 1.1)
mk("k1", "land", "g1", sub(c[0], .1, .4), dy=60); mk("m1", "mas", "g1", .3, dy=220)

archive()
# ---------- g2 ----------
c = cues("g2", ["Sản phẩm là", "Dịch vụ lại"])
SC["g2"] = (topic("g2", "KHÁCH KHÔNG HIỂU")
  + card("k1", 120, 200, 1180, 230, "", ib(110, "message-question", 36, 40) + H("Khách không thể mua<br>thứ họ không hiểu", 58, "position:absolute;left:190px;top:34px;line-height:1.1"))
  + card("k2", 120, 470, 1180, 330, "pet", '<div class="abs chip cr" style="left:36px;top:34px;height:52px">WIRTZ &amp; LOVELOCK (LƯỢC DỊCH)</div>' + H("Sản phẩm là tập hợp dịch vụ<br>chuẩn hóa, rõ ràng, phân biệt được", 48, "position:absolute;left:36px;top:128px;line-height:1.15"))
  + card("k3", 120, 840, 1180, 140, "red", H("Dịch vụ được trải nghiệm, không được sở hữu", 44, "position:absolute;left:36px;top:40px;white-space:nowrap"))
  + mas("m1", "n3", 880, 1860, 1040))
mk("topic", "tag", "g2", .25); mk("k1", "land", "g2", .35, dy=50); mk("k2", "land", "g2", sub(c[0], .1, .4), dy=50); mk("k3", "land", "g2", sub(c[1]), dy=50); mk("m1", "mas", "g2", .4, dy=220)

archive()
# ---------- g3 ----------
c = cues("g3", ["Con số giá", "nên khách"])
SC["g3"] = (topic("g3", "VÌ SAO BỊ MẶC CẢ")
  + card("k1", 120, 200, 1100, 250, "", '<div class="abs chip cr" style="left:36px;top:34px;height:52px">THIẾU RÕ RÀNG</div>' + H("Khách không phân biệt<br>được giá trị các gói", 56, "position:absolute;left:36px;top:116px;line-height:1.1"))
  + card("k2", 120, 480, 1100, 280, "red", ib(110, "ruler-2", 36, 36).replace("ibx", "ibx dk") + H("CON SỐ GIÁ", 100, "position:absolute;left:190px;top:30px") + '<div class="abs" style="left:36px;top:170px;font-size:40px;font-weight:700;line-height:1.2">thước đo rõ ràng duy nhất còn lại</div>')
  + card("k3", 120, 790, 1100, 190, "pet", H("Khách mặc cả giá,<br>thay vì so sánh giá trị", 50, "position:absolute;left:36px;top:36px;line-height:1.12"))
  + mas("m1", "n2", 880, 1860, 1040))
mk("topic", "tag", "g3", .25); mk("k1", "land", "g3", .35, dy=50); mk("k2", "land", "g3", sub(c[0]), dy=50); mk("k3", "land", "g3", sub(c[1]), dy=50); mk("m1", "mas", "g3", .4, dy=220)

archive()
# ---------- g4 ----------
c = cues("g4", ["Classic", "Black Card"])
SC["g4"] = (topic("g4", "PLANET FITNESS")
  + card("k0", 120, 200, 1680, 170, "pet", ib(100, "list-check", 36, 28) + H("Chỉ bán hai gói chính", 80, "position:absolute;left:190px;top:34px"))
  + card("k1", 120, 410, 820, 540, "", '<div class="abs chip cr" style="left:36px;top:34px;height:52px">CLASSIC</div>' + H("15 USD", 170, "position:absolute;left:36px;top:130px") + '<div class="abs m" style="left:36px;top:340px;font-size:34px;color:%s">MỖI THÁNG, GIÁ TỪ</div>' % PET, 16, 5)
  + card("k2", 980, 410, 820, 540, "red", '<div class="abs chip cr" style="left:36px;top:34px;height:52px">BLACK CARD</div>' + H("24,99 USD", 130, "position:absolute;left:36px;top:140px") + '<div class="abs m" style="left:36px;top:320px;font-size:34px">MỖI THÁNG, GIÁ TỪ</div><div class="abs h" style="left:36px;top:390px;font-size:44px">cộng 49 USD phí thường niên</div>'))
mk("topic", "tag", "g4", .25); mk("k0", "land", "g4", .35, dy=50); mk("k1", "land", "g4", sub(c[0]), dy=50); mk("k2", "land", "g4", sub(c[1]), dy=50)

archive()
# ---------- g5 ----------
c = cues("g5", ["Năm hai nghìn không trăm hai mươi mốt", "Doanh thu bình quân"])
SC["g5"] = (topic("g5", "KẾT QUẢ CỦA PLANET FITNESS")
  + card("k1", 120, 200, 800, 760, "red", '<div class="abs h" id="n66" style="left:36px;top:30px;font-size:210px;line-height:1.1">66,5%</div>' + H("HỘI VIÊN CHỌN<br>GÓI ĐẮT HƠN", 66, "position:absolute;left:36px;top:300px;line-height:1.1") + '<div class="abs m" style="left:36px;top:480px;font-size:34px">CUỐI NĂM 2025</div>', 24, 8)
  + card("k2", 960, 200, 840, 270, "", '<div class="abs h" style="left:36px;top:20px;font-size:130px;line-height:1.1;color:%s">62,6%%</div>' % PET + '<div class="abs m" style="left:36px;top:180px;font-size:32px">NĂM 2021, CÙNG CHỈ SỐ</div>')
  + card("k3", 960, 510, 840, 450, "pet", ib(100, "trending-up", 36, 34) + '<div class="abs m" style="left:170px;top:50px;font-size:30px">DOANH THU BÌNH QUÂN</div><div class="abs h" style="left:36px;top:160px;font-size:76px;line-height:1.1">17,63 lên 19,51</div><div class="abs" style="left:36px;top:290px;font-size:36px;font-weight:700;line-height:1.2">USD mỗi người mỗi tháng</div>'))
mk("topic", "tag", "g5", .25); mk("k1", "land", "g5", .35, dy=50); mk("n66", "slam", "g5", .6); mk("k2", "land", "g5", sub(c[0]), dy=50); mk("k3", "land", "g5", sub(c[1]), dy=50)

archive()
# ---------- g6 ----------
c = cues("g6", ["Đó là", "Khảo sát"])
SC["g6"] = (topic("g6", "VÌ SAO KHÁCH BẢO QUÁ ĐẮT")
  + card("k1", 120, 200, 780, 240, "", '<div class="abs chip cr" style="left:36px;top:34px;height:52px">MỨC GIÁ</div>' + H("Con số trên<br>bảng giá", 56, "position:absolute;left:36px;top:112px;line-height:1.08"))
  + card("k2", 1020, 200, 780, 240, "pet", '<div class="abs chip cr" style="left:36px;top:34px;height:52px">GIÁ TRỊ</div>' + H("Điều khách nhìn<br>thấy được", 56, "position:absolute;left:36px;top:112px;line-height:1.08"))
  + ibox("gap", 910, 270, 100, "arrows-diff")
  + card("k3", 120, 490, 1680, 470, "red", '<div class="abs h" id="n41" style="left:40px;top:30px;font-size:290px;line-height:1.1">41%</div>' + H("NGƯỜI HỦY THẺ TẬP<br>VÌ QUÁ ĐẮT", 70, "position:absolute;left:760px;top:70px;line-height:1.1") + '<div class="abs m" style="left:760px;top:300px;font-size:34px">KHẢO SÁT YOUGOV</div>', 24, 8))
mk("topic", "tag", "g6", .25); mk("k1", "land", "g6", .35, dy=50); mk("k2", "land", "g6", sub(c[0]) , dy=50); mk("gap", "pop", "g6", sub(c[0]) + .25)
mk("k3", "land", "g6", sub(c[1]), dy=50); mk("n41", "slam", "g6", sub(c[1]) + .3)

archive()
# ---------- g7 ----------
c = cues("g7", ["tính năng", "mô tả", "lời hứa", "có tên", "cách tính giá", "cách mua"])
feats = [("list-check", "TÍNH NĂNG<br>CỤ THỂ"), ("file-description", "MÔ TẢ<br>RÕ RÀNG"), ("trending-up", "LỜI HỨA<br>GIÁ TRỊ RÕ"), ("tag", "CÓ TÊN<br>RIÊNG"), ("percentage", "CÁCH TÍNH<br>GIÁ"), ("package", "CÁCH MUA<br>XÁC ĐỊNH")]
SC["g7"] = topic("g7", "SẢN PHẨM DỊCH VỤ TỐT")
for n, (ic, ti) in enumerate(feats, 1):
    x = 120 + ((n - 1) % 3) * 570; y = 200 + ((n - 1) // 3) * 390
    SC["g7"] += card(f"f{n}", x, y, 540, 360, "red" if n in (3, 6) else "", ib(110, ic, 36, 36).replace("ibx", "ibx dk" if n in (3, 6) else "ibx") + H(ti, 52, "position:absolute;left:36px;top:190px;line-height:1.1"))
mk("topic", "tag", "g7", .25)
for n in range(1, 7):
    mk(f"f{n}", "land", "g7", sub(c[n - 1], .15, .35), dy=50)

archive()
# ---------- g8 ----------
c = cues("g8", ["Hầu như", "Ở phòng gym", "còn nội dung"])
SC["g8"] = (topic("g8", "SẢN PHẨM RÕ GIÚP ĐỘI NGŨ")
  + card("k1", 120, 200, 1680, 310, "", ib(120, "coffee", 36, 36) + '<div class="abs chip cr" style="left:190px;top:34px;height:52px">STARBUCKS (LƯỢC DỊCH)</div>' + H("Hầu như mọi nhân viên đều tự tin<br>giới thiệu các dòng đồ uống", 60, "position:absolute;left:190px;top:120px;line-height:1.12"))
  + card("k2", 120, 550, 820, 410, "red", ib(110, "users", 36, 36).replace("ibx", "ibx dk") + '<div class="abs m" style="left:176px;top:50px;font-size:30px">PHÒNG GYM</div>' + H("Ranh giới rõ<br>giúp tư vấn<br>đồng đều", 60, "position:absolute;left:36px;top:170px;line-height:1.1"))
  + card("k3", 980, 550, 820, 410, "pet", ib(110, "stopwatch", 36, 36) + '<div class="abs m" style="left:176px;top:50px;font-size:30px">BUỔI TẬP</div>' + H("Nội dung chi tiết<br>vẫn linh hoạt", 60, "position:absolute;left:36px;top:170px;line-height:1.1")))
mk("topic", "tag", "g8", .25); mk("k1", "land", "g8", sub(c[0]), dy=50); mk("k2", "land", "g8", sub(c[1]), dy=50); mk("k3", "land", "g8", sub(c[2]), dy=50)

archive()
# ---------- g9 ----------
c = cues("g9", ["Một,", "Hai,", "Ba,"]); e9 = seg_end("g9")
tasks = [("BẢNG GIÁ CHO NGƯỜI NGOÀI NGÀNH", "Nhờ họ giải thích mỗi gói gồm gì"),
         ("XÁC ĐỊNH DỊCH VỤ CỐT LÕI", "Dịch vụ bổ sung ghi bằng con số, như số lần<br>đo chỉ số hay thời gian phản hồi"),
         ("ĐẶT TÊN CHO GÓI", "Nhờ ba tư vấn viên giới thiệu, nếu họ nói<br>khác nhau thì sản phẩm chưa rõ")]
SC["g9"] = topic("g9", "BA VIỆC TRONG TUẦN NÀY")
for n, (ti, su) in enumerate(tasks, 1):
    y = 190 + (n - 1) * 275
    SC["g9"] += card(f"r{n}", 120, y, 1100, 250, "", f'<div class="abs nm" style="left:34px;top:34px;width:84px;height:84px;font-size:48px">{n}</div>' + H(ti, 38, "position:absolute;left:150px;top:36px;white-space:nowrap") + f'<div class="abs" style="left:150px;top:100px;font-size:32px;font-weight:700;line-height:1.2">{su}</div><div class="bar" id="r{n}b"></div>')
SC["g9"] += mas("m1", "n4", 860, 1860, 1040)
mk("topic", "tag", "g9", .25); mk("m1", "mas", "g9", .4, dy=220)
for n, (a, b) in enumerate(zip([c[0], c[1], c[2]], [c[1], c[2], e9]), 1):
    a0 = sub(a, .2, .5); mk(f"r{n}", "land", "g9", a0, dy=50, bar=[round(START["g9"] + a0 + .45, 3), row_dur(a0, b)], barid=f"r{n}b", lift=None)

archive()
# ---------- g10 ----------
c = cues("g10", ["Khi các gói"])
SC["g10"] = (topic("g10", "KẾT LUẬN")
  + card("k1", 120, 200, 800, 760, "red", '<div class="abs h" id="n23" style="left:36px;top:50px;font-size:330px;line-height:1.1">2/3</div>' + H("KHÁCH PLANET<br>FITNESS", 66, "position:absolute;left:36px;top:430px;line-height:1.1") + '<div class="abs m" style="left:36px;top:590px;font-size:34px">TỰ CHỌN GÓI ĐẮT HƠN</div>', 24, 8)
  + card("k2", 960, 200, 840, 360, "pet", ib(110, "eye", 36, 36) + H("Khách cần hiểu<br>mình nhận được gì", 62, "position:absolute;left:36px;top:170px;line-height:1.1"))
  + card("k3", 960, 600, 840, 360, "", '<div class="abs chip cr" style="left:36px;top:34px;height:52px">KHI GÓI ĐƯỢC THIẾT KẾ RÕ</div>' + H("Khách tự chọn<br>gói đắt hơn", 66, "position:absolute;left:36px;top:130px;line-height:1.1")))
mk("topic", "tag", "g10", .25); mk("k1", "land", "g10", .35, dy=50); mk("n23", "slam", "g10", .6); mk("k2", "land", "g10", .9, dy=50); mk("k3", "land", "g10", sub(c[0]), dy=50)

archive()
# ---------- g11 ----------
c = cues("g11", ["Bạn đọc"])
SC["g11"] = (chip("c1", 120, 130, "ĐỌC BÀI ĐẦY ĐỦ TRÊN WEBSITE", "red", 64)
  + card("k1", 120, 230, 900, 480, "cream", f'<div class="abs h" style="left:44px;top:30px;font-size:72px;color:{INK}">VŨ HẢI</div><div class="abs" style="left:44px;top:124px;width:810px;height:5px;background:{RED}"></div><div class="abs m" style="left:44px;top:160px;font-size:44px;color:{INK}">0344 444 000</div><div class="abs m" style="left:44px;top:240px;font-size:38px;color:{INK}">fitnessviet@gmail.com</div><div class="abs m" style="left:44px;top:318px;font-size:36px;color:{INK}">facebook.com/vuhai.fitness</div><div class="abs m" style="left:44px;top:396px;font-size:44px;color:{RED}">vuhuyhai.com</div>')
  + t_("tg", 120, 770, "Human first.", "h", f"font-size:92px;color:{INK}") + t_("tg2", 120, 880, "Profit follows.", "h", f"font-size:92px;color:{RED}")
  + mas("m1", "n1", 880, 1860, 1040))
mk("c1", "tag", "g11", .3); mk("k1", "land", "g11", .45, dy=60); mk("tg", "rev", "g11", .8, dy=30); mk("tg2", "rev", "g11", 1.0, dy=30); mk("m1", "mas", "g11", .5, dy=220)
archive()


# ---------------- ghép ----------------
def css():
    return f"""
:root{{--cream:{CREAM};--ink:{INK};--red:{RED};--pet:{PET}}}
*{{box-sizing:border-box;margin:0;padding:0}}
body{{width:1920px;height:1080px;overflow:hidden;background:{CREAM};font-family:'Inter';font-weight:500;color:{INK};position:relative}}
.nen{{position:absolute;inset:0;opacity:.11;background-image:linear-gradient({INK} 2px,transparent 2px),linear-gradient(90deg,{INK} 2px,transparent 2px);background-size:130px 130px}}
.sc{{position:absolute;left:0;top:0;width:1920px;height:1080px;overflow:hidden;background:{CREAM}}}
.sc.dark{{background:{INK};color:{CREAM}}}
.sc.dark .nen{{opacity:.09;background-image:linear-gradient({CREAM} 2px,transparent 2px),linear-gradient(90deg,{CREAM} 2px,transparent 2px)}}
.abs{{position:absolute}}
.card{{position:absolute;background:#fff;border:5px solid {INK};border-radius:4px;overflow:hidden;opacity:0}}
.card.red{{background:{RED};color:{CREAM}}} .card.pet{{background:{PET};color:{CREAM}}} .card.cream{{background:{CREAM};color:{INK}}}
.ibox{{position:absolute;background:{RED};border:5px solid {INK};border-radius:4px;display:flex;align-items:center;justify-content:center;opacity:0}}
.ibx{{background:{RED};border:5px solid {INK};border-radius:4px;display:flex;align-items:center;justify-content:center}}
.nm.dk,.ibx.dk{{background:{INK}}} .ico.ink{{color:{INK}}} .bw{{display:block}} .ico{{width:100%;height:100%;display:block;color:{CREAM}}}
.t{{position:absolute;white-space:nowrap;line-height:1.05;opacity:0}}
.h{{font-family:'Space Grotesk';font-weight:700;letter-spacing:-.02em}} .m{{font-family:'JetBrains Mono';font-weight:700;letter-spacing:.02em}}
.chip{{position:absolute;display:flex;align-items:center;padding:0 20px;border:3px solid {INK};border-radius:4px;font-family:'JetBrains Mono';font-weight:700;font-size:30px;letter-spacing:.03em;white-space:nowrap;opacity:0}}
.chip.pet{{background:{PET};color:{CREAM}}} .chip.cr{{background:{CREAM};color:{INK}}} .chip.red{{background:{RED};color:{CREAM}}}
.card .chip{{opacity:1}}
.nm{{left:28px;top:30px;width:62px;height:62px;background:{RED};color:{CREAM};border:3px solid {INK};display:flex;align-items:center;justify-content:center;font-family:'JetBrains Mono';font-weight:700;font-size:32px}}
.bar{{position:absolute;left:0;bottom:0;height:10px;width:100%;background:{PET};transform-origin:0 50%;transform:scaleX(0)}}
.card.red .bar,.card.pet .bar{{background:{CREAM}}}
.rl{{position:absolute;height:6px;background:{INK};opacity:.25}} .rf{{position:absolute;height:6px;background:{INK}}}
.rn{{position:absolute;width:28px;height:28px;border:4px solid {INK};background:{CREAM};border-radius:2px}} .rn.past{{background:{INK}}} .rn.act{{background:{RED}}}
.rt{{position:absolute;width:140px;font-family:'JetBrains Mono';font-weight:700;font-size:30px;white-space:nowrap}} .rt.fut{{color:#5C5A57}} .rt.act{{color:{RED}}}
.strike{{position:absolute;background:{RED};transform-origin:0 50%;transform:scaleX(0)}}
img.mas{{position:absolute;opacity:0}}
"""
VI = "U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB"
LA = "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD"
FF = ""
for fam, base, wts in [("Space Grotesk","space-grotesk",[700]),("Inter","inter",[500,700]),("JetBrains Mono","jetbrains-mono",[700])]:
    for w in wts:
        for ss, rg in [("vietnamese",VI),("latin",LA)]:
            FF += f'@font-face{{font-family:"{fam}";font-weight:{w};font-display:block;src:url("fonts/{base}-{ss}-{w}-normal.woff2") format("woff2");unicode-range:{rg}}}\n'
scenes = ""
for k in KEYS:
    dark = " dark" if k in ("none",) else ""
    body = re.sub(r'id="([^"]+)"', lambda m: f'id="{k}_{m.group(1)}"', SC[k])
    scenes += f'<div class="sc{dark}" id="{k}"><div class="nen"></div>{body}</div>\n'
EV2 = {}
for i_, e_ in ALL:
    e_ = dict(e_); sc_ = e_["sc"]
    for f_ in ("barid", "id", "node"):
        if f_ in e_: e_[f_] = f"{sc_}_{e_[f_]}"
    EV2[f"{sc_}_{i_}"] = e_
EV = EV2
scdef = {k: [START[k], round(START[k] + DUR[k], 3)] for k in KEYS}
import os
FIXJ = open(f"{W}/fix.json").read() if os.path.exists(f"{W}/fix.json") else "{}"
html = f"""<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>Gói tập phòng gym 90s</title><style>{FF}{css()}</style></head><body>
{scenes}
<script>
const EV={json.dumps(EV, ensure_ascii=False)};
const SCD={json.dumps(scdef)};const KEYS={json.dumps(KEYS)};const TOTAL={TOTAL};
const FIX=__FIX__;
document.querySelectorAll('.sc').forEach(sc=>{{
 const L=[...sc.children].filter(e=>!e.classList.contains('nen')&&!e.classList.contains('mas')&&e.style.top).map(e=>{{const t=parseFloat(e.style.top);return {{e,l:e.offsetLeft,r:e.offsetLeft+e.offsetWidth,t,b:t+e.offsetHeight,dh:(FIX[e.id]||[0,0,0])[2],s:0}}}}).sort((p,q)=>p.t-q.t);
 L.forEach((q,i)=>{{for(let j=0;j<i;j++){{const p=L[j];if(q.t>=p.b-6&&Math.min(q.r,p.r)-Math.max(q.l,p.l)>4)q.s=Math.max(q.s,p.s+p.dh)}}}});
 L.forEach(q=>{{if(q.s)q.e.style.top=(q.t+q.s)+'px'}});
}});
Object.entries(FIX).forEach(([id,[dx,dy,dh]])=>{{const c=document.getElementById(id);if(!c)return;c.style.height=(parseFloat(c.style.height)+dh)+'px';[...c.children].forEach(ch=>{{if(ch.style.left)ch.style.left=(parseFloat(ch.style.left)+dx)+'px';if(ch.style.top)ch.style.top=(parseFloat(ch.style.top)+dy)+'px';}})}});
const clamp=(x,a=0,b=1)=>Math.min(b,Math.max(a,x));
const oc=x=>1-Math.pow(1-clamp(x),3);
const ob=x=>{{x=clamp(x);const c=1.2,k=c+1;return 1+k*Math.pow(x-1,3)+c*Math.pow(x-1,2)}};
const $=id=>document.getElementById(id);const T=0.3;
function px(i,t){{const [a,b]=SCD[KEYS[i]];let x=0;if(i>0&&t<a+T)x=1920*(1-oc((t-a)/T));if(i<KEYS.length-1&&t>=b)x=-1920*oc((t-b)/T);if(i>0&&t<a)x=1920;if(i<KEYS.length-1&&t>b+T)x=-1920;return x}}
function setT(t){{
 KEYS.forEach((k,i)=>{{const x=px(i,t);const s=$(k);s.style.transform=`translateX(${{x}}px)`;s.style.display=Math.abs(x)>=1920?'none':'block';s.querySelector('.nen').style.backgroundPosition=`${{-t*26}}px ${{t*15}}px`;}});
 for(const id in EV){{const e=EV[id];const el=$(id);if(!el&&e.k!=='rail')continue;const u=t-e.t;
  if(e.k==='land'){{const p=ob(u/.45);el.style.opacity=u<0?0:1;let tx=0;if(e.lift){{const [l0,ld]=e.lift;const q=t-l0;tx=q<0?0:(q<.2?14*oc(q/.2):(q<ld-.2?14:14*(1-clamp((q-(ld-.2))/.2))))}}
    el.style.transform=`translate(${{tx}}px,${{(1-p)*e.dy}}px)`;const sp=oc((u-.35)/.2);const sh=+el.dataset.sh;el.style.boxShadow=`${{sh*sp}}px ${{sh*sp}}px 0 ${{INKC}}`;
    if(e.bar){{const b=$(e.barid||e.id+'b');if(b){{const q=(t-e.bar[0])/e.bar[1];b.style.transform=`scaleX(${{clamp(q)}})`}}}}}}
  else if(e.k==='rev'){{el.style.opacity=u<0?0:oc(u/.4);el.style.transform=`translateY(${{(1-oc(u/.4))*e.dy}}px)`}}
  else if(e.k==='tag'){{const p=ob(u/.35);el.style.opacity=u<0?0:1;el.style.transform=`scale(${{.7+.3*p}})`}}
  else if(e.k==='pop'){{const p=ob(u/.4);el.style.opacity=u<0?0:1;el.style.transform=`scale(${{.6+.4*p}})`}}
  else if(e.k==='slam'){{const p=ob(u/.45);el.style.opacity=u<0?0:1;el.style.transform=`scale(${{1.28-.28*p}})`;el.style.transformOrigin='0 50%'}}
  else if(e.k==='strike'){{el.style.transform=`scaleX(${{oc(u/.3)}})`}}
  else if(e.k==='mas'){{const p=ob(u/.5);el.style.opacity=u<0?0:1;el.style.transform=`translateY(${{(1-p)*e.dy+Math.sin(t*2.6)*6}}px)`}}
  else if(e.k==='rail'){{const f=$(e.id);f.style.width=(e.a+(e.b-e.a)*oc(u/.6))+'px';const n=$(e.node);n.style.transform=`scale(${{1+.45*ob((u-.25)/.4)}})`}}
 }}
 document.querySelectorAll('.bw').forEach((e,i)=>e.style.transform=`translateY(${{Math.sin(t*3.2+i)*3}}px)`);
}}
const INKC='{INK}';
window.setT=setT;setT(0);
</script></body></html>"""
html = html.replace("__FIX__", FIXJ)
open(f"{W}/index.html", "w").write(html)
print("TOTAL", TOTAL, {k: (START[k], DUR[k]) for k in KEYS})
