# Quy tắc ngôn ngữ, bắt buộc cho mọi script video

Áp dụng cho chữ trên màn hình, lời đọc, và caption. Không thương lượng, không có ngoại lệ theo "văn phong sáng tạo".

## Đi cùng, không đi theo

- Luôn dùng "đi cùng". KHÔNG dùng "đi theo" (hàm ý cấp bậc, trên-dưới).
- Áp dụng cho mọi câu diễn tả quan hệ giữa người vận hành và hệ thống, giữa lãnh đạo và đội nhóm.

## Hệ thống đỡ người, không nâng, không bẻ

- Hệ thống "đỡ" con người, hỗ trợ, chịu lực thay khi cần.
- KHÔNG dùng "nâng" (hàm ý đưa lên cao, phân cấp).
- KHÔNG dùng "bẻ" (hàm ý ép buộc, cưỡng chế con người theo hệ thống).

## Từ cấm, nếu ai đọc cũng gật đầu, nghĩa là nó rỗng

Không dùng trong bất kỳ dòng chữ nào của video:
- kiến tạo
- lan tỏa
- nâng tầm
- truyền cảm hứng
- cuộc cách mạng

Khi viết xong một beat, tự kiểm: nếu câu đó đọc lên mà không ai phản đối được, không ai bị chạm, viết lại cụ thể hơn.

## Cốt lõi: Phân vai, không phân hạng

Khi video chạm tới chủ đề vai trò, đội nhóm, cấu trúc tổ chức: kiểm tra ngôn ngữ có vô tình tạo ra thứ bậc (trên/dưới, cao/thấp, lãnh đạo giỏi hơn nhân viên) hay không. Nếu có, viết lại theo hướng phân vai, mỗi người một vai trò, không ai đứng trên ai.
