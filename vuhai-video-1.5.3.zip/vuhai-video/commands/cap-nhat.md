---
description: Cập nhật plugin vuhai-video lên bản mới nhất từ GitHub
argument-hint: "[--check]"
allowed-tools: Bash
---
Chạy đúng một lệnh rồi báo kết quả bằng tiếng Việt, ngắn gọn, không thêm ý:

```
python3 "${CLAUDE_PLUGIN_ROOT}/tools/self_update.py" $ARGUMENTS
```

- Có bản mới và đã cài: nói phiên bản cũ, phiên bản mới, nơi lưu bản cũ, và nhắc mở phiên mới.
- Đã là bản mới nhất: nói một câu.
- Lệnh báo lỗi: chép nguyên lời báo lỗi, không tự đoán nguyên nhân khác.
