#!/usr/bin/env python3
# Khuôn trang v1.3 (flex card, đệm chữ tự động). Đọc vo.json, durs_t.json, pauses.json, video.json. Sinh index.html và timing.json.
# Được build_page.py nối với scenes.py (cảnh của video) và _tail.py rồi chạy; không chạy riêng.
import json, re, os
W = os.path.dirname(os.path.abspath(__file__))
vo = json.load(open(f"{W}/vo.json")); durs = json.load(open(f"{W}/durs_t.json")); pauses = json.load(open(f"{W}/pauses.json"))
LEAD, TAIL = 0.10, 0.05
CFG = json.load(open(f"{W}/video.json"))
TITLE = CFG["title"]; PW, PH = CFG.get("size", [1080, 1920])
LANG = CFG.get("khoang_lang", {})  # khoảng lặng thêm vào cuối cảnh, giây: {"s4": 0.5} = lặng 0,5 giây ngay trước cảnh s5 (nhạc và tiếng hiệu ứng tắt)
FIXED = CFG.get("fixed", {})  # cảnh có thời lượng tối thiểu, ví dụ CTA đứng yên 6 giây: {"s10": 7.5}
DARK = CFG.get("dark", [])  # cảnh nền tối (chữ kem)
KEYS = list(vo)
DUR, START = {}, {}; t = 0.0
for k in KEYS:
    DUR[k] = round(max(LEAD + durs[k] + TAIL, FIXED.get(k, 0)) + LANG.get(k, 0), 3); START[k] = round(t, 3); t += DUR[k]
TOTAL = round(t, 3)
json.dump({"START":START,"DUR":DUR,"TOTAL":TOTAL,"LEAD":LEAD,"PW":PW,"PH":PH,"LANG":LANG}, open(f"{W}/timing.json","w"), indent=1)
INK, CREAM, RED, PET = "#1A1A1A", "#F7F4EF", "#c73937", "#245B6B"
FIX = json.load(open(f"{W}/fix.json")) if os.path.exists(f"{W}/fix.json") else {}

def icon(name):
    s = open(f"{W}/assets/{name}.svg").read()
    s = re.sub(r"<!--.*?-->", "", s, flags=re.S).strip(); s = re.sub(r'\s(width|height)="24"', "", s, count=2)
    s = s.replace("<svg", '<svg class="ico"', 1); assert 'class="ico"' in s and "<path" in s, name; return s

WJ = json.load(open(f"{W}/words.json")) if os.path.exists(f"{W}/words.json") else {}
CAPS = json.load(open(f"{W}/captions.json")) if os.path.exists(f"{W}/captions.json") else []
def cues(key, cuts):
    txt, dur, pa = vo[key], durs[key], pauses[key]; res, pos = [], 0
    ww = WJ.get("words", {}).get(key) if WJ.get("nguon") == "whisper" else None  # mốc từ thật từ whisper (make_srt.py)
    if ww is not None and len(ww) != len(txt.split()): ww = None
    for c in cuts:
        i = txt.find(c, pos); assert i >= 0, (key, c); pos = i
        if ww is not None:
            res.append(round(ww[len(txt[:i].split())][0], 2)); continue
        est = i / len(txt) * dur
        if i == 0: tt = 0.0
        else:
            cand = [b for a, b in pa if abs(b - est) < 0.55]; tt = min(cand, key=lambda b: abs(b - est)) if cand else est
        res.append(round(tt + LEAD, 2))
    return res
def seg_end(k): return round(LEAD + durs[k], 2)
def sub(a, d=0.12, lo=0.1): return max(lo, round(a - d, 2))

EV = {}; ALL = []
def archive():
    for k_, e_ in EV.items(): ALL.append((k_, e_))
    EV.clear()
def ev(sc, i, kind, t, **kw): EV[i] = dict(sc=sc, k=kind, t=round(START[sc] + t, 3), **kw)

def card(i, x, y, w, h, cls="", inner="", sh=16, bw=5):
    return f'<div class="card {cls}" id="{i}" data-sh="{sh}" style="left:{x}px;top:{y}px;width:{w}px;height:{h}px;border-width:{bw}px">{inner}</div>'
def ibox(i, x, y, s, name):
    return f'<div class="ibox" id="{i}" style="left:{x}px;top:{y}px;width:{s}px;height:{s}px"><div class="bw" style="width:64%;height:64%">{icon(name)}</div></div>'
def t_(i, x, y, s, cls="", style=""): return f'<div class="t {cls}" id="{i}" style="left:{x}px;top:{y}px;{style}">{s}</div>'
def chip(i, x, y, s, kind="pet", h=56): return f'<div class="chip {kind}" id="{i}" style="left:{x}px;top:{y}px;height:{h}px">{s}</div>'
def small_ibox(s, name, l=42, t=36): return f'<div class="abs ibx" style="left:{l}px;top:{t}px;width:{s}px;height:{s}px"><div class="bw" style="width:64%;height:64%">{icon(name)}</div></div>'
def mas(i, src, h, right, bottom_y):
    from PIL import Image
    w0, h0 = Image.open(f"{W}/assets/{src}.png").size; w = round(h * w0 / h0)
    return f'<img class="mas" id="{i}" src="assets/{src}.png" style="height:{h}px;width:{w}px;left:{right-w}px;top:{bottom_y-h}px">'

def row_dur(a, b): return max(.5, round(b - a - .5, 2))
def add_row(sc, i, a0, b):
    ev(sc, i, "land", a0, dy=60)
    EV[i]["bar"] = [round(START[sc] + a0 + .45, 3), row_dur(a0, b)]
    EV[i]["lift"] = [round(START[sc] + a0 + .45, 3), row_dur(a0, b)]
def H(s, size, color=None, extra=""):
    c = f"color:{color};" if color else ""
    return f'font-size:{size}px;{c}{extra}'

