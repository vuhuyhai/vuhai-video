#!/usr/bin/env python3
"""Tạo giọng VieNeu Thiện Minh, tăng tốc 1,3 bằng atempo. Dùng: VIENEU_DIR=<thư mục model> python3 gen_vo.py [khóa ...]
Không đối số = tạo tất cả. Có đối số = chỉ tạo lại các cảnh đó (sửa lời một vài cảnh)."""
import json, subprocess, os, sys
from vieneu import Vieneu
vo = json.load(open("vo.json")); only = sys.argv[1:] or list(vo)
VD = os.environ.get("VIENEU_DIR", "/home/claude/tts-test/m"); SPEED = os.environ.get("VO_SPEED", "1.3")
tts = Vieneu(onnx_dir=VD + "/onnx", codec_dir=VD + "/codec")
os.makedirs("audio", exist_ok=True)
for k in only:
    tts.save(tts.infer(vo[k], voice="Thiện Minh"), f"audio/{k}_raw.wav")
    subprocess.run(["ffmpeg","-y","-loglevel","error","-i",f"audio/{k}_raw.wav","-filter:a",f"atempo={SPEED}","-ar","24000","-ac","1",f"audio/{k}.wav"], check=True)
    print(k, flush=True)
