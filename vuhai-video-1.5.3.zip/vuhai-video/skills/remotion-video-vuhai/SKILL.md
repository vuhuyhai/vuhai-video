---
name: "remotion-video-vuhai"
description: "Biến một ý tưởng hoặc bài viết thành video 16:9 hoặc dọc 9:16 hoàn chỉnh cho Vũ Hải (H-OE): kịch bản, giọng VieNeu Thiện Minh 1,3, dựng bằng Playwright theo style Neo-Brutalism, banner có mascot, share copy, kiểm tự động. Dùng khi yêu cầu làm video cho bài này, dựng video motion hoặc video dọc cho Reels, TikTok, Shorts. Không dùng cho video quay thật."
---

# Video cho Vũ Hải (bản lõi v1.3)

Skill này là lớp đạo diễn. Nó nhận một ý tưởng hoặc bài viết, chốt mục tiêu và CTA với anh Hải, viết kịch bản theo nhịp, rồi giao phần kỹ thuật cho bộ công cụ `tools/`. Claude không tự bịa animation, không thêm chữ mà nguồn không có. Bản lõi này chỉ giữ luật cứng và thứ tự việc. Chi tiết nằm trong `references/`, chỉ mở tệp đúng bước đang làm. Các tệp `references/` và thư mục `tools/` nằm trong plugin `vuhai-video` (bản 1.3 trở lên): tìm bằng Glob `**/vuhai-video/**/<tên tệp>`. Chưa cài plugin bản 1.3 thì nói rõ với anh Hải, đừng tự dựng lại công cụ.

Hai mục tiêu của mọi video: (1) giữ người xem ở lại đến hết, (2) CTA hấp dẫn. CTA do anh Hải cung cấp, Claude không tự đặt.

## Thứ tự việc và tệp cần đọc

| Bước | Việc | Đọc |
|---|---|---|
| 0 | Nhận việc từ hàng đợi: `tools/dupcheck.py` loại việc trùng, đặt status `chay` | `references/duyet-giao.md` (mục Lưu và giao) |
| 1 | Chốt brief và CTA (bên dưới) | không cần |
| 2 | Kịch bản: `facts.md`, 3 hook, beat map, `cta.json` | `references/kich-ban.md`, `references/beat-map-template.md` |
| 2b | Khung mẫu duyệt trước: `make_video.py mau` ra `out/khung-mau.png` (hook, cảnh đáng nhớ nhất, CTA). Gửi anh Hải duyệt rồi mới dựng tiếp | `references/duyet-giao.md` |
| 3 | Dựng cảnh bằng khuôn Playwright | `references/dung-canh.md`, `references/mascot.md` (chỉ khi có mascot) |
| 4 | Giọng, nhạc, độ lớn | `references/am-thanh.md` |
| 5 | `verify.py`, `strip.py` (dải ảnh 0,2 giây), người chấm, banner, share copy, giao | `references/duyet-giao.md` |

Một lệnh chạy cả chuỗi dựng: `python3 tools/make_video.py` (giai đoạn vo, trim, srt, page, audit, audio, render, mux, verify, strip). Chỉ sửa vài cảnh thì thêm `--scenes s9,s10 --force`.

## Luật cứng về hình (anh Hải đã nhắc nhiều lần)

1. **Icon chỉ lấy từ file SVG thật của Tabler Icons** (`tabler/tabler-icons`), tải trong phiên và mở file kiểm tra. Cấm icon hoặc logo tự vẽ, cấm dùng chữ cái hay ký tự làm icon, cấm tự ghép logo từ hình cơ bản. Khái niệm không có icon khớp thì đổi khái niệm, dùng số lớn hoặc ảnh thật. Hàm `icon()` của khuôn bỏ chú thích, gắn `class="ico"`, đặt màu kem, và `assert` kết quả có `<path`.
2. **Không chữ hoặc icon tối trên nền đỏ `#c73937`**: luôn kem `#F7F4EF`. Viền và bóng đổ vẫn ink `#1A1A1A`. Chữ đỏ chỉ đặt trên nền kem hoặc trắng, không đặt trên nền tối (kể cả màu san hô).
3. **Chữ không sát viền thẻ.** Đệm tối thiểu: ngang 38px, trên 32px, dưới 40px ở khung ngang 1920x1080; 30px mỗi phía ở khung dọc 1080x1920; đệm dưới không nhỏ hơn đệm trên; chữ cạnh ô icon cách ít nhất 24px; chip và nhãn đệm ngang ít nhất 20px. Thẻ dựng bằng flex có `padding` để chiều cao tự giãn theo chữ (hàm `fc()` của khuôn). Hết chỗ thì tăng chiều cao thẻ, giảm số dòng hoặc tách thẻ, không thu chữ dưới cỡ tối thiểu. `audit.py` đo bằng số và tự nới thẻ (`audit.py --fix`), phải ra 0 vi phạm.

## Luật nội dung và ngôn ngữ
- Không dùng dấu gạch dài (U+2014) ở bất kỳ đâu.
- Từ cấm: kiến tạo, lan tỏa, nâng tầm, truyền cảm hứng, cuộc cách mạng, bùng nổ doanh thu, bí quyết, công thức, tăng trưởng đột phá, kinh hoàng, bóc phốt, sốc, bí mật. Các câu thương hiệu đã bỏ (Phân vai, không phân hạng; Vận hành Xuất sắc lấy con người làm trung tâm; Người kiến tạo hệ thống) không được xuất hiện.
- "Đi cùng", không "đi theo". Hệ thống "đỡ" con người, không "nâng", không "bẻ". Nếu ai đọc cũng gật đầu thì câu đó rỗng, viết cụ thể hơn.
- Câu ngắn, từ thông dụng, chủ động, không thêm ý, không tô màu cảm xúc. Chữ và số trên màn hình chỉ lấy từ `facts.md`.
- Mỗi video: 3 hook (dùng 1, hai bản dự phòng vào `hook-options.md`, hook dưới 15 từ); banner có mascot với ĐÚNG 1 thông điệp và ĐÚNG 1 hook, dựng bằng một trong 3 mẫu A, B, C của `tools/banner.py`; `share-copy.txt`; giọng đọc ở mọi cảnh; đo độ lớn; xem khung từ chính file MP4; người chấm độc lập.
- Giọng VieNeu Thiện Minh 1,3. Màu nền kem #F7F4EF, ink #1A1A1A, đỏ #c73937, petrol #245B6B. Font Space Grotesk, Inter, JetBrains Mono. Mascot chỉ dùng ảnh PNG nền trong suốt của anh Hải, tối đa một nửa số cảnh, không lặp tư thế ở hai cảnh liền nhau.
- Cảnh cuối có CTA và khối liên hệ (VŨ HẢI, 0344 444 000, fitnessviet@gmail.com, facebook.com/vuhai.fitness, vuhuyhai.com, Human first. Profit follows.) khi khớp với CTA.

## Bước 1, chốt brief

Hỏi gọn, một lượt, tối đa 4 câu:

- Chủ đề hoặc nguồn (bài viết, ý thô, dữ liệu)?
- Thời lượng (mặc định 60 tới 90 giây ngang, 30 tới 60 giây dọc)?
- Có giọng đọc không, hay chỉ chữ chuyển động cộng nhạc nền?
- **CTA của video này là gì?**

**CTA là đầu vào bắt buộc do Vũ Hải cung cấp trước khi làm video.** Nó gồm bốn thứ:

1. Người xem làm gì (một việc duy nhất).
2. Làm ở đâu (link, bình luận, tin nhắn, lưu video, theo dõi).
3. Họ nhận được gì khi làm (món cho trước: tài liệu, checklist, buổi tư vấn, hoặc chỗ trong khóa học).
4. Hạn hoặc lý do làm ngay, chỉ khi hạn đó là thật (ví dụ ngày khai giảng).

Quy tắc về CTA:

- Claude **không tự đặt** ưu đãi, tên sản phẩm, tên tài liệu, số chỗ hay hạn. Thiếu thứ nào thì hỏi, một lần, trong cùng lượt hỏi brief.
- Chọn một mục tiêu CTA: lưu, bình luận lấy tài liệu, theo dõi, bấm link, hoặc nhắn tin. CTA phải khớp mục tiêu thật của video, không phải lúc nào cũng là lời mời mua hàng.
- Nếu Vũ Hải đã đưa nguồn và bảo dựng luôn mà chưa có CTA, dùng CTA trung tính ("đọc bài đầy đủ ở link"), ghi rõ ở đầu bài giao là chưa có CTA thật, và đề nghị dựng lại cảnh cuối khi anh gửi CTA.
- Khi anh gửi CTA, giữ nguyên văn lời anh dùng trên màn hình và trong lời đọc. Chỉ đổi cách viết số và từ viết tắt thành dạng đọc được.

Nếu Vũ Hải đã đưa nguồn và bảo dựng luôn, thì làm luôn, ghi rõ ở đầu bài giao là đã hiểu yêu cầu thế nào. Không hỏi thêm khi câu trả lời không đổi cách dựng.

Khi Vũ Hải vắng mặt hoặc nói "cứ làm", Claude tự quyết mọi chỗ còn mở, không dừng lại hỏi, rồi ghi các quyết định đã chọn ở cuối bài giao để anh sửa nếu muốn. Chỉ dừng lại hỏi với việc không làm lại được hoặc rất tốn thời gian.

## Giới hạn, nói thẳng

- Skill mạnh về chữ chuyển động, biểu đồ, số lớn, icon, sơ đồ, ghép ảnh và clip có sẵn theo nhịp. Không dựng được cảnh quay mới hay diễn viên thật. Ngoại lệ: nhân vật mascot Vũ Hải là bộ ảnh có sẵn của anh, được tách nền rồi ghép vào một số cảnh theo mục "Nhân vật mascot Vũ Hải", không dựng lại bằng code.
- Giọng đọc là giọng tổng hợp, không thay được người thật. Muốn giọng thật thì thu âm riêng, skill chỉ khóa đúng timecode để ghép vào.
- Claude không nghe được audio. Việc kiểm tra giọng chỉ dựa trên độ dài, mức tiếng, chữ (và whisper nếu có). Luôn nhờ Vũ Hải nghe lại các chỗ có số.
- Tách nền ảnh nhân vật áo đen trên nền đen là bước bán tự động, cần xem từng ảnh và có thể phải bù tay bằng hình chữ nhật. Nói rõ khi giao nếu còn mép chưa sạch.
- Nói trước nếu video là nội dung mẫu chưa lấy từ bài của Vũ Hải.
- Skill không đo được tỷ lệ giữ chân thật. Các nguyên tắc giữ chân và CTA dựa trên tài liệu trong kho Content Marketing của Vũ Hải, và chỉ kiểm được bằng số liệu thật sau khi đăng. Vì vậy có 3 hook để thử, và nên ghi tỷ lệ xem qua 3 giây của từng hook vào `INDEX.md` khi có.
- Claude không tự đặt CTA, ưu đãi, hạn hay số chỗ. Thiếu thì hỏi, hoặc dùng CTA trung tính và ghi rõ.

## Giao và báo cáo
Giao một lần khi đã qua `verify.py` (0 lỗi P0) và người chấm độc lập. Báo thẳng điều chưa làm: chưa nghe thử bằng tai, chưa chấm độc lập, CTA trung tính nếu chưa có CTA thật. Khi anh Hải vắng mặt hoặc nói "cứ làm": tự quyết mọi chỗ còn mở, ghi các quyết định ở cuối bài giao, chỉ dừng với việc không làm lại được.

## Tệp tham chiếu
`references/`: kich-ban.md, beat-map-template.md, dung-canh.md, mascot.md, am-thanh.md, duyet-giao.md, ngon-ngu-vuhai.md, photo-scenes.md (cảnh dùng ảnh thật), engines-khac.md (Hyperframes, Remotion, chỉ khi anh yêu cầu). Thư mục `_cu/` là tài liệu cũ, không nạp.
