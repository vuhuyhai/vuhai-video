#!/usr/bin/env python3
"""Ghép khung hình + mix/final.wav thành MP4, thay đúng khung 0 bằng banner (khung f00000 được ghi đè bằng banner trước khi mã hóa).
Dùng: python3 mux.py out/ten-video.mp4 [banner.png]"""
import sys, json, os, subprocess
T = json.load(open("timing.json")); PW, PH = T.get("PW", 1080), T.get("PH", 1920)
out = sys.argv[1]; banner = sys.argv[2] if len(sys.argv) > 2 else None
ext = open("frames/EXT").read().strip() if os.path.exists("frames/EXT") else "png"
os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
if banner and os.path.exists(banner):
    # thay khung 0 bằng banner ngay trong thư mục khung (qua Pillow, màu đúng; lọc overlay của ffmpeg làm lệch dải màu)
    from PIL import Image
    b0 = Image.open(banner).convert("RGB")
    if abs(b0.width / b0.height - PW / PH) > 0.01:   # banner 16:9 trong video dọc: đặt giữa nền kem, không kéo méo
        s = min(PW / b0.width, PH / b0.height); b1 = b0.resize((round(b0.width * s), round(b0.height * s)), Image.LANCZOS)
        im = Image.new("RGB", (PW, PH), (247, 244, 239)); im.paste(b1, ((PW - b1.width) // 2, (PH - b1.height) // 2))
    else: im = b0.resize((PW, PH), Image.LANCZOS)
    im.save(f"frames/f00000.{ext}", quality=95) if ext == "jpg" else im.save(f"frames/f00000.{ext}")
cmd = ["ffmpeg","-y","-loglevel","error","-framerate","30","-i",f"frames/f%05d.{ext}","-i","mix/final.wav","-map","0:v","-map","1:a","-c:v","libx264","-crf","20","-pix_fmt","yuv420p","-c:a","aac","-b:a","192k","-t",str(T["TOTAL"]),"-movflags","+faststart",out]
subprocess.run(cmd, check=True); print(out, round(os.path.getsize(out)/1e6, 1), "MB")
