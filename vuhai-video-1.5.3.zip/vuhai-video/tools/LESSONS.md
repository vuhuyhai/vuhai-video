# Bài học các lỗi đã mắc (phiên làm Buổi 2 đến 5, bản 1.4.0)

1. Bỏ kênh alpha của ảnh anh Hải gửi (`convert("RGB")`) rồi tách nền lại. Hậu quả: quầng, thủng áo, giày rách. Cách đúng: dùng alpha gốc, `tools/mascot_from_alpha.py`.
2. Tin vào khung xem chat (alpha hiện màu đen). Cách đúng: đọc `im.mode` và số điểm alpha = 0.
3. Giao mascot sau khi chỉ xem ảnh nhỏ trên nền kem. Cách đúng: phóng to, soi trên nền đỏ và nền kem trước khi giao.
4. Ảnh hai nhân vật đè tiêu đề ở mẫu B. Cách đúng: dùng mẫu C và msg ngắn.
5. Chạy mux 12 video ở tiền cảnh bị quá 10 phút. Cách đúng: nohup và đọc log.
6. Giao file về máy: vượt 100 MB, sai fileUuid, sai stagedPath của zip, unzip đè không được, tên file lệch dấu. Xem checklist trong quy-trinh-render-vuhai.
7. Người chấm model nhỏ báo sai. Lấy khung từ MP4 làm căn cứ.
8. Thẻ hẹp cắt mascot, đuôi âm thanh P0, CTA đọc tên bị Whisper chấm thấp: xem các mục 1.3.x trong CHANGELOG.
9. make_video.py chạy giọng bằng Python hệ thống nên báo thiếu `vieneu`. Cách đúng: dùng Python của venv (đã sửa ở 1.5.0).
10. `audit.py --fix` ghi fix.json nhưng khuôn trang không đọc nên vòng sửa vô tác dụng. Đã sửa ở 1.5.0.
11. Chụp khung mẫu sát cuối cảnh bắt trúng lúc mờ dần. Chụp ở khoảng 60 phần trăm cảnh hoặc cách cuối 1,2 giây.
