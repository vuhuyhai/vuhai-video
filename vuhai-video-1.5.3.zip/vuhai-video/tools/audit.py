import os
import json, sys
from playwright.sync_api import sync_playwright
T=json.load(open("timing.json")); S,D=T["START"],T["DUR"]
JS="""()=>{const out=[];
document.querySelectorAll('.card').forEach(c=>{
 if(getComputedStyle(c).opacity==='0'||c.getBoundingClientRect().width<5)return;
 const cr=c.getBoundingClientRect(), bw=parseFloat(getComputedStyle(c).borderLeftWidth)||5;
 const L=cr.left+bw,R=cr.right-bw,Tp=cr.top+bw,B=cr.bottom-bw;
 let l=1e9,r=-1e9,t=1e9,b=-1e9,n=0;
 const add=(rc)=>{if(rc.width<1||rc.height<1)return;l=Math.min(l,rc.left);r=Math.max(r,rc.right);t=Math.min(t,rc.top);b=Math.max(b,rc.bottom);n++};
 const w=document.createTreeWalker(c,NodeFilter.SHOW_TEXT);let x;
 while(x=w.nextNode()){if(!x.textContent.trim())continue;const e=x.parentElement;if(e.closest('.bar'))continue;if(parseFloat(getComputedStyle(e).fontSize)>=200)continue;const g=document.createRange();g.selectNodeContents(x);for(const rc of g.getClientRects())add(rc);}
 c.querySelectorAll('.ibx,svg,img').forEach(e=>{if(!e.closest('.ibx')||e.classList.contains('ibx'))add(e.getBoundingClientRect())});
 if(n)out.push({top:parseFloat(c.style.top),id:c.id,gl:l-L,gr:R-r,gt:t-Tp,gb:B-b,h:Math.round(B-Tp)});
});return out}"""
bad=0; fx={}; rows={}
with sync_playwright() as p:
    b=p.chromium.launch(args=["--allow-file-access-from-files"]); pg=b.new_page(viewport={'width':T.get('PW',1080),'height':T.get('PH',1920)})
    pg.goto('file://'+os.path.abspath('index.html')); pg.evaluate("document.fonts.ready"); pg.wait_for_timeout(700)
    for k in S:
        pg.evaluate(f"setT({S[k]+D[k]-0.15})")
        for c in pg.evaluate(JS):
            m=min(c['gl']-6,c['gt']-2,c['gb']-4)
            flag = m<30; fx[c['id']]=[0,0,max(0,round(2*max(32-c['gt'],40-c['gb'])))]  # thẻ flex căn giữa: thêm d thì mỗi phía thêm d/2
            if flag or '-v' in sys.argv: print(("BAD " if flag else "ok  ")+k, c['id'], {x:round(c[x]) for x in('gl','gr','gt','gb','h')})
            bad+=flag; rows.setdefault((k,c['top']),[]).append(c['id'])
    b.close()
print("violations",bad)
for ids in rows.values():
    ids=[i for i in ids if i in fx]
    if len(ids)>1:
        m=[max(fx[i][q] for i in ids) for q in range(3)]
        for i in ids: fx[i]=list(m)
if "--fix" in sys.argv: json.dump({k:v for k,v in fx.items() if any(v)},open("fix.json","w"))
