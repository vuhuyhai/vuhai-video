#!/usr/bin/env python3
"""Cắt khoảng lặng đầu và cuối mỗi file giọng. Sinh audio/<k>_t.wav, durs_t.json, pauses.json.
v1.3: sửa lỗi cắt mất từ cuối. Chỉ cắt đuôi khi khoảng lặng cuối kéo dài tới hết file,
không lấy một quãng nghỉ giữa câu làm đuôi. Cuối clip luôn chừa 0,12 giây yên lặng.
Dùng: python3 trim_vo.py [khóa cảnh ...]  (bỏ trống = tất cả)"""
import json, subprocess, re, sys
vo = json.load(open("vo.json")); keys = sys.argv[1:] or list(vo)
try: out = json.load(open("durs_t.json")); sil = json.load(open("pauses.json"))
except Exception: out, sil = {}, {}
NOISE, MIN_D, PAD_HEAD, PAD_TAIL = "-38dB", 0.10, 0.05, 0.12
def dur(p): return float(subprocess.check_output(["ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0",p]).decode())
for k in keys:
    p = f"audio/{k}.wav"; total = dur(p)
    r = subprocess.run(["ffmpeg","-i",p,"-af",f"silencedetect=noise={NOISE}:d={MIN_D}","-f","null","-"],capture_output=True,text=True).stderr
    s = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", r)]
    e = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", r)]
    # lặng đầu: bắt đầu từ 0
    head_end = e[0] if s and s[0] < 0.02 and e else 0.0
    # lặng cuối: có start mà không có end tương ứng, hoặc end sát hết file
    tail_start = None
    if s and (len(s) > len(e) or (e and e[-1] >= total - 0.03)):
        tail_start = s[-1]
    t0 = max(0.0, head_end - PAD_HEAD)
    t1 = min(total, (tail_start + PAD_TAIL) if tail_start is not None else total)
    assert t1 - t0 > 0.3, (k, t0, t1, total)
    subprocess.run(["ffmpeg","-y","-loglevel","error","-i",p,"-ss",f"{t0:.3f}","-to",f"{t1:.3f}",f"audio/{k}_t.wav"], check=True)
    out[k] = round(t1 - t0, 3)
    sil[k] = [(round(a - t0, 3), round(b - t0, 3)) for a, b in zip(s, e) if a > t0 + 0.1 and b < t1 - 0.05]
order = list(vo)
out = {k: out[k] for k in order if k in out}; sil = {k: sil[k] for k in order if k in sil}
json.dump(out, open("durs_t.json","w"), indent=1); json.dump(sil, open("pauses.json","w"))
print(out, round(sum(out.values()), 2))
