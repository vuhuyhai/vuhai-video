---
name: "quy-trinh-render-vuhai"
description: "Chạy đường dựng Playwright cho video của Vũ Hải bằng bộ công cụ v1.3: một lệnh make_video.py chạy giọng VieNeu, đệm chữ, âm, render, ghép MP4 và kiểm tự động. Dùng khi dựng, render lại, sửa một vài cảnh, ghép âm hoặc kiểm tra video Phòng gym, GDTC và các video cùng khuôn."
---

# Quy trình render Playwright (v1.3)

Đọc `remotion-video-vuhai` trước để chốt kịch bản và luật hình. Skill này chỉ nói cách chạy máy. Mọi lệnh chạy trong thư mục video; công cụ nằm ở `tools/` của plugin.

## Một lệnh
```
python3 tools/make_video.py                      # cả chuỗi
python3 tools/make_video.py page audit audio render mux verify --scenes s9,s10 --force   # chỉ sửa vài cảnh
```
Giai đoạn: `vo` (giọng VieNeu, nền), `trim` (cắt lặng, đã sửa lỗi cắt mất từ cuối), `page` (khuôn + scenes.py thành index.html và timing.json), `audit` (đệm chữ, tự nới thẻ tới 0 vi phạm), `audio` (ghép giọng, nhạc, trộn, loudnorm -14 LUFS), `render` (JPEG 95, 2 tiến trình, xếp hàng qua /tmp/render.lock), `mux` (banner thay khung 0 trong một lượt), `verify` (kiểm tự động, ra contact.png và phone.png cho người chấm). Giai đoạn đã có kết quả mới hơn đầu vào thì tự bỏ qua.

## Việc cần có trong thư mục video
`vo.json`, `video.json` (name, title, size, fixed, dark, procs), `cta.json` (must, share), `scenes.py`, `banner.json`, `assets/` (mascot PNG nền trong suốt, icon Tabler SVG), `fonts/`. Mẫu: `tools/template/scenes_example.py`. Cần Python 3, playwright và Chromium, Pillow, numpy, ffmpeg, model VieNeu (biến `VIENEU_DIR`).

## Lưu ý
- Sửa lời đọc một cảnh: `python3 tools/gen_vo.py s5` rồi `python3 tools/trim_vo.py s5`, sau đó chạy lại từ `page`.
- Đổi CTA: chỉ sửa cảnh cuối và `cta.json`, tạo lại giọng cảnh cuối, chạy lại `page audit audio render mux verify --scenes <cảnh cuối> --force`.
- Không dùng `rm -rf frames/*` (bị chặn), render ghi đè tại chỗ.
- Chờ render bằng `sleep` dưới 120 giây, không chặn. Đọc log, không đoán.
- `verify.py` thoát khác 0 khi còn lỗi P0. Chỉ giao khi 0 lỗi P0, rồi báo thẳng điều chưa làm (chưa nghe thử, chưa chấm độc lập).
- Giao bằng SendUserFile kèm tên file và số giây. Lưu vào `video\<ngày>-<tên>\` trên máy anh; không nối được thì nói rõ chưa lưu.

## Việc chạy dài và giao file về máy anh (rút từ lỗi phiên 1.4.0)
- Một lệnh chạy nền tối đa 10 phút. Mux + verify mất khoảng 2,5 phút mỗi video, nên làm nhiều video thì chạy `nohup bash script.sh > out 2>&1 &` rồi đọc log mỗi lần dưới 120 giây. Không để lệnh dài chạy ở tiền cảnh.
- Sau khi đổi mascot, chạy lại `render --scenes s1` rồi `mux verify` cho từng video. Banner mới không tự vào MP4.
- Giao về máy bằng `device_commit_files`: tối đa 100 MB mỗi lần gọi; `fileUuid` lấy từ kết quả SendUserFile (chép đúng, soi lại từng ký tự); file trong `/mnt/user-data/outputs/<thư mục>/` dùng `stagedPath`, riêng file zip gói nằm ở gốc `/mnt/user-data/outputs/`.
- Máy anh không cho xóa, nên `unzip -o` đè lên file cũ sẽ lỗi "cannot delete old". Ghi đè bằng cách commit từng file.
- Tên file có dấu tiếng Việt: liệt kê bằng `os.listdir` rồi dùng đúng chuỗi đó, không gõ lại bằng tay (dấu có thể khác dạng Unicode).
- Giao đủ cả bộ: MP4, thumbnail, hook, share-copy, thứ tự video. Đừng chỉ commit MP4 rồi để thumbnail và văn bản bản cũ trên máy.
- Người chấm tự động bằng model nhỏ từng báo sai. Khung lấy từ MP4 là căn cứ cuối.

