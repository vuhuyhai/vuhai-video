#!/usr/bin/env python3
"""Chụp khung hình bằng Playwright. JPEG chất lượng 95 (nhẹ hơn PNG nhiều), chạy song song, chụp theo đoạn.
Dùng: python3 render.py [số tiến trình=2] [--ext jpg|png] [--scenes s9,s10] [--from giây] [--to giây]
Mặc định chụp toàn bộ. --scenes chỉ chụp các cảnh đó (cộng 0,4 giây chuyển cảnh hai đầu), dùng khi chỉ sửa vài cảnh.
Kích thước lấy từ timing.json (PW, PH), mặc định 1080x1920."""
import sys, json, os
from multiprocessing import Pool
from playwright.sync_api import sync_playwright
T = json.load(open("timing.json")); TOTAL = T["TOTAL"]; N = int(TOTAL * 30) + 1
PW, PH = T.get("PW", 1080), T.get("PH", 1920)
def arg(name, default=None):
    return sys.argv[sys.argv.index(name) + 1] if name in sys.argv else default
EXT = arg("--ext", "jpg")
def work(rng):
    a, b = rng
    with sync_playwright() as p:
        br = p.chromium.launch(args=["--allow-file-access-from-files"]); pg = br.new_page(viewport={'width': PW, 'height': PH})
        pg.goto('file://' + os.path.abspath('index.html')); pg.evaluate("document.fonts.ready"); pg.wait_for_timeout(700)
        for n in range(a, b):
            pg.evaluate(f"setT({n/30})")
            if EXT == "jpg": pg.screenshot(path=f"frames/f{n:05d}.jpg", type="jpeg", quality=95)
            else: pg.screenshot(path=f"frames/f{n:05d}.png")
        br.close()
    return b
def ranges():
    sc = arg("--scenes")
    if sc:
        out = []
        for k in sc.split(","):
            a = max(0, int((T["START"][k] - 0.4) * 30)); b = min(N, int((T["START"][k] + T["DUR"][k] + 0.4) * 30) + 1); out.append((a, b))
        return out
    return [(int(float(arg("--from", 0)) * 30), min(N, int(float(arg("--to", TOTAL)) * 30) + 1))]
if __name__ == "__main__":
    k = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 2
    os.makedirs("frames", exist_ok=True); open("frames/EXT", "w").write(EXT)
    jobs = []
    for a, b in ranges():
        step = max(1, (b - a + k - 1) // k); jobs += [(i, min(b, i + step)) for i in range(a, b, step)]
    with Pool(k) as pool: pool.map(work, jobs)
    print("xong", sum(b - a for a, b in jobs), "khung", EXT)
