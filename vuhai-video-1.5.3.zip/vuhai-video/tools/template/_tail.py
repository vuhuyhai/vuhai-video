CAP_MODE = CFG.get('captions', 'srt')
CAP_FS = CFG.get('caption_font', 46 if PH > PW else 40)
CAP_BOTTOM = CFG.get('caption_bottom', 440 if PH > PW else 90)
archive()
def css():
    return f"""
:root{{--cream:{CREAM};--ink:{INK};--red:{RED};--pet:{PET}}}
*{{box-sizing:border-box;margin:0;padding:0}}
body{{width:{PW}px;height:{PH}px;overflow:hidden;background:{CREAM};font-family:'Inter';font-weight:500;color:{INK};position:relative}}
.nen{{position:absolute;inset:0;opacity:.11;background-image:linear-gradient({INK} 2px,transparent 2px),linear-gradient(90deg,{INK} 2px,transparent 2px);background-size:130px 130px}}
.sc{{position:absolute;left:0;top:0;width:{PW}px;height:{PH}px;overflow:hidden;background:{CREAM}}}
.sc.dark{{background:{INK};color:{CREAM}}}
.sc.dark .nen{{opacity:.09;background-image:linear-gradient({CREAM} 2px,transparent 2px),linear-gradient(90deg,{CREAM} 2px,transparent 2px)}}
.abs{{position:absolute}}
.card{{position:absolute;background:#fff;border:5px solid {INK};border-radius:4px;overflow:hidden;opacity:0}}
.card.fx{{display:flex;align-items:center;gap:28px;padding:34px 40px}}
.col{{display:flex;flex-direction:column;justify-content:center;gap:8px;min-width:0;flex:1}}
.lab{{font-family:'JetBrains Mono';font-weight:700;font-size:32px;letter-spacing:.02em;line-height:1.15}}
.tt{{font-family:'Space Grotesk';font-weight:700;letter-spacing:-.02em;line-height:1.06}}
.bd{{font-family:'Inter';font-weight:700;line-height:1.22}}
.rd{{color:{RED}}}
.ibx{{flex:none}}
.card.red .ibx,.card.pet .ibx{{background:{INK}}}
.card.red{{background:{RED};color:{CREAM}}} .card.pet{{background:{PET};color:{CREAM}}} .card.cream{{background:{CREAM};color:{INK}}}
.ibox{{position:absolute;background:{RED};border:5px solid {INK};border-radius:4px;display:flex;align-items:center;justify-content:center;opacity:0}}
.ibx{{background:{RED};border:5px solid {INK};border-radius:4px;display:flex;align-items:center;justify-content:center}}
.sc.dark .ibox{{background:{CREAM}}} .sc.dark .ibox .ico{{color:{INK}}}
.bw{{display:block}} .ico{{width:100%;height:100%;display:block;color:{CREAM}}}
.t{{position:absolute;white-space:nowrap;line-height:1.05;opacity:0}}
.h{{font-family:'Space Grotesk';font-weight:700;letter-spacing:-.02em}} .m{{font-family:'JetBrains Mono';font-weight:700;letter-spacing:.02em}}
.chip{{position:absolute;display:flex;align-items:center;padding:0 20px;border:3px solid {INK};border-radius:4px;font-family:'JetBrains Mono';font-weight:700;font-size:36px;letter-spacing:.03em;white-space:nowrap;opacity:0}}
.chip.pet{{background:{PET};color:{CREAM}}} .chip.cr{{background:{CREAM};color:{INK}}} .chip.red{{background:{RED};color:{CREAM}}}
.card .chip{{opacity:1}}
.nm{{left:28px;top:30px;width:62px;height:62px;background:{RED};color:{CREAM};border:3px solid {INK};display:flex;align-items:center;justify-content:center;font-family:'JetBrains Mono';font-weight:700;font-size:32px}}
.bar{{position:absolute;left:0;bottom:0;height:10px;width:100%;background:{PET};transform-origin:0 50%;transform:scaleX(0)}}
.card.red .bar,.card.pet .bar{{background:{CREAM}}}
.rl{{position:absolute;height:6px;background:{INK};opacity:.25}} .rf{{position:absolute;height:6px;background:{INK}}}
.rn{{position:absolute;width:28px;height:28px;border:4px solid {INK};background:{CREAM};border-radius:2px}} .rn.past{{background:{INK}}} .rn.act{{background:{RED}}}
.rt{{position:absolute;width:140px;font-family:'JetBrains Mono';font-weight:700;font-size:30px;white-space:nowrap}} .rt.fut{{color:#5C5A57}} .rt.act{{color:{RED}}}
.strike{{position:absolute;background:{RED};transform-origin:0 50%;transform:scaleX(0)}}
img.mas{{position:absolute;opacity:0}}
#fade{{position:absolute;inset:0;background:{INK};opacity:0;pointer-events:none}}
#cap{{position:absolute;left:80px;width:{PW-160}px;bottom:{CAP_BOTTOM}px;background:{CREAM};color:{INK};border:5px solid {INK};border-radius:4px;box-shadow:10px 10px 0 {INK};padding:30px 38px 34px;font-family:'Inter';font-weight:700;font-size:{CAP_FS}px;line-height:1.28;opacity:0;text-align:left;z-index:50}}
#cap .w{{color:{INK}}} #cap .w.on{{color:{RED}}}
"""
VI = "U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB"
LA = "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD"
FF = ""
for fam, base, wts in [("Space Grotesk","space-grotesk",[700]),("Inter","inter",[500,700]),("JetBrains Mono","jetbrains-mono",[700])]:
    for w in wts:
        for ss, rg in [("vietnamese",VI),("latin",LA)]:
            FF += f'@font-face{{font-family:"{fam}";font-weight:{w};font-display:block;src:url("fonts/{base}-{ss}-{w}-normal.woff2") format("woff2");unicode-range:{rg}}}\n'
scenes = ""
for k in KEYS:
    dark = " dark" if k in DARK else ""
    body = re.sub(r'id="([^"]+)"', lambda m: f'id="{k}_{m.group(1)}"', SC[k])
    scenes += f'<div class="sc{dark}" id="{k}"><div class="nen"></div>{body}</div>\n'
EV2 = {}
for i_, e_ in ALL:
    e_ = dict(e_); sc_ = e_["sc"]
    for f_ in ("barid", "id", "node"):
        if f_ in e_: e_[f_] = f"{sc_}_{e_[f_]}"
    EV2[f"{sc_}_{i_}"] = e_
EV = EV2
CAP_HTML = '<div id="cap"></div>' if CAP_MODE == 'burn' and CAPS else ''
scdef = {k: [START[k], round(START[k] + DUR[k], 3)] for k in KEYS}
html = f"""<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>{TITLE}</title><style>{FF}{css()}</style></head><body>
{scenes}
<div id="fade"></div>
{CAP_HTML}
<script>
const EV={json.dumps(EV, ensure_ascii=False)};
const CAPS={json.dumps(CAPS if CAP_MODE == 'burn' else [], ensure_ascii=False)};
const SCD={json.dumps(scdef)};const KEYS={json.dumps(KEYS)};const TOTAL={TOTAL};
const clamp=(x,a=0,b=1)=>Math.min(b,Math.max(a,x));
const oc=x=>1-Math.pow(1-clamp(x),3);
const ob=x=>{{x=clamp(x);const c=1.2,k=c+1;return 1+k*Math.pow(x-1,3)+c*Math.pow(x-1,2)}};
const $=id=>document.getElementById(id);const T=0.14;
function px(i,t){{const [a,b]=SCD[KEYS[i]];let x=0;if(i>0&&t<a+T)x={PW}*(1-oc((t-a)/T));if(i<KEYS.length-1&&t>=b)x=-{PW}*oc((t-b)/T);if(i>0&&t<a)x={PW};if(i<KEYS.length-1&&t>b+T)x=-{PW};return x}}
function setT(t){{
 KEYS.forEach((k,i)=>{{const x=px(i,t);const s=$(k);s.style.transform=`translateX(${{x}}px)`;s.style.display=Math.abs(x)>={PW}?'none':'block';s.querySelector('.nen').style.backgroundPosition=`${{-t*26}}px ${{t*15}}px`;}});
 for(const id in EV){{const e=EV[id];const el=$(id);if(!el&&e.k!=='rail')continue;const u=t-e.t;
  if(e.k==='land'){{const p=ob(u/.45);el.style.opacity=u<0?0:1;let tx=0;if(e.lift){{const [l0,ld]=e.lift;const q=t-l0;tx=q<0?0:(q<.2?14*oc(q/.2):(q<ld-.2?14:14*(1-clamp((q-(ld-.2))/.2))))}}
    el.style.transform=`translate(${{tx}}px,${{(1-p)*e.dy}}px)`;const sp=oc((u-.35)/.2);const sh=+el.dataset.sh;el.style.boxShadow=`${{sh*sp}}px ${{sh*sp}}px 0 ${{INKC}}`;
    if(e.bar){{const b=$(e.barid||e.id+'b');if(b){{const q=(t-e.bar[0])/e.bar[1];b.style.transform=`scaleX(${{clamp(q)}})`}}}}}}
  else if(e.k==='rev'){{el.style.opacity=u<0?0:oc(u/.4);el.style.transform=`translateY(${{(1-oc(u/.4))*e.dy}}px)`}}
  else if(e.k==='tag'){{const p=ob(u/.35);el.style.opacity=u<0?0:1;el.style.transform=`scale(${{.7+.3*p}})`}}
  else if(e.k==='pop'){{const p=ob(u/.4);el.style.opacity=u<0?0:1;el.style.transform=`scale(${{.6+.4*p}})`}}
  else if(e.k==='slam'){{const p=ob(u/.45);el.style.opacity=u<0?0:1;el.style.transform=`scale(${{1.28-.28*p}})`;el.style.transformOrigin='0 50%'}}
  else if(e.k==='strike'){{el.style.transform=`scaleX(${{oc(u/.3)}})`}}
  else if(e.k==='mas'){{const p=ob(u/.5);el.style.opacity=u<0?0:clamp((SCD[e.sc][1]-t)/.12);el.style.transform=`translateY(${{(1-p)*e.dy+Math.sin(t*2.6)*6}}px)`}}
  else if(e.k==='rail'){{const f=$(e.id);f.style.width=(e.a+(e.b-e.a)*oc(u/.6))+'px';const n=$(e.node);n.style.transform=`scale(${{1+.45*ob((u-.25)/.4)}})`}}
 }}
 if(CAPS.length){{const cp=$('cap');let ci=-1;for(let q=0;q<CAPS.length;q++)if(t>=CAPS[q].t0-.03&&t<CAPS[q].t1){{ci=q;break}}
  if(ci<0){{cp.style.opacity=0}}else{{if(cp.dataset.i!==String(ci)){{cp.dataset.i=ci;cp.innerHTML=CAPS[ci].words.map((w,n)=>`<span class="w" data-n="${{n}}">${{w[0]}}</span>`).join(' ')}}
   cp.style.opacity=1;const ws=CAPS[ci].words;cp.querySelectorAll('.w').forEach((e,n)=>e.classList.toggle('on',t>=ws[n][1]&&t<ws[n][2]))}}}}
 {{const fe=SCD[KEYS[KEYS.length-1]][1];$('fade').style.opacity=clamp((t-(fe-.45))/.45)}}
 document.querySelectorAll('.bw').forEach((e,i)=>e.style.transform=`translateY(${{Math.sin(t*3.2+i)*3}}px)`);
}}
const FIX={json.dumps(FIX)};
document.querySelectorAll('.sc').forEach(sc=>{{
 const L=[...sc.children].filter(e=>!e.classList.contains('nen')&&!e.classList.contains('mas')&&e.style.top).map(e=>{{const t=parseFloat(e.style.top);return {{e,l:parseFloat(e.style.left)||0,r:(parseFloat(e.style.left)||0)+(parseFloat(e.style.width)||e.offsetWidth),t,b:t+(parseFloat(e.style.height)||e.offsetHeight),dh:(FIX[e.id]||[0,0,0])[2],s:0}}}}).sort((p,q)=>p.t-q.t);
 L.forEach((q,i)=>{{for(let j=0;j<i;j++){{const p=L[j];if(q.t>=p.b-6&&Math.min(q.r,p.r)-Math.max(q.l,p.l)>4)q.s=Math.max(q.s,p.s+p.dh)}}}});
 L.forEach(q=>{{if(q.s)q.e.style.top=(q.t+q.s)+'px'}});
}});
Object.entries(FIX).forEach(([id,[dx,dy,dh]])=>{{const c=document.getElementById(id);if(c&&dh)c.style.height=(parseFloat(c.style.height)+dh)+'px'}});
const INKC='{INK}';
window.setT=setT;setT(0);
</script></body></html>"""
open(f"{W}/index.html", "w").write(html)
print("TOTAL", TOTAL, {k: (START[k], DUR[k]) for k in KEYS})
