#!/usr/bin/env python3
"""Phụ đề và mốc từng từ (v1.5). Dùng trong thư mục video: python3 make_srt.py [--no-whisper] [--max 56]
Đọc vo.json, durs_t.json, pauses.json, timing.json, audio/<khóa>_t.wav. Ghi:
  out/<tên>.srt   file phụ đề (mỗi dòng giữ tối thiểu 1,8 giây và bằng độ dài lời đọc cộng 0,6 giây khi còn chỗ)
  captions.json   danh sách dòng phụ đề kèm mốc từng từ (khuôn trang dùng để đốt sẵn khi video.json có "captions":"burn")
  words.json      mốc từng từ theo cảnh; nguon = "whisper" (khớp lời thật) hoặc "uoc_luong" (suy từ quãng nghỉ, kém chính xác hơn)
Có faster-whisper (pip install faster-whisper) thì mốc lấy từ giọng thật. Không có thì ước lượng và ghi rõ."""
import sys, os, re, json, unicodedata, difflib, subprocess
import numpy as np
vo = json.load(open("vo.json")); durs = json.load(open("durs_t.json")); pauses = json.load(open("pauses.json")); T = json.load(open("timing.json"))
CFG = json.load(open("video.json")); S, D, LEAD = T["START"], T["DUR"], T["LEAD"]
MAXC = int(sys.argv[sys.argv.index("--max") + 1]) if "--max" in sys.argv else CFG.get("caption_max_chars", 56)
MIN_HOLD, EXTRA = 1.8, 0.6
def norm(s): return " ".join(re.findall(r"[^\W_]+", unicodedata.normalize("NFC", s.lower())))
def estimate(k, toks):
    dur = durs[k]; pa = [(a, b) for a, b in pauses.get(k, []) if a > 0.02 and b < dur - 0.02]
    segs, cur = [], 0.0
    for a, b in pa: segs.append((cur, a)); cur = b
    segs.append((cur, dur)); tot = sum(b - a for a, b in segs)
    wts = [len(t) + 1.5 for t in toks]; W = sum(wts)
    def at(x):  # x trên trục thời gian nói (đã bỏ quãng nghỉ) → giây thật
        for a, b in segs:
            if x <= b - a: return a + x
            x -= b - a
        return segs[-1][1]
    out, c = [], 0.0
    for w in wts:
        out.append((at(c / W * tot), at((c + w * 0.92) / W * tot))); c += w
    return out
WH = None
if "--no-whisper" not in sys.argv:
    try:
        from faster_whisper import WhisperModel; WH = WhisperModel("small", device="cpu", compute_type="int8")
    except Exception as e: print("không có faster-whisper, ước lượng mốc từ quãng nghỉ:", type(e).__name__)
def whisper_times(k, toks):
    p = f"audio/{k}_t.wav"
    pcm = np.frombuffer(subprocess.run(["ffmpeg", "-v", "error", "-i", p, "-f", "s16le", "-ac", "1", "-ar", "16000", "-"], capture_output=True, check=True).stdout, np.int16).astype(np.float32) / 32768
    segs, _ = WH.transcribe(pcm, language="vi", beam_size=5, word_timestamps=True, vad_filter=False)
    ws = [w for s in segs for w in (s.words or [])]
    a = [norm(t) for t in toks]; b = [norm(w.word) for w in ws]
    res = [None] * len(toks); hit = 0
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if tag == "equal":
            for i, j in zip(range(i1, i2), range(j1, j2)): res[i] = (float(ws[j].start), float(ws[j].end)); hit += 1
    if hit < 0.6 * len(toks): return None, hit
    est = estimate(k, toks)
    for i in range(len(res)):  # từ không khớp: nội suy giữa hai từ đã khớp
        if res[i] is None:
            l = next((x for x in range(i - 1, -1, -1) if res[x]), None); r = next((x for x in range(i + 1, len(res)) if res[x]), None)
            lo = res[l][1] if l is not None else 0.0; hi = res[r][0] if r is not None else durs[k]
            run = [x for x in range((l if l is not None else -1) + 1, r if r is not None else len(res)) if res[x] is None]
            n = len(run); idx = run.index(i); step = (hi - lo) / max(n, 1)
            res[i] = (lo + idx * step, lo + (idx + 1) * step * 0.92)
    return res, hit
words, caps, src, warn = {}, [], "uoc_luong", []
used_wh = 0
for k in vo:
    toks = vo[k].split(); tm = None
    if WH:
        tm, hit = whisper_times(k, toks)
        if tm: used_wh += 1
        else: warn.append(f"{k}: whisper chỉ khớp {hit}/{len(toks)} từ, dùng ước lượng")
    if not tm: tm = estimate(k, toks)
    words[k] = [[round(LEAD + a, 3), round(LEAD + max(b, a + 0.08), 3)] for a, b in tm]
    # cắt dòng: theo câu; câu dài hơn MAXC thì chia đôi ở dấu phẩy gần giữa, không có thì ở khoảng trắng gần giữa
    def split(ids):
        txt = " ".join(toks[j] for j in ids)
        if len(txt) <= MAXC or len(ids) < 2: return [ids]
        mid = len(txt) / 2; best, bd = None, 1e9; pos = 0
        for n, j in enumerate(ids[:-1]):
            pos += len(toks[j]) + 1; d = abs(pos - mid) - (0.18 * len(txt) if toks[j][-1] in ",;:" else 0)
            if d < bd: best, bd = n + 1, d
        return split(ids[:best]) + split(ids[best:])
    sent, cur = [], []
    for i, t in enumerate(toks):
        cur.append(i)
        if t[-1] in ".?!" or i == len(toks) - 1: sent.append(cur); cur = []
    lines = [x for sn in sent for x in split(sn)]
    cl = [{"scene": k, "ids": ln} for ln in lines]
    def txt_of(c): return " ".join(toks[j] for j in c["ids"])
    # gộp dòng ngắn hơn 1,8 giây với dòng kế khi còn vừa MAXC
    i = 0
    while i < len(cl) - 1:
        a = cl[i]; dur = words[k][a["ids"][-1]][1] - words[k][a["ids"][0]][0]
        if dur < MIN_HOLD and len(txt_of(a)) + 1 + len(txt_of(cl[i + 1])) <= MAXC: a["ids"] = a["ids"] + cl[i + 1]["ids"]; del cl[i + 1]
        else: i += 1
    for c in cl:
        w = words[k]; c["t0"] = S[k] + w[c["ids"][0]][0]; c["t1"] = S[k] + w[c["ids"][-1]][1]
        c["text"] = txt_of(c); c["words"] = [[toks[j], round(S[k] + w[j][0], 3), round(S[k] + w[j][1], 3)] for j in c["ids"]]
    caps += cl
if WH and used_wh == len(vo): src = "whisper"
elif WH and used_wh: src = "whisper_mot_phan"
# giữ tối thiểu 1,8 giây và độ dài lời đọc + 0,6 giây, không chồng dòng kế, không vượt hết video
for i, c in enumerate(caps):
    speak = c["t1"] - c["t0"]; want = max(MIN_HOLD, speak + EXTRA)
    lim = (caps[i + 1]["t0"] - 0.04) if i + 1 < len(caps) else T["TOTAL"]
    c["t1"] = round(min(c["t0"] + want, max(lim, c["t1"])), 3); c["t0"] = round(c["t0"], 3); c["ids"] = None
    c["hold"] = round(c["t1"] - c["t0"], 2); c["ngan"] = c["hold"] < MIN_HOLD - 0.02  # lời đọc nhanh, dòng kế nối ngay nên không kéo dài được
for c in caps: c.pop("ids", None)
def ts(x): h, r = divmod(x, 3600); m, s = divmod(r, 60); return f"{int(h):02}:{int(m):02}:{int(s):02},{int(round((s - int(s)) * 1000)):03}"
os.makedirs("out", exist_ok=True)
with open(f"out/{CFG['name']}.srt", "w", encoding="utf-8") as f:
    for n, c in enumerate(caps, 1): f.write(f"{n}\n{ts(c['t0'])} --> {ts(c['t1'])}\n{c['text']}\n\n")
json.dump(caps, open("captions.json", "w"), ensure_ascii=False, indent=1)
json.dump({"nguon": src, "words": words}, open("words.json", "w"))
short = [c for c in caps if c["ngan"]]
print(f"phụ đề: {len(caps)} dòng, mốc từ: {src}; dòng ngắn hơn {MIN_HOLD}s: {len(short)} (lời đọc nhanh, dòng kế nối ngay)" + ("".join(f"\n  ! {w}" for w in warn)))
for c in short[:6]: print(f"  ngắn {c['hold']}s: {c['text'][:50]}")
