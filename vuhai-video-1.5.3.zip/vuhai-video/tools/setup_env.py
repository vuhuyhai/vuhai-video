#!/usr/bin/env python3
"""Dựng lại môi trường làm video trong container mới (idempotent: cái gì có rồi thì bỏ qua).
Dùng: python3 setup_env.py [--check]   (--check chỉ báo thiếu gì)
Cài: Python playwright + Pillow + numpy, ffmpeg (báo nếu thiếu), venv VieNeu 3.8.3 (đã vá codec_dir) + mô hình v3 Turbo.
Mặc định đặt ở /home/claude/tts-test (venv v, mô hình m). Đổi bằng biến VH_BASE. Cần mạng tới pypi.org và huggingface.co."""
import os, sys, subprocess, shutil, importlib.util, glob
BASE = os.environ.get("VH_BASE", "/home/claude/tts-test"); V = f"{BASE}/v"; M = f"{BASE}/m"; check = "--check" in sys.argv
def sh(c, **k): print("→", c if isinstance(c, str) else " ".join(c), flush=True); return subprocess.run(c, shell=isinstance(c, str), **k)
miss = []
for mod, pipn in (("playwright", "playwright"), ("PIL", "Pillow"), ("numpy", "numpy")):
    if importlib.util.find_spec(mod) is None:
        miss.append(pipn)
if miss:
    print("thiếu:", miss)
    if not check: sh([sys.executable, "-m", "pip", "install", "--break-system-packages", "-q"] + miss, check=True)
if not shutil.which("ffmpeg"): print("THIẾU ffmpeg (apt-get install -y ffmpeg)")
if not glob.glob("/opt/pw-browsers/chromium*") and not check: print("chưa thấy Chromium của Playwright: chạy `python3 -m playwright install chromium` nếu render lỗi")
ok_venv = os.path.exists(f"{V}/bin/python") and subprocess.run([f"{V}/bin/python", "-c", "import vieneu"], capture_output=True).returncode == 0
print("venv VieNeu:", "có" if ok_venv else "THIẾU")
if not ok_venv and not check:
    sh([sys.executable, "-m", "venv", V], check=True)
    sh([f"{V}/bin/pip", "install", "-q", "vieneu==3.8.3", "huggingface_hub", "numpy"], check=True)
# vá codec_dir (gói không chuyển tiếp codec_dir cho engine ONNX)
if os.path.exists(f"{V}/bin/python"):
    f = glob.glob(f"{V}/lib/python3*/site-packages/vieneu/v3turbo.py")
    if f:
        s = open(f[0]).read(); old = "onnx_subfolder=onnx_subfolder,\n                threads=threads,\n            )"
        if 'codec_dir=kwargs.get("codec_dir")' in s: print("đã vá codec_dir")
        elif old in s and not check:
            open(f[0], "w").write(s.replace(old, 'onnx_subfolder=onnx_subfolder,\n                threads=threads, codec_dir=kwargs.get("codec_dir"),\n            )')); print("đã vá codec_dir")
        else: print("CHƯA vá được codec_dir (mã nguồn khác bản 3.8.3), xem skill am-thanh")
ok_model = all(os.path.exists(p) for p in (f"{M}/onnx/vieneu_prefill.onnx", f"{M}/codec/moss_audio_tokenizer_decode_full.onnx"))
print("mô hình VieNeu:", "có" if ok_model else "THIẾU")
if not ok_model and not check:
    code = f'''
from huggingface_hub import snapshot_download
import shutil, os, glob
a = snapshot_download("pnnbao-ump/VieNeu-TTS-v3-Turbo", allow_patterns=["onnx_update/*"])
b = snapshot_download("OpenMOSS-Team/MOSS-Audio-Tokenizer-Nano-ONNX")
for src, dst in ((a + "/onnx_update", "{M}/onnx"), (b, "{M}/codec")):
    os.makedirs(dst, exist_ok=True)
    for p in glob.glob(src + "/*"):
        if os.path.isfile(p): shutil.copyfile(os.path.realpath(p), os.path.join(dst, os.path.basename(p)))  # cp -L: bỏ symlink của bộ nhớ đệm HF
print("xong mô hình")
'''
    sh([f"{V}/bin/python", "-c", code], check=True)
print("\nCòn lại: đặt VIENEU_DIR=" + M + " và chạy gen_vo.py bằng " + V + "/bin/python")
