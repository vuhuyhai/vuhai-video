## Nhân vật mascot Vũ Hải

Nhân vật cố định của Vũ Hải là bộ ảnh do chính anh tạo (bộ PNG nền trong suốt 13 ảnh, thư mục `Mô hình Vũ Hải minecraft` trên máy anh, nằm trong `Image` của thư mục `Vu Hai Biz consultant`, và các ảnh mới anh gửi thẳng trong chat). Chỉ dùng ảnh của anh. Không dựng lại nhân vật bằng code (Three.js, voxel, CSS, SVG), vì mọi bản dựng bằng code đều không giống ảnh mẫu của anh. Nếu chưa có ảnh trong phiên, xin quyền thư mục trên máy anh hoặc xin anh gửi ảnh, không tự vẽ thay.

**Mọi ảnh mascot đưa vào video phải là ảnh nền trong suốt, giữ nguyên tỷ lệ gốc, không viền, không bóng đổ khối.** Không dán cả khung ảnh có nền đen hay hào quang cam vào cảnh (Vũ Hải đã yêu cầu sửa lại sau khi bản dán khung ảnh được giao). Không cắt xén vào nhân vật hay đạo cụ để ép về tỷ lệ khác, không kéo méo. Chỉ được cắt sát phần trong suốt thừa quanh ảnh. Ảnh ngang vẫn để ngang và chừa chỗ cho nó. Quy trình tách nền ảnh có nền tối nằm ở mục "Tách nền ảnh mascot" bên dưới.

**Không phải cảnh nào cũng cần nhân vật.** Đây là luật chính của mục này. Ngoại lệ: ảnh banner luôn có nhân vật (xem `duyet-giao.md`, mục Banner).

- Dùng nhân vật ở: hook mở đầu, chuyển ý hoặc nhấn mạnh, cảnh giải thích, cảnh hỏi đáp hoặc tư vấn, lời kêu gọi cuối.
- Không dùng ở: cảnh nhiều chữ, cảnh số lớn, biểu đồ, ảnh thật, cảnh liệt kê nhiều mục, khối liên hệ. Ở các cảnh này nhân vật chỉ che nội dung.
- Tối đa khoảng một nửa số cảnh có nhân vật. Hai cảnh liền nhau không dùng cùng một tư thế. Cảnh không có nhân vật dùng toàn khung, không chừa chỗ trống. Nếu cảnh không có ảnh mà bên phải bị trống thì nới rộng thẻ ra thay vì để khoảng trắng.
- Khi lập beat map, thêm cột "mascot" cho từng cảnh: có hoặc không, và tên tư thế nếu có. Cảnh nào chữ hoặc hình đã đầy thì ghi "không".
- Khi số ảnh ít hơn số cảnh cần nhân vật, dùng lại một ảnh ở cảnh khác nhau, không dùng lại ở hai cảnh liền nhau, và nói rõ khi giao.

**Chọn tư thế theo vai của cảnh.** Tên file có số đuôi, luôn kiểm tra tên thật trong thư mục.

| Vai của cảnh | Tư thế | File đã dùng |
|---|---|---|
| Hook, chào | vẫy tay | `Mascot Vũ Hải vẫy tay-4.png` |
| Giải thích | đang giải thích | `Mascot Vũ Hải đang giải thích-3.png` |
| Chỉ vào ý chính | chỉ tay | `Linh vật Vũ Hải chỉ tay-5.png` |
| Hỏi đáp, tư vấn | lắng nghe | `Mascot Vũ Hải tư vấn lắng nghe-4.png` |
| Chuyển ý | bước đi | `Mascot Vũ Hải bước đi-9.png` |
| Câu hỏi mở, suy nghĩ | suy tư | `Vũ Hải suy tư-7.png` |
| Nói thẳng với người xem | thuyết trình với micro | `Mascot Vũ Hải thuyết trình với micro-1.png` |
| Chốt, kêu gọi | giơ ngón cái | `Mascot Vũ Hải giơ ngón cái-6.png` |

Ảnh mới theo chủ đề bài (ví dụ bộ 4 ảnh Phòng gym đóng cửa: cầm thẻ trước cửa khóa, bàn 12 tờ lịch và hũ tiền, kính lúp soi phòng gym nứt, cầm danh sách kiểm tra cạnh hũ tiền) thì ghép theo nghĩa của cảnh: ảnh cửa khóa ở hook, ảnh bàn lịch ở cảnh nói về thẻ năm, ảnh kính lúp ở cảnh nói về sự vô hình, ảnh danh sách kiểm tra ở cảnh người mua hỏi gì và cảnh kêu gọi.

Hạn chế dùng: các ảnh ngang rộng (bàn làm việc, ghế, laptop, bảng lật) vì chiếm nhiều chỗ và che nội dung, nếu cần thì đổi sang tư thế bước đi hoặc suy tư, hoặc thu hẹp thẻ để chừa dải ngang. Hai ảnh lệch style (tư thế chỉ tay kiểu thân thiện và bản voxel 3D áo đen) không dùng chung với các ảnh còn lại trong một video, để nhân vật trông như một người.

**Cách đặt nhân vật.**

- Cách ưu tiên khi dựng cảnh: cảnh có nhân vật chừa một dải phải khoảng 400 đến 650px trong khung 1920x1080 (lề an toàn vẫn giữ), nhân vật đặt trong dải đó, cao khoảng 700 đến 880px, chân chạm khoảng y=1040 đến 1066. Ảnh đã tách nền được phép gối lên mép thẻ ở phần thẻ không có chữ (tối đa khoảng 100px), nhưng không che chữ, số hay icon. Thẻ có chữ dài thì thu hẹp thẻ (và thu cỡ chữ không dưới mức tối thiểu) rồi chạy lại script đo đệm. Ảnh ngang 3:2 đặt ở nửa dưới dải phải, rộng khoảng 640px, thẻ thu còn khoảng 1060px. Cảnh không có nhân vật dựng toàn khung. Không thu nhỏ cả video để chừa chỗ.
- Nhân vật vào bằng trượt 110 đến 220px trong 0,35 đến 0,5 giây (cubic ease), nhấp nhô 5 đến 6px chu kỳ 2,4 giây suốt cảnh, mờ dần ở 0,2 giây cuối cảnh. Hết cảnh có nhân vật thì ra, cảnh kế tiếp không dùng nhân vật thì khung trở lại toàn bộ.
- Video dọc 9:16: đặt nhân vật ở nửa dưới, trong vùng an toàn, và xem ảnh chụp trước khi dựng cả video.

**Tách nền ảnh mascot.** Ảnh nền đen hoặc quầng cam, áo quần đen: dùng skill `tach-nen-mascot-vuhai` (đã gồm quy trình rembg, làm gắt alpha, bù tay bằng hình chữ nhật, cắt sát, ghép thử trên nền kem). Ảnh phải ra PNG nền trong suốt, giữ nguyên tỷ lệ, trước khi đưa vào cảnh.

**Kiểm tra riêng cho mascot.** Soi từng cảnh có nhân vật: nhân vật có che chữ, số, icon hoặc mép biểu đồ không, có đúng tư thế khớp vai của cảnh không, có hai cảnh liền nhau cùng tư thế không, tỉ lệ có nhất quán giữa các cảnh không, chân có chạm đúng đường đáy không, ảnh có còn nền đen, quầng cam, viền trắng hay vệt thừa không, ảnh có bị kéo méo hoặc cắt vào nhân vật không. Số cảnh có nhân vật có vượt khoảng một nửa không.


## Banner (từ 1.3.5)
- Banner dùng bộ tư thế trong `mascot/pose/` (7 ảnh nền trong suốt đã cắt sát: khoanh tay, suy tư, vẫy tay, chỉ lên, ngạc nhiên, giải thích, ngón cái). Danh mục và gợi ý chọn theo chủ đề ở `mascot/pose/catalog.json` (cột `hop_voi`).
- `banner.json`: `"mascot": "auto"` kèm `"tag"` (vài từ khóa của video, ví dụ "vô hình, bất ngờ") để `banner.py` chọn ảnh khớp nhất. Muốn chỉ định thì ghi tên, ví dụ `suy-tu`. Hai video liền nhau không dùng cùng tư thế.
- Ảnh khác (toàn thân trong `mascot/full/`, ảnh mới anh thêm trong `Mô hình Vũ Hải minecraft`) đặt vào `assets/` và ghi tên file (không đuôi .png) vào `mascot`; `banner.py` tự cắt sát nền trong suốt.
- Không lật ngược, không kéo méo, không thêm viền, bóng hay quầng sáng.
