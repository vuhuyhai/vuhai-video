# VÍ DỤ: cảnh của video 'Nghịch lý phục hồi dịch vụ'. Chép thành scenes.py trong thư mục video rồi sửa.
# Mỗi cảnh: SC['sK'] = HTML các thẻ; ev(...)/land(...) khai báo chuyển động; c = cues('sK', [...]) lấy mốc theo lời đọc.
# Luật: mọi thẻ dùng fc() (flex, đệm tự động) và đặt từ đầu cảnh; chữ trên nền đỏ là kem; CTA dùng đúng chữ trong cta.json.
SC = {}
BRIGHT = "#FF6A5F"
def fc(i, x, y, w, h, cls, inner, sh=16, bw=5, bar=True):
    b = f'<div class="bar" id="{i}b"></div>' if bar else ""
    return f'<div class="card fx {cls}" id="{i}" data-sh="{sh}" style="left:{x}px;top:{y}px;width:{w}px;height:{h}px;border-width:{bw}px">{inner}{b}</div>'
def ib(s, name):
    return f'<div class="ibx" style="width:{s}px;height:{s}px"><div class="bw" style="width:64%;height:64%">{icon(name)}</div></div>'
def col(*p): return '<div class="col">' + "".join(p) + '</div>'
def lab(s, size=34, st=""): return f'<div class="lab" style="font-size:{max(size,34)}px;margin-bottom:8px;{st}">{s}</div>'
def tt(s, size, st=""): return f'<div class="tt" style="font-size:{size}px;{st}">{s}</div>'
def bd(s, size=40, st=""): return f'<div class="bd" style="font-size:{max(size,38)}px;{st}">{s}</div>'
def rd(s): return f'<span class="rd">{s}</span>'
def tag(s): return chip("tag", 80, 250, s, "cr", 64)
def rowdur(sc, i, a, b):
    add_row(sc, i, a, b); EV[i]["barid"] = i + "b"; EV[i]["lift"] = None
def rowe(sc, i, lt, a, b):
    # hàng vào sớm (lt), thanh chạy theo lời đọc từ a đến b
    ev(sc, i, "land", lt, dy=50)
    EV[i]["bar"] = [round(START[sc] + a, 3), max(.5, round(b - a, 2))]; EV[i]["barid"] = i + "b"; EV[i]["lift"] = None
def land(sc, i, t, dy=50): ev(sc, i, "land", t, dy=dy)
def L(i, y, s, size, color): return t_(i, 80, y, s, "h", f"font-size:{size}px;color:{color}")

archive()
# ---------- S1 hook ----------
c = cues("s1", ["Khách gặp", "Có nên", "Cuối video"])
SC["s1"] = (tag("SERVICE RECOVERY PARADOX")
  + fc("k1", 80, 340, 860, 430, "", col(tt("KHÁCH GẶP<br>LỖI RỒI LẠI<br>" + rd("HÀI LÒNG HƠN"), 100)), 24, 8, False)
  + fc("k2", 80, 798, 520, 462, "red", col(tt("CÓ NÊN<br>MỪNG<br>KHÔNG?", 100)), 20, 6, False)
  + fc("sb", 80, 1288, 480, 202, "", col(bd("Cuối video có một câu hỏi cho bạn", 40)), 16, 5, False)
  + mas("m1", "m1", 680, 1020, 1490))
ev("s1", "tag", "tag", .2); land("s1", "k1", .1, -70); land("s1", "k2", .2); land("s1", "sb", .3); ev("s1", "m1", "mas", .15, dy=200)

archive()
# ---------- S2 định nghĩa + 1992 ----------
c = cues("s2", ["lỗi,", "đền bù", "rồi hài lòng", "Thuật ngữ"])
SC["s2"] = (tag("SERVICE RECOVERY PARADOX")
  + fc("t", 80, 340, 860, 232, "", col(tt("NGHỊCH LÝ<br>PHỤC HỒI DỊCH VỤ", 64)), 20, 6, False)
  + fc("a", 80, 596, 860, 180, "", ib(100, "alert-triangle") + col(tt("KHÁCH GẶP LỖI", 60)), 16, 5, False)
  + fc("b", 80, 800, 860, 180, "red", ib(100, "heart-handshake") + col(tt("ĐỀN BÙ XUẤT SẮC", 60)), 16, 5, False)
  + fc("c", 80, 1004, 860, 222, "pet", ib(100, "trending-up") + col(tt("HÀI LÒNG HƠN", 66), bd("cả lúc chưa có sự cố", 38)), 16, 5, False)
  + fc("d", 80, 1250, 860, 240, "", col(lab("THUẬT NGỮ GẮN VỚI", 32), bd("McCollough và Bharadwaj", 42)) + tt(rd("1992"), 96, "flex:none"), 20, 6, False))
ev("s2", "tag", "tag", .2); land("s2", "t", .1, -50)
land("s2", "a", .25); land("s2", "b", .55); land("s2", "c", .9); land("s2", "d", 1.3)

archive()
# ---------- S3 lật lại + 1998 ----------
c = cues("s3", ["Nhưng", "Năm một", "cảnh báo"])
SC["s3"] = (tag("LẬT LẠI")
  + fc("k1", 80, 340, 860, 440, "red", col(lab("NHƯNG ĐỪNG VỘI MỪNG"), tt("KHÔNG PHẢI<br>QUY LUẬT", 118)), 24, 8, False)
  + fc("k2", 80, 808, 860, 330, "", col(tt(rd("1998"), 130), tt("SMITH VÀ BOLTON", 50)), 20, 6, False)
  + fc("k3", 80, 1166, 860, 324, "pet", col(lab("CẢNH BÁO"), tt("RỦI RO RẤT LỚN", 72), bd("Biến lỗi thành cơ hội gây ấn tượng", 38)), 20, 6, False))
ev("s3", "tag", "tag", .2); land("s3", "k1", .1, -70); land("s3", "k2", .25); land("s3", "k3", .6)

archive()
# ---------- S4 Michel và Meuter (mascot m3) ----------
c = cues("s4", ["Năm hai", "hơn mười một", "Hiện tượng", "Kết luận"])
SC["s4"] = (tag("KIỂM CHỨNG NGOÀI ĐỜI THẬT")
  + fc("a1", 80, 340, 860, 232, "", tt(rd("2008"), 120) + col(tt("MICHEL VÀ<br>MEUTER", 52)), 16, 5, False)
  + fc("a2", 80, 600, 860, 350, "", col(tt(rd("HƠN 11.000"), 120), bd("cuộc phỏng vấn khách hàng tại ngân hàng", 40)), 24, 8, False)
  + fc("b", 80, 978, 500, 232, "pet", col(tt("RẤT HIẾM", 76), bd("Chênh lệch quá nhỏ", 40)), 16, 5, False)
  + fc("c", 80, 1236, 500, 254, "red", col(lab("KẾT LUẬN"), tt("CỐ TÌNH LÀM TỆ KHÔNG PHẢI CHIẾN LƯỢC", 38)), 16, 5, False)
  + mas("m1", "m3", 565, 1060, 1490))
ev("s4", "tag", "tag", .2); land("s4", "a1", .1); land("s4", "a2", .25); land("s4", "b", .5); land("s4", "c", .8); ev("s4", "m1", "mas", .3, dy=200)

archive()
# ---------- S5 de Matos ----------
c = cues("s5", ["De Matos", "khách vui", "mua lại", "truyền miệng", "hình ảnh"])
def r5(i, y, name, title, cls=""):
    return fc(i, 80, y, 860, 200, cls, ib(100, name) + col(tt(title, 46), bd("hầu như không thay đổi", 38)), 16, 5, True)
SC["s5"] = (tag("PHÂN TÍCH TỔNG HỢP")
  + fc("a", 80, 340, 860, 220, "", tt(rd("2007"), 110) + col(tt("DE MATOS<br>VÀ CỘNG SỰ", 50)), 16, 5, False)
  + fc("b", 80, 584, 860, 224, "pet", ib(100, "mood-smile") + col(tt("KHÁCH VUI HƠN", 58), bd("một chút", 40)), 16, 5, False)
  + r5("r1", 832, "repeat", "Ý ĐỊNH MUA LẠI") + r5("r2", 1056, "message-circle", "TRUYỀN MIỆNG", "red") + r5("r3", 1280, "building-store", "HÌNH ẢNH DOANH NGHIỆP"))
ev("s5", "tag", "tag", .2); land("s5", "a", .1); land("s5", "b", .25)
rowe("s5", "r1", .5, sub(c[2]), c[3]); rowe("s5", "r2", .75, sub(c[3]), c[4]); rowe("s5", "r3", 1.0, sub(c[4]), seg_end("s5"))

archive()
# ---------- S6 Magnini ----------
c = cues("s6", ["Khi nào", "lỗi không quá", "khách chưa", "nguyên nhân", "doanh nghiệp"])
def r6(i, y, name, txt, cls=""):
    return fc(i, 80, y, 860, 204, cls, ib(100, name) + col(bd(txt, 46)), 16, 5, True)
SC["s6"] = (tag("KHI NÀO DỄ XẢY RA?")
  + fc("a", 80, 340, 860, 230, "", tt(rd("2007"), 110) + col(tt("MAGNINI<br>VÀ CỘNG SỰ", 52)), 16, 5, False)
  + r6("r1", 594, "alert-circle", "Lỗi không quá nặng") + r6("r2", 822, "user-check", "Khách chưa từng gặp sự cố", "red")
  + r6("r3", 1050, "dice-3", "Nguyên nhân ngẫu nhiên, khó lặp lại", "pet") + r6("r4", 1278, "hand-stop", "Doanh nghiệp ở thế bị động"))
ev("s6", "tag", "tag", .2); land("s6", "a", .1)
nx = c[2:] + [seg_end("s6")]
for n in range(4): rowe("s6", f"r{n+1}", .25 + .25 * n, sub(c[n + 1]), nx[n])

archive()
# ---------- S7 giới hạn (mascot m4) ----------
c = cues("s7", ["Họ thừa", "Khách gặp"])
SC["s7"] = (tag("GIỚI HẠN")
  + fc("k1", 80, 340, 580, 400, "", col(lab("TÁC GIẢ TỰ THỪA NHẬN", 32), bd("Người tham gia chỉ là sinh viên, trong một bối cảnh dịch vụ", 46)), 20, 6, False)
  + fc("k2", 80, 768, 580, 722, "red", col(lab("KHÁCH GẶP LỖI NHIỀU LẦN", 32), tt("LẠI NỮA<br>RỒI", 108), bd("Phục hồi đẹp đến đâu cũng khó cứu", 46)), 20, 6, False)
  + mas("m1", "m4", 900, 1060, 1490))
ev("s7", "tag", "tag", .2); land("s7", "k1", .1); land("s7", "k2", .25); ev("s7", "m1", "mas", .15, dy=200)

archive()
# ---------- S8 bài học ----------
c = cues("s8", ["Phục hồi", "Nhân viên", "có người đỡ", "nguyên nhân gốc", "Khách hài lòng"])
def r8(i, y, name, txt, cls=""):
    return fc(i, 80, y, 860, 178, cls, ib(96, name) + col(bd(txt, 42)), 16, 5, True)
SC["s8"] = (tag("VIỆC CỦA CẢ HỆ THỐNG")
  + fc("t1", 80, 340, 860, 290, "red", col(lab("PHỤC HỒI DỊCH VỤ KHÔNG PHẢI"), tt("MÀN TRÌNH DIỄN", 80), bd("mà là việc của cả hệ thống", 40)), 20, 6, False)
  + r8("r1", 648, "shield-check", "Nhân viên có quyền xử lý ngay") + r8("r2", 844, "users", "Có người đỡ phía sau")
  + r8("r3", 1040, "tool", "Nguyên nhân gốc được sửa")
  + fc("z", 80, 1236, 860, 254, "pet", col(lab("KHÁCH HÀI LÒNG HƠN LÀ"), tt("PHẦN THƯỞNG,<br>KHÔNG PHẢI KẾ HOẠCH", 46)), 20, 6, False))
ev("s8", "tag", "tag", .2); land("s8", "t1", .1)
rowe("s8", "r1", .25, sub(c[1]), c[2]); rowe("s8", "r2", .5, sub(c[2]), c[3]); rowe("s8", "r3", .75, sub(c[3]), c[4]); land("s8", "z", 1.0)

archive()
# ---------- S9 câu hỏi (mascot m5) ----------
c = cues("s9", ["Bạn có", "để che"])
SC["s9"] = (tag("CÂU HỎI CHO BẠN")
  + fc("k1", 80, 340, 860, 460, "", col(lab("BẠN CÓ ĐANG DỰA VÀO"), tt("LỜI XIN LỖI<br>" + rd("THẬT KHÉO") + "?", 108)), 24, 8, False)
  + fc("k2", 80, 828, 470, 560, "red", col(tt("ĐỂ CHE<br>MỘT LỖI CỨ<br>LẶP LẠI<br>HÀNG TUẦN?", 60)), 20, 6, False)
  + mas("m1", "m5", 660, 1060, 1490))
ev("s9", "tag", "tag", .2); land("s9", "k1", .1, -60); land("s9", "k2", .25); ev("s9", "m1", "mas", .1, dy=200)

archive()
# ---------- S10 CTA thật ----------
c = cues("s10", ["Hãy đăng ký", "Vũ Huy"])
LK = f"font-family:Inter;font-weight:700;color:{CREAM};"
SC["s10"] = (fc("k0", 80, 330, 860, 290, "red", col(lab("ĐĂNG KÝ KHÓA HỌC", 36), tt("Biến nhu cầu khách hàng thành doanh số", 58)), 20, 6, False)
  + t_("lk", 80, 654, "https://vuhuyhai.com/sanpham01", "", LK + "font-size:54px")
  + t_("bf", 80, 750, "để hiểu hơn về Dịch vụ và cách thiết kế giải pháp", "", LK + "font-size:46px;line-height:1.25;white-space:normal;width:860px")
  + L("tg2", 902, "Human first. Profit follows.", 52, CREAM)
  + fc("k1", 80, 1008, 860, 482, "cream",
      col(tt("VŨ HẢI", 80, f"color:{INK}"), f'<div style="height:5px;background:{RED};margin:4px 0 8px"></div>',
          tt("0344 444 000", 56, f"color:{INK}"), bd("fitnessviet@gmail.com", 44, f"color:{INK}"),
          bd("facebook.com/vuhai.fitness", 44, f"color:{INK}"), bd("vuhuyhai.com", 50, f"color:{RED}")), 20, 6, False))
ev("s10", "bf", "rev", .1, dy=30); ev("s10", "tg2", "rev", .3, dy=20); land("s10", "k1", .45, 60)
land("s10", "k0", sub(c[0]), 60); ev("s10", "lk", "rev", sub(c[1]), dy=30)
