#!/usr/bin/env python3
"""Dải ảnh soi chuyển động, lấy từ chính file MP4 (v1.5). Dùng trong thư mục video: python3 strip.py out/<tên>.mp4 [--step 0.2] [--span 0.4]
Quanh mỗi chỗ chuyển cảnh và mỗi lần mascot vào, lấy các khung cách nhau --step giây (mặc định 0,2) từ -span đến +span.
Ghi out/strip/<điểm>.png (một hàng khung, có ghi giờ) và out/strip.png (xếp các hàng lại cho người chấm).
Dùng để soi hiệu ứng quất, đẩy, mờ chuyển động mà ảnh chụp tĩnh và contact sheet mỗi 3 giây không thấy."""
import sys, os, re, json, subprocess
from PIL import Image, ImageDraw
args = [a for a in sys.argv[1:] if not a.startswith("--")]; mp4 = args[0]
def opt(n, d): return float(sys.argv[sys.argv.index(n) + 1]) if n in sys.argv else d
step, span = opt("--step", 0.2), opt("--span", 0.4)
T = json.load(open("timing.json")); S, TOTAL = T["START"], T["TOTAL"]; KEYS = list(S)
ev = json.loads(re.search(r"const EV=(\{.*?\});\r?\nconst ", open("index.html", encoding="utf-8").read(), re.S).group(1))
pts = [(f"cat-{k}", S[k]) for k in KEYS[1:]] + [(f"mascot-{i.split('_', 1)[0]}", e["t"]) for i, e in ev.items() if e["k"] == "mas"]
n = int(round(span / step)); offs = [round(i * step, 3) for i in range(-n, n + 1)]
os.makedirs("out/strip", exist_ok=True); rows = []
for name, t0 in pts:
    fr = []
    for o in offs:
        t = min(max(t0 + o, 0), TOTAL - 0.05); f = f"out/strip/_{name}_{o}.png"
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", f"{t:.3f}", "-i", mp4, "-frames:v", "1", "-vf", "scale=360:-1", f], check=True)
        im = Image.open(f).convert("RGB"); d = ImageDraw.Draw(im); d.rectangle((0, 0, 150, 26), fill="#1A1A1A"); d.text((6, 7), f"{t:6.2f}s ({o:+.1f})", fill="#F7F4EF"); fr.append(im); os.remove(f)
    row = Image.new("RGB", (sum(i.width for i in fr), fr[0].height), "white")
    for i, im in enumerate(fr): row.paste(im, (i * im.width, 0))
    row.save(f"out/strip/{name}.png"); rows.append((name, row))
if rows:
    w = rows[0][1].width // 2; h = rows[0][1].height // 2; per = 3
    sheet = Image.new("RGB", (w * per, (h + 22) * ((len(rows) + per - 1) // per)), "white"); d = ImageDraw.Draw(sheet)
    for i, (name, row) in enumerate(rows):
        x, y = (i % per) * w, (i // per) * (h + 22); d.text((x + 6, y + 6), name, fill="#1A1A1A"); sheet.paste(row.resize((w, h)), (x, y + 22))
    sheet.save("out/strip.png")
print(f"dải ảnh: {len(rows)} điểm ({', '.join(nm for nm, _ in rows[:6])}{'...' if len(rows) > 6 else ''}) -> out/strip.png và out/strip/*.png")
