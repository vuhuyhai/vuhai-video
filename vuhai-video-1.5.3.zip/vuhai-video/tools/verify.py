#!/usr/bin/env python3
"""Kiểm tự động trước khi giao. Dùng (trong thư mục video): python3 verify.py out/ten-video.mp4
Kiểm: thời lượng, audio, độ lớn, giọng ở mọi cảnh, đuôi giọng không bị cắt, khung 0 là banner, cảnh CTA đủ lâu,
khung đen/đứng hình, đệm chữ (audit), chữ tối trên nền đỏ và chữ đỏ trên nền tối, mascot lặp tư thế,
từ cấm và gạch dài, CTA đúng nguyên văn (cta.json). Tạo thêm out/contact.png và out/phone.png cho người chấm.
Thoát 0 nếu không có lỗi P0. Người chấm độc lập chỉ cần xem hình và chấm phần cần mắt."""
import sys, os, re, json, subprocess, wave, glob
import numpy as np
mp4 = sys.argv[1]; T = json.load(open("timing.json")); S, D, TOTAL, LEAD = T["START"], T["DUR"], T["TOTAL"], T["LEAD"]
PW, PH = T.get("PW", 1080), T.get("PH", 1920); KEYS = list(S)
res = []  # (mức, tên, chi tiết)
def add(ok, name, detail="", level="P0"): res.append(("ĐẠT" if ok else level, name, detail))
def sh(cmd): return subprocess.run(cmd, capture_output=True, text=True)
def wavread(p):
    with wave.open(p) as w: return np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768, w.getframerate()
def db(x): return 20 * np.log10(max(float(x), 1e-9))

# 1. file, thời lượng, audio, khung hình
pr = json.loads(sh(["ffprobe","-v","error","-show_entries","stream=codec_type,width,height,duration","-of","json",mp4]).stdout)
st = {s["codec_type"]: s for s in pr["streams"]}
add("audio" in st and "video" in st, "có hình và tiếng")
v = st.get("video", {}); add((int(v.get("width", 0)), int(v.get("height", 0))) == (PW, PH), "khung hình", f"{v.get('width')}x{v.get('height')}")
dv = float(v.get("duration", 0)); add(abs(dv - TOTAL) < 0.1, "thời lượng", f"{dv:.2f}s so với {TOTAL}s")
# 2. độ lớn
r = sh(["ffmpeg","-i",mp4,"-af","loudnorm=I=-14:TP=-1.5:print_format=json","-f","null","-"]).stderr
j = json.loads(re.search(r"\{[^{}]*input_i[^{}]*\}", r, re.S).group(0)); I, TP = float(j["input_i"]), float(j["input_tp"])
add(abs(I + 14) <= 1.0, "độ lớn LUFS", f"{I:.1f} (mục tiêu -14 ±1)"); add(TP <= -1.0, "đỉnh thật dBTP", f"{TP:.1f} (không quá -1)")
# 3. giọng ở mọi cảnh + đuôi clip không bị cắt giữa từ
if os.path.exists("mix/vo.wav"):
    vo, sr = wavread("mix/vo.wav"); durs = json.load(open("durs_t.json")); miss = []
    for k in KEYS:
        a = int((S[k] + LEAD + .05) * sr); b = int((S[k] + LEAD + durs[k] - .05) * sr); seg = vo[a:b]
        fr = np.abs(seg[: len(seg) // 1200 * 1200]).reshape(-1, 1200).max(1) if len(seg) >= 1200 else np.array([0])
        if (fr > 0.01).mean() < 0.5: miss.append(k)
    add(not miss, "mọi cảnh đều có giọng đọc", "thiếu: " + ",".join(miss) if miss else f"{len(KEYS)}/{len(KEYS)} cảnh")
    bad = []
    for k in KEYS:
        p = f"audio/{k}_t.wav"
        if os.path.exists(p):
            x, s2 = wavread(p); n = int(.03 * s2)
            if db(np.abs(x[-n:]).max()) > -45: bad.append(k)
    add(not bad, "đuôi giọng không bị cắt giữa từ", "nghi cắt: " + ",".join(bad) if bad else "")
else: add(False, "có mix/vo.wav để kiểm giọng", level="P1")
# 4. khung 0 là banner (banner 16:9 trong video dọc được đặt giữa nền kem, giống mux.py)
if os.path.exists("banner.png"):
    from PIL import Image
    _t = json.load(open("timing.json")); _pw, _ph = _t.get("PW", 1080), _t.get("PH", 1920); _w, _h = 108, max(2, round(108 * _ph / _pw))
    f0 = subprocess.run(["ffmpeg","-v","error","-i",mp4,"-vf",f"select=eq(n\\,0),scale={_w}:{_h}","-frames:v","1","-f","rawvideo","-pix_fmt","gray","-"],capture_output=True).stdout
    _b = Image.open("banner.png").convert("RGB")
    if abs(_b.width / _b.height - _pw / _ph) > 0.01:
        _k = min(_pw / _b.width, _ph / _b.height); _b1 = _b.resize((round(_b.width * _k), round(_b.height * _k)), Image.LANCZOS)
        _c = Image.new("RGB", (_pw, _ph), (247, 244, 239)); _c.paste(_b1, ((_pw - _b1.width) // 2, (_ph - _b1.height) // 2)); _b = _c
    bn = _b.resize((_w, _h), Image.LANCZOS).convert("L").tobytes()
    d = float(np.abs(np.frombuffer(f0, np.uint8).astype(float) - np.frombuffer(bn, np.uint8).astype(float)).mean()) if len(f0) == len(bn) > 0 else 99
    add(d < 6, "khung 0 là banner", f"chênh lệch {d:.1f}")
else: add(False, "có banner.png", level="P0")
# 5. cảnh cuối đủ lâu, khung đen, đứng hình
last = KEYS[-1]; add(D[last] >= 6.0, "cảnh CTA đứng đủ 6 giây", f"{D[last]:.1f}s")
bd = sh(["ffmpeg","-i",mp4,"-vf","scale=270:-1,blackdetect=d=0.2:pix_th=0.05","-an","-f","null","-"]).stderr
blk = re.findall(r"black_start:([\d.]+) black_end:([\d.]+)", bd); blk = [b for b in blk if float(b[0]) < TOTAL - 1.0]
add(not blk, "không có khung đen giữa video", str(blk))
fz = sh(["ffmpeg","-i",mp4,"-vf","scale=270:-1,freezedetect=n=0.001:d=2.5","-an","-f","null","-"]).stderr
fs = [float(x) for x in re.findall(r"freeze_start: ([\d.]+)", fz)]; fs = [x for x in fs if x < S[last]]
add(not fs, "không đứng hình quá 2,5 giây trước cảnh cuối", str(fs), "P1")
# 6. đệm chữ
ra = sh([sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), "audit.py")]); m = re.search(r"violations (\d+)", ra.stdout)
add(m is not None and m.group(1) == "0", "đệm chữ trong thẻ (audit)", (m.group(0) if m else ra.stderr[-200:]))
# 7. DOM: màu chữ trên nền, mascot
from playwright.sync_api import sync_playwright
JS = """()=>{const out=[];const lum=c=>{const m=c.match(/[\\d.]+/g).map(Number);const f=v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)};return .2126*f(m[0])+.7152*f(m[1])+.0722*f(m[2])};
const rgb=c=>c.match(/[\\d.]+/g).map(Number);
const bgOf=e=>{while(e){const b=getComputedStyle(e).backgroundColor;const m=b.match(/[\\d.]+/g);if(m&&(m.length<4||+m[3]>.5))return b;e=e.parentElement}return 'rgb(247,244,239)'};
const vis=e=>{while(e){const s=getComputedStyle(e);if(s.opacity==='0'||s.display==='none')return false;e=e.parentElement}return true};
const isRed=c=>{const [r,g,b]=rgb(c);return Math.abs(r-199)<25&&Math.abs(g-57)<30&&Math.abs(b-55)<30};const redish=c=>{const [r,g,b]=rgb(c);return r>170&&r-g>80&&r-b>80};
const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let x;
while(x=w.nextNode()){if(!x.textContent.trim())continue;const e=x.parentElement;if(!vis(e))continue;const r=e.getBoundingClientRect();if(r.width<2||r.left>%d||r.right<0)continue;
 const col=getComputedStyle(e).color,bg=bgOf(e);
 if(isRed(bg)&&lum(col)<.45)out.push('chữ tối trên nền đỏ: '+x.textContent.trim().slice(0,30));
 if(redish(col)&&lum(bg)<.2)out.push('chữ đỏ trên nền tối: '+x.textContent.trim().slice(0,30));}
document.querySelectorAll('svg.ico').forEach(s=>{if(!vis(s))return;const r=s.getBoundingClientRect();if(r.width<2||r.left>%d||r.right<0)return;const col=getComputedStyle(s).color,bg=bgOf(s.parentElement);if(isRed(bg)&&lum(col)<.45)out.push('icon tối trên nền đỏ')});
return out}""" % (PW, PW)
col_bad, mas = [], {}
with sync_playwright() as p:
    b = p.chromium.launch(args=["--allow-file-access-from-files"]); pg = b.new_page(viewport={"width": PW, "height": PH})
    pg.goto("file://" + os.path.abspath("index.html")); pg.evaluate("document.fonts.ready"); pg.wait_for_timeout(600)
    for k in KEYS:
        pg.evaluate(f"setT({S[k] + D[k] - 0.2})")
        col_bad += [f"{k}: {x}" for x in pg.evaluate(JS)]
        mas[k] = pg.evaluate(f"(()=>{{const i=document.querySelector('#{k} img.mas');return i?i.getAttribute('src'):null}})()")
    b.close()
add(not col_bad, "không chữ tối trên nền đỏ, không chữ đỏ trên nền tối", "; ".join(sorted(set(col_bad))[:6]))
rep = [(a, b2) for a, b2 in zip(KEYS, KEYS[1:]) if mas[a] and mas[a] == mas[b2]]
add(not rep, "mascot không lặp tư thế ở hai cảnh liền nhau", str(rep))
nm = sum(1 for k in KEYS if mas[k]); add(nm <= (len(KEYS) + 1) // 2, "mascot không quá một nửa số cảnh", f"{nm}/{len(KEYS)}", "P1")
# 8. chữ cấm
BAN = ["kiến tạo","lan tỏa","nâng tầm","truyền cảm hứng","cuộc cách mạng","bùng nổ doanh thu","bí quyết","công thức","tăng trưởng đột phá","kinh hoàng","bóc phốt","sốc","bí mật"]
txt = ""
for f in ("vo.json","share-copy.txt","hook-options.md","banner.json"):
    if os.path.exists(f): txt += open(f).read() + "\n"
html = open("index.html").read(); html = re.sub(r"<style>.*?</style>", "", html, flags=re.S); html = re.sub(r"<svg.*?</svg>", "", html, flags=re.S); html = re.sub(r"<script>.*?</script>", "", html, flags=re.S)
txt += re.sub(r"<[^>]+>", " ", html)
hits = [w for w in BAN if re.search(r"(?<!\w)" + re.escape(w) + r"(?!\w)", txt, re.I)]
add(not hits, "không có từ cấm", ", ".join(hits)); add("\u2014" not in txt, "không có gạch dài (U+2014)")
# 9. CTA nguyên văn
if os.path.exists("cta.json"):
    cta = json.load(open("cta.json")); pagetxt = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html)); sc = open("share-copy.txt").read() if os.path.exists("share-copy.txt") else ""
    miss = [m for m in cta.get("must", []) if m.lower() not in pagetxt.lower()]; add(not miss, "CTA hiện đúng nguyên văn trên màn hình", "; ".join(miss))
    miss2 = [m for m in cta.get("share", []) if m.lower() not in sc.lower()]; add(not miss2, "share-copy có CTA", "; ".join(miss2))
else: add(False, "có cta.json (CTA thật của anh Hải)", "chưa có: phải ghi rõ khi giao rằng dùng CTA trung tính", "P1")
# 9b. v1.5: phụ đề (mục 1), khoảng lặng (mục 4), thời gian giữ chữ (mục 5)
CV = json.load(open("video.json")); srt = f"out/{CV['name']}.srt"
if os.path.exists("captions.json"):
    caps = json.load(open("captions.json")); ov = [i + 1 for i in range(len(caps) - 1) if caps[i]["t1"] > caps[i + 1]["t0"] + 0.001]
    add(os.path.exists(srt) and not ov, "phụ đề: có file .srt và các dòng không chồng nhau", "chồng ở dòng " + str(ov) if ov else ("thiếu " + srt if not os.path.exists(srt) else f"{len(caps)} dòng"), "P1")
    ng = [c for c in caps if c.get("ngan")]; add(not ng, "phụ đề: mỗi dòng giữ tối thiểu 1,8 giây", f"{len(ng)}/{len(caps)} dòng ngắn hơn vì lời đọc nhanh, dòng kế nối ngay", "P2")
    if CV.get("captions") == "burn" and PH > PW: add(CV.get("caption_bottom", 440) >= 420, "phụ đề đốt sẵn nằm trong vùng an toàn (cách mép dưới từ 420px)", level="P1")
else: add(False, "có phụ đề (chạy make_srt.py, giai đoạn srt)", level="P1")
sd = sh(["ffmpeg", "-i", mp4, "-af", "silencedetect=noise=-45dB:d=0.35", "-vn", "-f", "null", "-"]).stderr
_ss = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", sd)]; _se = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", sd)]
sil = [(round(a, 2), round(b, 2)) for a, b in zip(_ss, _se) if a > 0.5 and b < TOTAL - 2.6]
add(len(sil) >= min(2, len(KEYS) - 1), "âm thanh: tối thiểu 2 khoảng lặng (từ 0,35 giây) trước điểm đáng giá", f"{len(sil)} khoảng: {sil} (thêm bằng video.json khoang_lang)", "P1")
RATE, BASE = CV.get("toc_do_doc", 15), CV.get("giu_chu_nen", 1.5)
EVH = json.loads(re.search(r"const EV=(\{.*?\});\r?\nconst ", open("index.html", encoding="utf-8").read(), re.S).group(1))
with sync_playwright() as p:
    b = p.chromium.launch(args=["--allow-file-access-from-files"]); pg = b.new_page(viewport={"width": PW, "height": PH})
    pg.goto("file://" + os.path.abspath("index.html")); pg.evaluate("document.fonts.ready")
    cards = pg.evaluate("()=>[...document.querySelectorAll('.card')].map(c=>({id:c.id,n:[...c.querySelectorAll('*')].filter(e=>!e.closest('.bar')&&e.children.length===0).map(e=>e.textContent).join('').replace(/\\s+/g,' ').trim().length}))")
    b.close()
short_hold = []
for c in cards:
    e = EVH.get(c["id"])
    if not e or not c["n"]: continue
    hold = S[e["sc"]] + D[e["sc"]] - e["t"]; need = c["n"] / RATE + BASE
    if hold < need: short_hold.append((c["id"], c["n"], round(hold, 1), round(need, 1)))
short_hold.sort(key=lambda x: x[3] - x[2], reverse=True)
add(not short_hold, f"thời gian giữ chữ: số ký tự chia {RATE} cộng {BASE} giây", f"{len(short_hold)}/{len(cards)} thẻ giữ chưa đủ (thẻ, ký tự, giữ, cần): {short_hold[:4]}; chỉnh tốc độ bằng video.json toc_do_doc", "P1")
# 10. hình cho người chấm
os.makedirs(os.path.dirname(mp4) or ".", exist_ok=True); od = os.path.dirname(mp4) or "."
sh(["ffmpeg","-y","-loglevel","error","-i",mp4,"-vf","fps=1/3,scale=270:-1,tile=7x3","-frames:v","1",f"{od}/contact.png"])
sh(["ffmpeg","-y","-loglevel","error","-i",mp4,"-vf","fps=1/6,scale=360:-1,tile=5x2","-frames:v","1",f"{od}/phone.png"])
p0 = sum(1 for r_ in res if r_[0] == "P0"); p1 = sum(1 for r_ in res if r_[0] == "P1"); p2 = sum(1 for r_ in res if r_[0] == "P2")
for lv, n, d in res: print(f"[{lv:4}] {n}" + (f"  ({d})" if d else ""))
print(f"\nP0: {p0}  P1: {p1}  P2: {p2}  | hình cho người chấm: {od}/contact.png, {od}/phone.png")
json.dump([{"level": a, "check": b2, "detail": c} for a, b2, c in res], open(f"{od}/verify.json", "w"), ensure_ascii=False, indent=1)
sys.exit(1 if p0 else 0)
