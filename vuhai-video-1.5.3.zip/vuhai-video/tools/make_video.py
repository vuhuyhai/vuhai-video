#!/usr/bin/env python3
"""Chạy cả chuỗi dựng video trong thư mục video. Dùng: python3 make_video.py [giai_đoạn ...] [--force] [--scenes s9,s10]
Giai đoạn theo thứ tự: vo, trim, srt, page, audit, audio, render, mux, verify, strip. Bỏ trống = tất cả.
`make_video.py mau` chạy vo, trim, srt, page, audit rồi chụp 3 khung mẫu (out/khung-mau.png) và dừng để anh Hải duyệt.
Giai đoạn đã có kết quả mới hơn đầu vào thì bỏ qua (trừ khi --force). Việc nặng (vo, render) xếp hàng qua /tmp/render.lock.
Cần trong thư mục: vo.json, video.json, scenes.py, assets/, fonts/, banner.json (hoặc banner.png), cta.json (CTA thật).
video.json: {"name":"ten-video-9x16","title":"...","size":[1080,1920],"fixed":{"s10":7.5},"dark":["s10"],"procs":2}"""
import sys, os, json, subprocess, fcntl, time
H = os.path.dirname(os.path.abspath(__file__)); PY = sys.executable
VBASE = os.environ.get("VH_BASE", "/home/claude/tts-test"); VPY = f"{VBASE}/v/bin/python" if os.path.exists(f"{VBASE}/v/bin/python") else PY  # giọng VieNeu chạy trong venv riêng
STAGES = ["vo", "trim", "srt", "page", "audit", "audio", "render", "mux", "verify", "strip"]
EXTRA = ["mau"]  # chỉ chạy khi gọi tên: vo, trim, srt, page, audit rồi dừng ở 3 khung mẫu để duyệt
args = [a for a in sys.argv[1:] if not a.startswith("--") and a in STAGES + EXTRA]; force = "--force" in sys.argv
scenes = sys.argv[sys.argv.index("--scenes") + 1] if "--scenes" in sys.argv else None
todo = ["vo", "trim", "srt", "page", "audit", "mau"] if args == ["mau"] else (args or STAGES); CFG = json.load(open("video.json")); NAME = CFG["name"]; OUT = f"out/{NAME}.mp4"
def mt(p): return os.path.getmtime(p) if os.path.exists(p) else 0
def newer(out, *ins): return mt(out) and all(mt(out) >= mt(i) for i in ins if os.path.exists(i))
def run(cmd, heavy=False):
    t = time.time(); print("→", " ".join(cmd), flush=True)
    if heavy:
        with open("/tmp/render.lock", "w") as lk:
            fcntl.flock(lk, fcntl.LOCK_EX); r = subprocess.run(cmd)
    else: r = subprocess.run(cmd)
    if r.returncode: sys.exit(f"LỖI ở: {' '.join(cmd)}")
    print(f"  ({time.time() - t:.0f}s)", flush=True)
def audit_loop():
    r = subprocess.run([PY, f"{H}/audit.py"], capture_output=True, text=True)
    if "violations 0" in r.stdout: print("audit: 0 vi phạm"); return
    for _ in range(3):
        if os.path.exists("fix.json"): os.remove("fix.json")
        run([PY, f"{H}/build_page.py"])  # trang không fix, đo từ trạng thái gốc
        run([PY, f"{H}/audit.py", "--fix"]); run([PY, f"{H}/build_page.py"])
        r = subprocess.run([PY, f"{H}/audit.py"], capture_output=True, text=True)
        if "violations 0" in r.stdout: print("audit: 0 vi phạm sau khi nới thẻ"); return
    sys.exit("audit còn vi phạm sau 3 vòng, sửa scenes.py bằng tay:\n" + r.stdout)
for st in todo:
    print(f"\n== {st}")
    if st == "vo":
        if not force and os.path.exists("audio") and all(os.path.exists(f"audio/{k}.wav") for k in json.load(open("vo.json"))): print("đã có giọng, bỏ qua (dùng gen_vo.py <khóa> để tạo lại cảnh sửa lời)"); continue
        os.environ.setdefault("VIENEU_DIR", f"{VBASE}/m"); run([VPY, f"{H}/gen_vo.py"], heavy=True)
    elif st == "trim":
        if not force and newer("durs_t.json", "vo.json"): print("bỏ qua"); continue
        run([PY, f"{H}/trim_vo.py"])
    elif st == "srt":
        if not force and newer("captions.json", "vo.json", "durs_t.json", "timing.json") and os.path.exists("captions.json"): print("bỏ qua"); continue
        run([PY, f"{H}/make_srt.py"])
    elif st == "mau":
        run([PY, f"{H}/style_frames.py"]); print("Dừng ở đây: gửi out/khung-mau.png cho anh Hải duyệt rồi mới chạy cả chuỗi."); sys.exit(0)
    elif st == "page":
        run([PY, f"{H}/build_page.py"])
    elif st == "audit": audit_loop()
    elif st == "audio":
        if not force and newer("mix/final.wav", "timing.json", "durs_t.json"): print("bỏ qua"); continue
        run([PY, f"{H}/build_audio.py"]); run([PY, f"{H}/mix_audio.py"])
    elif st == "render":
        cmd = [PY, f"{H}/render.py", str(CFG.get("procs", 2))] + (["--scenes", scenes] if scenes else [])
        run(cmd, heavy=True)
    elif st == "mux":
        if os.path.exists("banner.json") and (force or not newer("banner.png", "banner.json")): run([PY, f"{H}/banner.py"])
        run([PY, f"{H}/mux.py", OUT, "banner.png"])
    elif st == "verify": run([PY, f"{H}/verify.py", OUT])
    elif st == "strip": run([PY, f"{H}/strip.py", OUT])
print("\nXONG", OUT)
