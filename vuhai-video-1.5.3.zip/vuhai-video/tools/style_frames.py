#!/usr/bin/env python3
"""Khung mẫu để duyệt trước khi render cả video (v1.5). Chạy trong thư mục video, sau khi có index.html (giai đoạn page, audit):
  python3 style_frames.py
Chụp 3 khung, mỗi khung là một cảnh ở lúc mọi thẻ đã đáp: HOOK, CẢNH ĐÁNG NHỚ NHẤT, CTA.
Ghi out/mau-hook.png, out/mau-dinh.png, out/mau-cta.png và out/khung-mau.png (ba khung cạnh nhau) để gửi anh Hải duyệt.
Chọn cảnh bằng video.json: "mau": {"hook":"s1","dinh":"s4","cta":"s8"}. Mặc định hook là cảnh đầu, CTA là cảnh cuối,
cảnh đáng nhớ nhất là cảnh có số lớn hoặc mascot gần giữa video nhất (không có thì cảnh giữa)."""
import os, json
from playwright.sync_api import sync_playwright
from PIL import Image, ImageDraw
T = json.load(open("timing.json")); S, D = T["START"], T["DUR"]; KEYS = list(S); PW, PH = T.get("PW", 1080), T.get("PH", 1920)
CFG = json.load(open("video.json")); M = CFG.get("mau", {})
html = open("index.html", encoding="utf-8").read()
def has(k, pat): return pat in html[html.index(f'id="{k}"'): html.index(f'id="{KEYS[KEYS.index(k) + 1]}"')] if KEYS.index(k) + 1 < len(KEYS) else pat in html[html.index(f'id="{k}"'):]
mid = len(KEYS) // 2
cand = [k for k in KEYS[1:-1] if has(k, "class=\"mas\"") or has(k, "font-size:1")] or KEYS[1:-1] or KEYS
dinh = M.get("dinh") or min(cand, key=lambda k: abs(KEYS.index(k) - mid))
pick = [("hook", M.get("hook") or KEYS[0]), ("dinh", dinh), ("cta", M.get("cta") or KEYS[-1])]
os.makedirs("out", exist_ok=True); ims = []
with sync_playwright() as p:
    b = p.chromium.launch(args=["--allow-file-access-from-files"]); pg = b.new_page(viewport={"width": PW, "height": PH})
    pg.goto("file://" + os.path.abspath("index.html")); pg.evaluate("document.fonts.ready"); pg.wait_for_timeout(700)
    for name, k in pick:
        pg.evaluate(f"setT({S[k] + max(D[k] * 0.6, D[k] - 1.2)})"); f = f"out/mau-{name}.png"; pg.screenshot(path=f); ims.append((name, k, Image.open(f).convert("RGB")))
    b.close()
H = 900; sc = [im.resize((round(im.width * H / im.height), H)) for _, _, im in ims]; gap = 30; W = sum(i.width for i in sc) + gap * 4
sheet = Image.new("RGB", (W, H + 110), "#F7F4EF"); d = ImageDraw.Draw(sheet); x = gap
for (name, k, _), im in zip(ims, sc):
    sheet.paste(im, (x, 80)); d.text((x, 30), f"KHUNG {['hook','dinh','cta'].index(name) + 1}: {dict(hook='HOOK', dinh='CANH DANG NHO NHAT', cta='CTA')[name]} ({k})", fill="#1A1A1A"); x += im.width + gap
sheet.save("out/khung-mau.png")
print("khung mẫu:", ", ".join(f"{n}={k}" for n, k in pick), "-> out/khung-mau.png. Gửi anh Hải duyệt rồi mới chạy cả chuỗi (make_video.py).")
