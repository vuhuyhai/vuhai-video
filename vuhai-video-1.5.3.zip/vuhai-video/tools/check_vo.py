#!/usr/bin/env python3
"""Kiểm giọng đọc bằng whisper: nghe lại từng audio/<khóa>_t.wav, so với vo.json.
Dùng trong thư mục video: python3 check_vo.py [khóa ...] [--model small]
Ra check_vo.json và in bảng: khóa, độ khớp (0 đến 1), chữ lệch. Cảnh dưới 0.80 hoặc có số lệch là cần nghe lại.
Cần: pip install faster-whisper. Số đọc thành chữ (13 thành "mười ba") được quy về cùng dạng trước khi so."""
import sys, os, json, re, unicodedata, difflib, subprocess
import numpy as np
args = [a for a in sys.argv[1:] if not a.startswith("--")]; model = sys.argv[sys.argv.index("--model") + 1] if "--model" in sys.argv else "small"
if "--model" in sys.argv: args = [a for a in args if a != model]
vo = json.load(open("vo.json")); keys = args or list(vo)
from faster_whisper import WhisperModel
M = WhisperModel(model, device="cpu", compute_type="int8")
D = "không một hai ba bốn năm sáu bảy tám chín".split()
def doc(n):
    if n < 10: return D[n]
    if n < 20: return "mười" + ("" if n == 10 else " " + ("lăm" if n == 15 else D[n-10]))
    if n < 100:
        t, u = divmod(n, 10); return D[t] + " mươi" + ("" if u == 0 else " " + ("lăm" if u == 5 else "mốt" if u == 1 else D[u]))
    if n < 1000:
        h, r = divmod(n, 100); return D[h] + " trăm" + ("" if r == 0 else " linh " + D[r] if r < 10 else " " + doc(r))
    t, r = divmod(n, 1000); return doc(t) + " nghìn" + ("" if r == 0 else " " + doc(r) if r >= 100 else " không trăm " + ("linh " + D[r] if r < 10 else doc(r)))
def num(m):
    t = m.group().replace(".", "").replace(",", "")
    return doc(int(t)) if len(t) <= 6 else " ".join(D[int(c)] for c in t)
def norm(s):
    s = unicodedata.normalize("NFC", s.lower()); s = re.sub(r"\d+(?:[.,]\d{3})*", num, s)
    s = s.replace("%", " phần trăm "); return re.findall(r"[^\W_]+", s)
out = {}; low = 0
for k in keys:
    p = f"audio/{k}_t.wav" if os.path.exists(f"audio/{k}_t.wav") else f"audio/{k}.wav"
    pcm = np.frombuffer(subprocess.run(["ffmpeg", "-v", "error", "-i", p, "-f", "s16le", "-ac", "1", "-ar", "16000", "-"], capture_output=True, check=True).stdout, np.int16).astype(np.float32) / 32768
    segs, _ = M.transcribe(pcm, language="vi", beam_size=5, vad_filter=False)
    heard = " ".join(s.text for s in segs).strip(); a, b = norm(vo[k]), norm(heard)
    sm = difflib.SequenceMatcher(None, a, b); r = round(sm.ratio(), 3)
    diff = [(" ".join(a[i1:i2]), " ".join(b[j1:j2])) for t, i1, i2, j1, j2 in sm.get_opcodes() if t != "equal"]
    out[k] = {"khop": r, "nghe_duoc": heard, "lech": diff}
    flag = "  <-- NGHE LẠI" if r < 0.80 else ""; low += r < 0.80
    print(f"{k:5} {r:.2f}{flag}\n   lệch: {diff[:6]}")
json.dump(out, open("check_vo.json", "w"), ensure_ascii=False, indent=1)
print(f"\n{len(keys)} cảnh, {low} cảnh dưới 0.80. Whisper đoán sai được, nên cảnh lệch vẫn cần anh Hải nghe lại.")
