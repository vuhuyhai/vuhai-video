#!/usr/bin/env python3
"""Dựng banner.png (thumbnail 1920x1080) theo ĐÚNG ba mẫu của Vũ Hải. Dùng: python3 banner.py  (đọc banner.json trong thư mục video)

Ba mẫu (chọn bằng "template"):
  A  giant-lon    tấm đỏ 780x520 chứa tiêu đề 2 dòng, mascot LỚN đứng ngoài đè lên mép tấm đỏ. Hợp khẳng định mạnh.
  B  giant-ngang  tấm đỏ chạy hết chiều ngang, tiêu đề tối đa 2 dòng, mascot NHỎ ở góc phải dưới. Mặc định.
  C  giant-dai    tiêu đề mực trên nền kem, dải đỏ ở đáy chứa số liệu, mascot nhỏ đứng trên dải đỏ. Hợp câu hỏi, chủ đề ngắn.

banner.json: {"template":"B","msg":"KHÁCH ĐANG|THUÊ","red":"","hook":"Khách mua thẻ 12 tháng, mang gì về nhà?",
  "label":"Buổi 1 · Video 1","stats":[["5","kiểu thuê"],["3","thứ ghi lại"]],"mascot":"auto","tag":"ý mới, mẹo, tò mò","size":[1920,1080]}
- msg: các dòng tách bằng |, tối đa 2 dòng, in hoa. red (chỉ mẫu C): một cụm trong msg tô đỏ.
- hook: ĐÚNG MỘT câu dưới 15 từ. label: nhãn nhỏ (tập, series), tùy chọn. stats: tối đa 3 cặp [số, đơn vị], tùy chọn, chỉ mẫu A, B, C.
- mascot_h: tùy chọn, chiều cao mascot (px trong khung 1280x720) khi ảnh có đạo cụ cần to hơn mặc định.
- mascot: "auto" = chọn trong mascot/pose theo tag (khớp cột hop_voi của mascot/pose/catalog.json), hoặc ghi tên một ảnh: assets/<tên>.png, slug trong mascot/pose hoặc mascot/full. Ảnh tự cắt sát nền trong suốt.
- Dấu tiếng Việt: tiêu đề giãn dòng 1,04 trở lên. Không dùng gạch dài. Chữ trên nền đỏ luôn là trắng.
Biến môi trường PW_CHANNEL=msedge (hoặc chrome) để dùng trình duyệt có sẵn khi chưa cài Chromium của Playwright."""
import json, os, re, shutil, sys
from playwright.sync_api import sync_playwright
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = f"{HERE}/.."
B = json.load(open("banner.json", encoding="utf-8"))
T = (B.get("template") or "B").upper()[:1]
assert T in "ABC", "template phải là A, B hoặc C"
lines = [l.strip() for l in B["msg"].split("|") if l.strip()]
assert 1 <= len(lines) <= 2, "msg tối đa 2 dòng"
assert 0 < len(B["hook"].split()) < 15, "hook là một câu dưới 15 từ"
stats = B.get("stats", [])[:3]
label = B.get("label", "")
for s in lines + [B["hook"], label] + [x for p in stats for x in p]:
    assert "—" not in s, "không dùng gạch dài"
PW, PH = B.get("size", [1920, 1080]); assert (PW, PH) == (1920, 1080), "ba mẫu chỉ có khổ 1920x1080"

# ---- mascot
def load_cat(p):
    return json.load(open(p, encoding="utf-8")) if os.path.exists(p) else {}
POSE = load_cat(f"{ROOT}/mascot/pose/catalog.json")
def pick(tag):
    names = sorted(POSE)
    if tag:
        sc = {n: sum(w.strip() in POSE[n]["hop_voi"] for w in tag.split(",") if w.strip()) for n in names}
        if max(sc.values()) > 0: return max(names, key=lambda n: sc[n])
    return names[sum(map(ord, os.path.basename(os.getcwd()))) % len(names)]
mname = re.sub(r"^assets/|\.png$", "", B.get("mascot", "auto"))
if mname == "auto": mname = pick(B.get("tag", "")); print("mascot auto:", mname)
for cand in (f"assets/{mname}.png", f"{ROOT}/mascot/pose/{mname}.png", f"{ROOT}/mascot/full/{mname}.png"):
    if os.path.exists(cand): src = cand; break
else: sys.exit(f"không thấy ảnh mascot {mname}")
im = Image.open(src).convert("RGBA"); bb = im.getchannel("A").point(lambda v: 255 if v > 24 else 0).getbbox(); im = im.crop(bb)
os.makedirs("assets", exist_ok=True); im.save("assets/_banner_mascot.png")
asp = im.width / im.height
for n in ("primary", "cream"): shutil.copy(f"{ROOT}/brand/logo-vuhai-{n}.svg", f"assets/_logo_{n}.svg")

# ---- fonts (có sẵn trong plugin: tools/template/fonts, new_video.py chép vào fonts/)
FONT = lambda fam, base, w, ss, rg: f'@font-face{{font-family:"{fam}";font-weight:{w};font-display:block;src:url("fonts/{base}-{ss}-{w}-normal.woff2") format("woff2");unicode-range:{rg}}}'
VI = "U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB"
LA = "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD"
FF = ("".join(FONT("Space Grotesk", "space-grotesk", 700, s, r) for s, r in (("vietnamese", VI), ("latin", LA)))
      + "".join(FONT("Inter", "inter", w, s, r) for w in (500, 700) for s, r in (("vietnamese", VI), ("latin", LA)))
      + "".join(FONT("JetBrains Mono", "jetbrains-mono", 700, s, r) for s, r in (("vietnamese", VI), ("latin", LA))))

BASE_CSS = """
*{box-sizing:border-box;margin:0;padding:0;font-style:normal}
html,body{width:1280px;height:720px;background:#F7F4EF}
body{position:relative;overflow:hidden;color:#1A1A1A;font-family:'Inter';font-weight:700;word-break:keep-all;overflow-wrap:break-word}
body *{position:absolute}
.t{font-family:'Space Grotesk';font-weight:700;text-transform:uppercase;letter-spacing:-.02em;white-space:nowrap;line-height:1.04}
.mono{font-family:'JetBrains Mono';font-weight:700;text-transform:uppercase;letter-spacing:.06em}
.sub{font-family:"Inter";font-weight:700;line-height:1.28;text-wrap:balance}
.chip{background:#fff;color:#1A1A1A;border:3px solid #1A1A1A;padding:8px 16px;font-size:20px;box-shadow:4px 4px 0 #1A1A1A}
.slab{background:#c73937;border:5px solid #1A1A1A;border-radius:4px;box-shadow:8px 8px 0 #1A1A1A}
.stats{display:flex;gap:40px}
.stats div{position:static;font-family:'JetBrains Mono';font-weight:700;text-transform:uppercase;letter-spacing:.04em;font-size:28px;padding-bottom:6px;border-bottom:3px solid currentColor}
.stats b{position:static;font-family:'Space Grotesk';font-size:44px;margin-right:8px}
img{display:block}
"""
CSS = {
 "A": """.slab{left:48px;top:48px;width:780px;height:520px}
.chip{left:88px;top:84px}.logo{left:612px;top:496px;width:120px}
.title{left:84px;top:142px;color:#fff}
.sub{left:88px;top:480px;width:500px;color:#fff}
.mas{right:36px;bottom:0;height:690px;max-width:520px;width:auto}
.stats{left:48px;top:604px}""",
 "B": """.slab{left:48px;top:48px;width:1184px;height:430px}
.chip{left:88px;top:84px}.logo{left:1072px;top:88px;width:130px}
.title{left:80px;top:148px;color:#fff}
.sub{left:88px;top:410px;width:820px;color:#fff}
.mas{right:48px;bottom:0;height:440px;width:auto}
.stats{left:48px;top:528px}""",
 "C": """.chip{left:64px;top:40px}
.title{left:60px;top:112px;color:#1A1A1A}.title u{position:static;text-decoration:none;color:#c73937}
.sub{left:64px;top:300px;width:700px;color:#1A1A1A}
.band{left:0;top:476px;width:1280px;height:244px;background:#c73937;border-top:5px solid #1A1A1A}
.stats{left:64px;top:528px;color:#fff}.stats div{font-size:32px}.stats b{font-size:60px}
.logo{left:64px;top:650px;width:130px}
.mas{right:90px;bottom:0;height:420px;width:auto}""",
}
FIT = {  # (maxW, maxH, font bắt đầu, font nhỏ nhất) của tiêu đề; (maxH) của hook
 "A": dict(tw=640, th=326, tf=190, sf=32, sh=82),
 "B": dict(tw=960, th=252, tf=140, sf=34, sh=66),
 "C": dict(tw=760, th=250, tf=168, sf=38, sh=0),
}[T]

def title_html():
    out = []
    for l in lines:
        if T == "C" and B.get("red") and B["red"] in l: l = l.replace(B["red"], f"<u>{B['red']}</u>")
        out.append(l)
    return "<br>".join(out)
stats_html = "".join(f"<div><b>{a}</b>{b}</div>" for a, b in stats)
logo = "cream" if T in "AB" else "cream"
body = ""
if T == "A": body += '<div class="slab"></div>'
if T == "B": body += '<div class="slab"></div>'
if T == "C": body += '<div class="band"></div>'
if label: body += f'<div class="mono chip">{label}</div>'
if T in "AB": body += '<img class="logo" src="assets/_logo_cream.svg" alt="">'
if T == "C": body += '<img class="logo" src="assets/_logo_cream.svg" alt="">'
body += f'<h1 class="t title" id="title">{title_html()}</h1><div class="sub" id="sub">{B["hook"]}</div>'
body += '<img class="mas" id="mas" src="assets/_banner_mascot.png" alt="">'
if stats_html: body += f'<div class="stats">{stats_html}</div>'
JS = """
const ti=document.getElementById('title'), su=document.getElementById('sub');
function fit(el,maxW,maxH,start,min){let f=start;el.style.fontSize=f+'px';
  while((el.scrollWidth>maxW||el.getBoundingClientRect().height>maxH)&&f>min){f-=2;el.style.fontSize=f+'px';}return f;}
const F=%s;
const tf=fit(ti,F.tw,F.th,F.tf,60);
if(%s){su.style.top=(ti.getBoundingClientRect().bottom+22)+'px';}
su.style.fontSize=F.sf+'px';
if(F.sh){let f=F.sf;su.style.fontSize=f+'px';while(su.getBoundingClientRect().height>F.sh&&f>22){f-=1;su.style.fontSize=f+'px';}}
else{let f=F.sf;const lim=470-(ti.getBoundingClientRect().bottom+22);su.style.fontSize=f+'px';while(su.getBoundingClientRect().height>lim&&f>22){f-=1;su.style.fontSize=f+'px';}}
document.title=JSON.stringify({tf,sf:parseFloat(su.style.fontSize)});
""" % (json.dumps(dict(tw=FIT["tw"], th=FIT["th"], tf=FIT["tf"], sf=FIT["sf"], sh=FIT["sh"])), "true" if T == "C" else "false")
MASCSS = f".mas{{height:{int(B['mascot_h'])}px}}" if B.get("mascot_h") else ""
html = f'<!doctype html><html lang="vi"><head><meta charset="utf-8"><style>{FF}{BASE_CSS}{CSS[T]}{MASCSS}</style></head><body>{body}<script>{JS}</script></body></html>'
open("banner.html", "w", encoding="utf-8").write(html)

def box(pg, sel):
    return pg.evaluate("(s)=>{const r=document.querySelector(s).getBoundingClientRect();return [r.left,r.top,r.right,r.bottom]}", sel)
with sync_playwright() as p:
    kw = {"args": ["--allow-file-access-from-files"]}
    if os.environ.get("PW_CHANNEL"): kw["channel"] = os.environ["PW_CHANNEL"]
    b = p.chromium.launch(**kw); pg = b.new_page(viewport={"width": 1280, "height": 720}, device_scale_factor=1.5)
    pg.goto("file://" + os.path.abspath("banner.html")); pg.evaluate("document.fonts.ready"); pg.wait_for_timeout(900)
    info = json.loads(pg.title()); tb, sb, mb = box(pg, "#title"), box(pg, "#sub"), box(pg, "#mas")
    pg.screenshot(path="banner.png"); b.close()
print("banner.png xong, mẫu", T, "tiêu đề", info["tf"], "px, hook", info["sf"], "px")
assert info["tf"] >= 80, "tiêu đề quá dài, rút ngắn msg"
assert info["sf"] >= 22, "hook quá dài, rút ngắn hook"
over = lambda a, c: not (a[2] <= c[0] or c[2] <= a[0] or a[3] <= c[1] or c[3] <= a[1])
for nm, bx in (("tiêu đề", tb), ("hook", sb)):
    if over(bx, mb): print(f"CẢNH BÁO: {nm} chạm khung ảnh mascot, xem ảnh thật và đổi mascot hoặc rút ngắn chữ")
assert sb[3] <= {"A": 568, "B": 476, "C": 472}[T] + 4, "hook tràn khỏi khối, rút ngắn hook"
