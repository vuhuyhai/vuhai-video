# Hyperframes và Remotion (chỉ dùng khi anh Hải yêu cầu)

Đường mặc định là Playwright (xem `dung-canh.md`). Nội dung dưới đây giữ nguyên từ bản cũ của skill.

## Chọn engine

**Hyperframes (mặc định).** HTML, CSS và GSAP, render ra MP4. Giấy phép Apache 2.0, nên dùng cho Ladysfit, VPTA, VSE mà không phải mua license. Hợp với style Neo-Brutalism của Vũ Hải vì dựng bằng chính CSS. Nếu môi trường có skill `/hyperframes`, đọc skill đó trước khi viết composition. Lệnh chính: `npx hyperframes init`, `npm run check`, `npx hyperframes snapshot --at <giây,giây> --describe false -o <thư mục>`, `npm run render`.

**Remotion.** Dùng khi Vũ Hải đòi Remotion hoặc cần React. Remotion miễn phí cho cá nhân, còn Ladysfit, VPTA, VSE (công ty từ 3 người) cần license thương mại, phải nói trước khi dựng.

**Đường tự dựng bằng Playwright (đã chạy thật ở video Phòng gym đóng cửa, video lịch sử GDTC dọc và video Gói tập phòng gym).** Một trang HTML duy nhất điều khiển bằng hàm `setT(t)`, chụp từng khung bằng Playwright chạy song song (4 tiến trình nếu máy có 4 nhân, 2 tiến trình nếu máy 2 nhân), ghép âm bằng ffmpeg (libx264 CRF 20, aac 192k). Dùng khi cần kiểm soát từng khung và không cần các khối dựng sẵn của Hyperframes. Render 120 giây ở 1920x1080 mất khoảng 4 phút trên 4 tiến trình. Mọi luật cứng, khung hình NB và kiểm tra trong skill này áp dụng như nhau. Khi ghép, cắt âm theo độ dài video (`-t <giây video>`), vì track âm thường dài hơn khung cuối khoảng nửa giây.

Định dạng mặc định: 16:9 ngang, 1920x1080, 30fps. Không hỏi lại định dạng trừ khi Vũ Hải đổi ý. Khi Vũ Hải nói video dọc, bản dọc, Reels, TikTok hoặc Shorts, dùng khung 9:16 (1080x1920) và làm theo mục "Video dọc 9:16" bên dưới. Bố cục dọc phải dựng lại, không cắt từ bản ngang. Nếu Vũ Hải gõ "dọc 16:9" thì hiểu là 9:16 dọc và nói rõ một câu trong bài giao để anh xác nhận. Khung vuông 1:1 thì nói trước là cần dựng riêng.

## Dựng bằng Hyperframes

Với Hyperframes:

1. Khởi tạo project, viết `frame.md` để dịch skill `neo-brutalism-design-vuhai` sang luật khung hình video (bên dưới). Đây là bộ luật chung và bộ thành phần dùng chung (thẻ, nhãn, chip, hàng, khối số, khối liên hệ) viết trước khi dựng cảnh nào, để mọi cảnh trông như cùng một chương trình.
2. Mỗi cảnh là một sub-composition riêng trong `compositions/sN.html`. Thẻ gốc của cảnh phải là `id="root"` và tạo kiểu bằng `#root`, không dùng class, nếu không lint báo lỗi. Mỗi cảnh có timeline GSAP tạm dừng đăng ký ở `window.__timelines[id]`.
3. GSAP để cục bộ trong `vendor/`, không gọi CDN. Icon theo luật cứng số 1: Tabler SVG nội tuyến, tải từ `tabler/tabler-icons` và xác nhận tải được, không tự vẽ, không nhớ tên icon từ phiên trước. Lập bảng kê icon (khái niệm, tên icon Tabler, đã tải chưa) trong `video-plan.md` trước khi dựng.
4. Sinh các cảnh bằng một script Python đọc file `timing.json`. Đổi giọng, đổi tốc độ hoặc sửa chữ thì chạy lại script, không sửa tay từng file. Thêm hoặc tách cảnh thì thêm khóa mới vào file lời đọc và script, rồi chạy lại toàn bộ.
5. Phần tử hiện trước lời đọc khoảng 0,1 tới 0,3 giây, không sau lời.
6. Nội dung trong một cảnh vào sau khi khung của nó đã hiện, và ra trước khi cảnh kế tiếp vào, để chữ không bao giờ chồng lên nhau.
7. Dữ liệu hiển thị phải là dữ liệu thật của nguồn, không dùng chữ giữ chỗ. Nếu cần ví dụ giả cho giao diện thì dùng giá trị giả rõ ràng, không dùng thông tin cá nhân hay dữ liệu khách thật.
8. Video ngắn đăng mạng xã hội nên để khung cuối khớp với khung đầu khi có thể, để xem lặp mượt.
9. Không để khung nào đứng yên quá khoảng 2 giây, trừ cảnh CTA cuối đứng yên đủ 6 giây cho nội dung chính (nền và icon vẫn chuyển động nhẹ). Mỗi cảnh luôn có chuyển động nền (xem mục Chuyển động liên tục bên dưới).
10. Cảnh có nhân vật mascot (theo cột mascot của beat map) chừa dải phải cho ảnh nền trong suốt, cảnh khác toàn khung, theo mục "Nhân vật mascot Vũ Hải".
11. Thẻ dựng theo luật cứng số 3: đệm chữ trong thẻ tính từ công thức chiều cao theo nội dung, không để chữ sát viền, và có bước đo bằng script rồi nới thẻ, đẩy khối bên dưới.
12. Cảnh CTA: hành động và nơi làm hiện cỡ lớn, chữ đúng nguyên văn CTA của Vũ Hải, cảnh đứng yên đủ 6 giây. CTA nhẹ giữa video nhỏ gọn và không che nội dung đang đọc.

Font nhúng cục bộ, không gọi Google Fonts: `npm i @fontsource/space-grotesk @fontsource/inter @fontsource/jetbrains-mono`, chép các file woff2 của hai bộ ký tự `vietnamese` và `latin` (Space Grotesk 700, Inter 500 và 700, JetBrains Mono 700) vào `fonts/`. Khai báo `@font-face` (kèm `unicode-range` của từng bộ) trong `index.html` và cả trong `<style>` của từng file cảnh, đường dẫn tính từ thư mục gốc dự án. Thiếu khai báo trong file cảnh thì `npm run check` báo lỗi `font_family_without_font_face`.

Với Remotion: mỗi beat là một `<Sequence>`, dùng `references/remotion-technical-basics.md` khi không có skill Remotion chính thức, style theo `references/style-tokens-vuhai.md`.

## Chuyển động liên tục (bản GSAP)

#### Chuyển động liên tục và thanh chạy theo nhịp đọc

Người xem mất tập trung khi nhìn một khung tĩnh dù giọng đọc vẫn chạy. Vì vậy mọi cảnh có ba lớp chuyển động, sinh tự động trong script dựng cảnh (hàm bọc `scene_html`, đọc thời lượng cảnh từ `timing.json`):

- Nền hoa văn trôi chậm suốt cảnh: `tl.fromTo(".nen", {backgroundPosition:"0px 0px"}, {backgroundPosition:"-260px 150px", duration:DUR, ease:"none"}, 0)`.
- Icon nhấp nhô nhẹ: `tl.to(".ico", {y:-8, duration:0.9, yoyo:true, repeat:N, ease:"sine.inOut"}, 1.2)`, chỉ chạy khi cảnh có icon (kiểm tra bằng querySelector).
- Ảnh thật Ken Burns: scale 1 lên 1,12 suốt cảnh, chỉ chạy khi cảnh có ảnh.

Với các cảnh liệt kê (hàng, ô, đoạn văn), thêm **thanh chạy theo nhịp đọc**: mỗi mục có một thanh cao 6px màu petrol ở đáy, scaleX từ 0 lên 1 (gốc bên trái) đúng bằng độ dài đoạn lời đọc của mục đó (lấy từ `durs.json`), bắt đầu cùng lúc lời đọc. Mục đang được đọc nhích ra 14px và bóng nổi lên 18px, bắt đầu sau lúc mục vào khoảng 0,25 giây (để không chồng với tween vào cảnh, tránh cảnh báo overlapping_gsap_tweens), rồi trở về khi hết đoạn đọc. Nhờ vậy mắt luôn có chỗ để theo. Thanh chạy nằm ở đáy thẻ và không tính vào khoảng đệm chữ.

## Cổng kiểm tra và render của Hyperframes

**Cổng kiểm tra.** Chạy `npm run check` tới khi 0 lỗi, 0 cảnh báo, độ tương phản đạt AA. Cảnh báo lúc chạy kiểu "GSAP target not found" cũng phải sửa, vì nghĩa là một selector không có phần tử và hiệu ứng đó không chạy (ví dụ icon nhấp nhô). Với đường tự dựng bằng Playwright thì không có lệnh này, thay bằng việc chụp ảnh từng cảnh và chạy script đo bên dưới.

**Render.** Trên máy không có GPU (render phần mềm, 2 nhân), thời gian render khoảng 2 tới 2,3 lần độ dài video với cảnh tĩnh (34 giây mất 80 giây, 175 giây mất 6 phút 40, 213 giây mất 7 phút 44). Cảnh có chuyển động nền liên tục nặng hơn, khoảng 3,1 lần (186 giây mất gần 10 phút; video 60 giây mất 2 phút 51). Số điểm ảnh của khung dọc 1080x1920 bằng khung ngang 1920x1080, nên thời gian render tính như nhau. Lệnh `npm run render` chạy ở nền trước (foreground) với timeout 600000 ms sẽ bị ngắt ở 10 phút nếu video dài hơn khoảng 3 phút có chuyển động nền. Cách chạy ổn: `setsid nohup npx --yes hyperframes@<phiên bản> render -o renders/<tên>.mp4 > r.log 2>&1 < /dev/null &` rồi `sleep` chờ và đọc `r.log` trong cùng lệnh gọi (dưới 590 giây mỗi lần), gọi tiếp để chờ nếu chưa xong. Phải giữ chính lệnh gọi đã khởi động render còn sống trong lúc chờ: nếu lệnh gọi kết thúc ngay sau khi khởi động, render bị hủy với lỗi `render_cancelled_parent_exited`. Dòng "Done" của shell không có nghĩa là render xong, đợi tới khi file MP4 xuất hiện và log báo assemble. Video dài hơn khoảng 4 phút thì rút bớt cảnh cho vừa giới hạn. Ghép mascot bằng cách hậu kỳ mất thêm khoảng 1,5 phút cho mỗi 60 giây video. Đường tự dựng bằng Playwright chạy song song: video 120 giây mất khoảng 4 phút trên 4 tiến trình, video 90 giây ở 1920x1080 mất khoảng 2,5 phút trên 2 tiến trình (chụp JPEG chất lượng 95).
