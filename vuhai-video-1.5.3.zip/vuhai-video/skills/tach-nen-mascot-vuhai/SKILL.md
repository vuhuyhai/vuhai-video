---
name: tach-nen-mascot-vuhai
description: Tách nền ảnh mascot Vũ Hải thành PNG trong suốt cho video. Dùng khi ảnh mascot có nền đen, quầng sáng cam hoặc áo quần đen, và khi cắt ra bị mất tay, chân, đồng hồ, thẻ.
---

# Tách nền mascot Vũ Hải

## Bước 0 (bắt buộc): kiểm tra ảnh anh Hải gửi đã trong suốt chưa
Ảnh PNG anh Hải gửi gần như luôn là RGBA có kênh alpha thật. Khung xem trong chat hiển thị phần trong suốt thành màu đen, nên nhìn bằng mắt sẽ tưởng là nền đen. Đừng tin mắt.
1. Mở bằng Pillow, in `im.mode` và tỉ lệ điểm có alpha = 0.
2. Nếu có kênh alpha (từ 2 phần trăm điểm trở lên bằng 0): chạy `python3 ${CLAUDE_PLUGIN_ROOT}/tools/mascot_from_alpha.py <thư mục ra> <ảnh>...`. Công cụ chỉ làm sắc mép và cắt sát, không tách lại. Dừng ở đây, bỏ qua các bước còn lại.
3. Tuyệt đối không `convert("RGB")` rồi tách nền lại một ảnh đã trong suốt. Lỗi này đã làm 24 mascot bị quầng, thủng áo, giày rách và anh Hải phải nhắc hai lần.
4. Chỉ khi ảnh không có alpha mới làm tiếp phần dưới, và phải nói rõ với anh Hải đây là bản tách tự động.

## Nói thẳng với Vũ Hải trước khi làm
Ảnh nền đen có quầng cam không dùng thẳng được. Tách nền tự động với nhân vật áo đen, quần đen trên nền đen luôn có sai số. Cách chắc nhất là xin file gốc nền trong suốt, hoặc xin tạo lại ảnh trên nền xanh lá hoặc nền trắng không có quầng sáng. Khi có ảnh như vậy thì dùng nguyên, bỏ qua mọi bước dưới.

## Quy trình khi buộc phải tách
1. `pip install rembg onnxruntime`. Tải `u2net.onnx` vào `~/.u2net/`. Chạy u2net (alpha_matting) và isnet-general-use, lấy `np.maximum` của hai alpha.
2. Làm gắt bằng smoothstep 0,18 đến 0,45. Giữ mảng liên thông lớn hơn 1 phần trăm ảnh. Đóng lỗ 15px, lấp lỗ. Erode 3, gaussian 1,2, cắt sát bbox. Không viền, không bóng.
3. Bổ sung phần model bỏ sót:
   - Tay, đồng hồ, bàn tay: luật màu da (R>185, G>135, B>75) và kim loại (kênh sáng, chênh lệch nhỏ) trong một hình chữ nhật quanh vùng đó.
   - Đạo cụ có màu (thẻ đỏ, thẻ kem): luật màu đỏ hoặc sáng trong vùng thẻ.
   - Chân và quần đen: ngưỡng màu thất bại vì quần đen lẫn nền. Làm sáng ảnh bằng gamma, vẽ tay đường viền đa giác, đưa vào mặt nạ như vùng đặc.
4. Bỏ quầng cam: điểm ảnh sắc ấm có độ sáng V khoảng 0,44 đến 0,58 và bão hòa cao (da thật V trên 0,9). Dùng watershed trên gradient Sobel với điểm đánh dấu trong và ngoài, rồi khóa vùng cánh tay bằng đa giác vẽ tay giao với vùng mở rộng 14px.
5. Sau mọi bước gán, áp lại luật vùng một lần nữa (thứ tự quan trọng, bước sau ghi đè bước trước). Làm mịn mép bằng median 9 đến 11. Lấp khe hở: nếu `keep` đã đúng mà alpha vẫn 0 thì ép alpha bằng 1 trong vùng đó, vì alpha còn nhân với kết quả model.
6. Ghép thử lên nền kem #F7F4EF, phóng to các chỗ khó (khuỷu tay, đồng hồ, thắt lưng, mép thẻ, bàn chân) và soi trước khi dựng.

Mẫu mã nằm ở `${CLAUDE_PLUGIN_ROOT}/tools/mascot-cutout/cut_example.py` và `polys_example.py`. Tọa độ trong đó chỉ đúng cho 4 ảnh Phòng gym, phải vẽ lại cho ảnh mới.

## Kiểm trước khi giao (cả hai đường)
Phóng ảnh đủ lớn (cao 1000px trở lên), ghép trên nền đỏ #E63946 và nền kem #F7F4EF, rồi soi: quầng, lỗ thủng, giày, bàn tay, mép bàn. Xem thumbnail và khung s1 từ chính MP4 ở kích thước thật. Không xem ở dạng ảnh nhỏ rồi kết luận.

## Khi giao
Ghi rõ chỗ còn sót (quầng mờ, mép chưa mịn) và đề nghị ảnh nền trong suốt cho lần sau.
