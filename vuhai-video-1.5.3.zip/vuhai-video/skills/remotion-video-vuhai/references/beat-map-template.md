# Khuôn Beat Map

Mỗi video là một chuỗi beat. Mỗi beat = một Sequence trong Remotion. Viết theo bảng này, KHÔNG viết văn xuôi rồi cắt sau.

| # | Timecode (s) | Frame (30fps) | Hình / hành động | Chữ trên màn hình | Lời đọc (nếu có) | Ghi chú nhịp |
|---|---|---|---|---|---|---|
| 1 | 0:00–0:04 | 0–120 | Mở bằng quan sát cụ thể hoặc con số, không hỏi tu từ | ... | ... | Cut nhanh, không fade dài |
| 2 | 0:04–0:10 | 120–300 | ... | ... | ... | ... |

Quy tắc bắt buộc:

1. **Mỗi beat một ý.** Nếu một beat cần diễn đạt 2 ý, tách thành 2 beat.
2. **Frame chính xác, không mô tả mơ hồ.** "Khoảng giữa video" không dùng được, phải ghi frame bắt đầu/kết thúc.
3. **Mở đầu (beat 1-2):** một quan sát cụ thể, một con số, hoặc một tình huống thật, không mở bằng tuyên ngôn ("Trong thời đại...", "Bạn có bao giờ...").
4. **Khung "Phân vai, không phân hạng":** nếu video nói về vai trò/cấu trúc đội nhóm, kiểm tra beat map có vô tình dùng ngôn ngữ phân hạng (trên/dưới, nâng/hạ) không, sửa lại theo `ngon-ngu-vuhai.md`.
5. **Caption đồng bộ lời đọc:** nếu có voice-over, timecode chữ hiện phải khớp với thời điểm từ đó được nói ra, không sớm hơn 0.3s, không trễ hơn 0.2s.
6. **Kết thúc:** một hành động cụ thể người xem có thể làm, không phải khẩu hiệu chung chung.

Sau khi điền bảng, gửi cho Vũ Hải duyệt trước khi viết bất kỳ dòng code Remotion nào.
