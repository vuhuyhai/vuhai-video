#!/usr/bin/env python3
"""Tải icon Tabler thật (outline) vào assets/<tên>.svg. Dùng: python3 fetch_icon.py clock cash shield-check [--filled]
Lấy từ GitHub raw (tabler/tabler-icons, nhánh main); không được thì thử npm @tabler/icons. Không tải được thì báo lỗi, không tự vẽ thay."""
import sys, os, urllib.request, subprocess, glob, re
names = [a for a in sys.argv[1:] if not a.startswith("--")]; style = "filled" if "--filled" in sys.argv else "outline"
os.makedirs("assets", exist_ok=True); bad = []
for n in names:
    if not re.fullmatch(r"[a-z0-9-]+", n): bad.append(n); continue
    s = None
    for base in ("https://raw.githubusercontent.com/tabler/tabler-icons/main/icons", "https://cdn.jsdelivr.net/npm/@tabler/icons@3.34.1/icons"):
        try: s = urllib.request.urlopen(f"{base}/{style}/{n}.svg", timeout=20).read().decode(); break
        except Exception: pass
    if not s or "<path" not in s: bad.append(n); print("KHÔNG CÓ icon Tabler:", n); continue
    open(f"assets/{n}.svg", "w").write(s); print("ok", n)
if bad: sys.exit("Thiếu: " + ", ".join(bad) + ". Đổi khái niệm hoặc dùng số lớn, không tự vẽ icon.")
