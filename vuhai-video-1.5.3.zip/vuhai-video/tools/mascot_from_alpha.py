#!/usr/bin/env python3
"""Lấy mascot từ ảnh anh Hải gửi MÀ KHÔNG tách nền lại.
Dùng: python3 mascot_from_alpha.py <thư mục ra> anh1.png anh2.png ...
Việc làm: mở ảnh ở chế độ RGBA, KHÔNG convert("RGB") trước khi đọc kênh trong suốt. Nếu ảnh đã có kênh alpha (có điểm alpha 0),
chỉ làm sắc mép (alpha dưới 40 thành 0, từ 235 trở lên thành 255), bỏ mảnh nhỏ rời, cắt sát rồi lưu. Không làm mờ, không xóa quầng.
Nếu ảnh không có điểm trong suốt nào thì in CẢNH BÁO và bỏ qua: lúc đó mới dùng các ví dụ trong mascot-cutout/ và nói rõ với anh Hải đây là bản tách tự động."""
import sys, os, numpy as np
from PIL import Image
from scipy import ndimage as ndi
out = sys.argv[1]; os.makedirs(out, exist_ok=True)
for p in sys.argv[2:]:
    im = Image.open(p); print(os.path.basename(p), im.size, im.mode)
    a = np.array(im.convert("RGBA")).astype(float); al = a[..., 3]
    if (al == 0).mean() < 0.02:
        print("  CẢNH BÁO: ảnh không có nền trong suốt. Dùng ví dụ trong mascot-cutout/ và báo anh Hải rằng đây là tách tự động."); continue
    al2 = np.where(al < 40, 0, np.where(al >= 235, 255, (al - 40) * 255 / 195))
    m = al2 > 0; l, n = ndi.label(m)
    if n:
        z = ndi.sum(m, l, range(1, n + 1)); al2 = np.where(np.isin(l, [j + 1 for j, q in enumerate(z) if q > 0.002 * m.size]), al2, 0)
    a[..., 3] = al2; o = Image.fromarray(a.astype("uint8"), "RGBA"); o = o.crop(o.getchannel("A").getbbox())
    dst = os.path.join(out, os.path.splitext(os.path.basename(p))[0] + ".png"); o.save(dst); print("  ->", dst, o.size)
