# Bước 3, dựng bằng đường Playwright (đọc khi dựng cảnh)

Đường dựng chính của Vũ Hải: một trang HTML điều khiển bằng `setT(t)`, chụp từng khung 30 fps, ghép bằng ffmpeg. Bộ công cụ nằm ở `tools/` của plugin, chạy trong thư mục video. Hyperframes và Remotion chỉ dùng khi anh yêu cầu (xem `engines-khac.md`).

## Cấu trúc thư mục một video
`vo.json` (lời đọc theo khóa cảnh s1, s2...), `video.json` (tên, tiêu đề, kích thước, cảnh cố định thời lượng, cảnh nền tối), `cta.json` (CTA thật của anh Hải), `facts.md`, `scenes.py` (cảnh của video), `banner.json`, `assets/` (mascot PNG nền trong suốt và icon Tabler SVG thật), `fonts/`, rồi các thư mục sinh ra: `audio/`, `mix/`, `frames/`, `out/`.

## Cách dựng
1. Chép `tools/template/scenes_example.py` thành `scenes.py`, viết lại cảnh. `tools/build_page.py` nối khuôn (`_head.py`, `_tail.py`) với `scenes.py` và sinh `index.html` cùng `timing.json`. Sửa chữ hay đổi cảnh thì chạy lại, không sửa tay `index.html`.
2. Mọi thẻ dùng hàm `fc()` (flex, đệm chữ tự động, chiều cao theo nội dung). Hàm `cues()` lấy mốc hiện chữ theo quãng nghỉ trong lời đọc, `land()`, `ev()`, `rowe()` khai báo chuyển động, `mas()` đặt mascot.
3. **Đặt thẻ từ đầu cảnh, không để nửa khung trống.** Bản v2 bị bốn người chấm cùng nêu lỗi này: thẻ mới hiện dần nên 2 giây đầu cảnh còn thưa, nội dung dồn lên trên. Dùng khe cố định (vị trí mỗi thẻ định sẵn từ đầu), thẻ chưa tới lượt thì hiện khung nét đứt giữ chỗ, hoặc cho thẻ vào sớm hơn lời đọc 0,1 đến 0,3 giây.
4. Cảnh CTA nền ink, chữ kem, thẻ đỏ #c73937 chữ kem. Chữ đỏ chỉ đặt trên nền kem hoặc trắng. Màu san hô #FF6A5F trên nền đen bị tính là đỏ trên nền tối, không dùng.
5. Chạy `python3 tools/make_video.py` (hoặc từng giai đoạn: `vo trim page audit audio render mux verify`). `audit` tự nới thẻ và dựng lại tới khi 0 vi phạm đệm chữ. Chỉ sửa một vài cảnh thì `make_video.py page audit audio render mux verify --scenes s9,s10 --force`: chỉ chụp lại các khung của cảnh đó.
6. Font nhúng cục bộ, không gọi Google Fonts: `npm i @fontsource/space-grotesk @fontsource/inter @fontsource/jetbrains-mono`, chép woff2 hai bộ `vietnamese` và `latin` (Space Grotesk 700, Inter 500 và 700, JetBrains Mono 700) vào `fonts/`. Khuôn đã khai báo `@font-face`.
7. Icon: chỉ file SVG thật của Tabler (luật cứng số 1). Hàm `icon()` trong khuôn đã có `assert` kiểm tra.

## Luật khung hình NB

Luật khung hình video theo NB (khung ngang 1920x1080, khung dọc xem mục Video dọc 9:16):

- Màu: nền kem #F7F4EF, chữ và viền #1A1A1A (cấm #000000), đỏ #c73937 dẫn, petrol #245B6B phụ. Không màu thứ ba, không gradient, không blur, không italic, không emoji. Chữ và icon trên nền đỏ luôn là kem #F7F4EF (luật cứng số 2).
- Font: Space Grotesk cho tiêu đề, Inter cho nội dung, JetBrains Mono cho nhãn và số. Số dùng tabular-nums.
- Cỡ chữ: tiêu đề chính 120 tới 150px, tiêu đề cảnh 84 tới 104px, nội dung 40 tới 52px, nhãn 28 tới 32px, chú thích không nhỏ hơn 28px. Lề an toàn 120px hai bên, 90px trên dưới.
- Viền 3, 5 hoặc 8px. Bóng đổ cứng 16px, khối chủ đạo 24px. Góc 4px. Tối đa một khối viền 8px mỗi cảnh.
- Đệm chữ trong thẻ: tối thiểu 38px bên trái, 32px bên trên, 40px bên dưới tính từ mép trong của viền tới chữ (luật cứng số 3). Đệm dưới không nhỏ hơn đệm trên.
- Chuyển động: ease `power3.out`, nhãn dùng `back.out(1.6)`, thẻ vào rồi bóng đổ "đóng" xuống trong 0,2 giây. Cắt thẳng hoặc đẩy ngang 0,4 giây, không chuyển cảnh mờ. Độ nảy nhỏ, không nảy quá đà, không hạt nổ, không ánh sáng tỏa.
- Đồ hoạ: mỗi cảnh có nền hoa văn mờ (opacity 0,10 tới 0,14), icon Tabler nét vuông cỡ lớn, ít nhất một khối số lớn hoặc biểu đồ cột.
- Cảnh cuối có CTA, và khối liên hệ 5 thông tin (VŨ HẢI, 0344 444 000, fitnessviet@gmail.com, facebook.com/vuhai.fitness, vuhuyhai.com) trên nền ink khi khớp với hành động của CTA, kèm tagline Human first. Profit follows. Video nghe thử giọng nội bộ thì được bỏ khối này.

## Chuyển động
Khuôn đã sinh sẵn ba lớp chuyển động: nền hoa văn trôi chậm, icon nhấp nhô nhẹ, thanh chạy 10px ở đáy thẻ theo nhịp đọc (thanh nằm ở đáy thẻ và không tính vào khoảng đệm chữ). Mục đang được đọc nhích ra 14px.

#### Luật chuyển động sống 

- **Không khung nào đứng yên, trừ khung cuối.** Sau khi chữ vào xong vẫn giữ vi chuyển động (nền trôi, icon nhấp nhô, thanh chạy). Kiểm tra bằng bảng contact sheet 2 khung mỗi giây: hai ô liền nhau giống hệt nhau là đang đứng yên.
- **Mỗi lúc một thứ di chuyển chính.** Các phần tử khác chỉ phụ họa nhẹ.
- **Chuyển động có khối lượng:** tăng tốc, nảy rất nhẹ rồi ổn định. Không nảy kiểu hoạt hình. Dùng `back.out(1.2)` hoặc `power3.out` cho thẻ, tránh chuyển động tuyến tính.
- **Cảnh sau vào theo hướng cảnh trước thoát**, cắt khi đang chuyển động nhanh, không cắt giữa lúc mọi thứ đứng yên.
- **Bóng đổ chỉ hiện sau khi thẻ đã đáp** (khuôn đã làm: `box-shadow` tăng dần sau 0,35 giây). Nếu hiện sớm, khối đen lộ ra trước khi thẻ xuất hiện (lỗi đã xảy ra thật).
- **Một màu nhấn duy nhất cho điểm nhấn** (đỏ). Petrol chỉ là màu phụ.
- **Bài kiểm tra im lặng:** tắt tiếng, cho người xem lần đầu xem rồi tóm tắt thành một câu, và nói được họ cần làm gì ở cuối. Không tóm được thì đang có quá nhiều thứ chuyển động.

#### Video dọc 9:16

Dùng khi Vũ Hải nói video dọc, bản dọc, Reels, TikTok, Shorts. Khung 1080x1920, 30fps (`size` trong `video.json`). Mọi luật cứng, màu, font, giọng đọc, nhạc nền, chuyển động liên tục và thanh chạy theo nhịp đọc ở trên giữ nguyên. Chỉ các phần sau đổi.

Quy tắc chung: bản dọc là một bản dựng riêng. Dùng chung file lời đọc và `timing.json` với bản ngang nếu nội dung giống nhau, nhưng viết một script sinh cảnh riêng (ví dụ `gen_doc.py`, hoặc cùng script với tham số khung) và bố cục riêng. Không cắt hay phóng to từ bản ngang. Nên viết script sinh cảnh theo hàm bố cục nhận khung (W, H), để dựng 16:9, 9:16, 1:1 từ cùng một timeline và cùng lời đọc; mỗi khung vẫn có bố cục riêng.

**Vùng an toàn.** Các nền tảng che phần trên (thanh trạng thái, tên tài khoản) và phần dưới (chú thích, nút, thanh tiến độ). Mọi chữ và icon cần đọc nằm trong vùng: lề trái phải 80px, cách mép trên 250px, cách mép dưới 420px. Nửa dưới khung chừa thêm 140px bên phải cho cụm nút thích, bình luận, chia sẻ, nên chữ ở nửa dưới căn trong cột từ x=80 tới x=940. Nền hoa văn, ảnh nền và màu đầy khung thì được tràn ra ngoài vùng an toàn.

**Cỡ chữ** (khung dọc xem trên điện thoại nhỏ hơn, nên chữ không nhỏ hơn mức này):

- Tiêu đề chính 96 tới 120px, tiêu đề cảnh 72 tới 88px.
- Nội dung 44 tới 56px, nhãn 30 tới 34px, chú thích không nhỏ hơn 30px.
- Một câu tối đa 3 dòng. Nếu chữ dài hơn thì tách thành hai cảnh hoặc hai thẻ, không giảm cỡ chữ dưới mức trên.

**Bố cục.**

- Một cột duy nhất. Thẻ và hàng rộng khoảng 920px, xếp chồng theo chiều dọc. Không chia hai cột.
- Mỗi cảnh tối đa 4 mục. Hàng cao ít nhất 200px, khoảng cách giữa các hàng 24px. Quá 4 mục thì tách thành hai cảnh.
- Đệm chữ trong thẻ tối thiểu 30px mỗi phía (luật cứng số 3), đệm dưới không nhỏ hơn đệm trên. Thẻ hàng cao 200px mà chữ hai dòng cỡ 50px chưa đủ chỗ thì tăng chiều cao thẻ và đẩy các hàng dưới xuống, không ép chữ xuống sát đáy.
- Ảnh thật đặt đầu hoặc cuối khối, rộng 920px, vẫn khung 5px và bóng đổ 16px. Khung ảnh có thể cao hơn rộng (4:5) để tận dụng chiều dọc.
- Số lớn và biểu đồ cột dựng đứng chiếm cả chiều rộng cột, là điểm nhấn chính của cảnh.
- Khối liên hệ 5 thông tin ở cảnh cuối xếp thành 5 hàng dọc, nằm hoàn toàn trong vùng an toàn, trên nền ink.

**Nhịp và độ dài.**

- Video dọc dài 30 tới 60 giây. Bản dài hơn thì nói trước, vì người xem dọc bỏ đi nhanh.
- Hook trong 1,5 giây đầu, là một con số, một câu hỏi cụ thể hoặc ảnh có người.
- Mỗi cảnh 4 tới 8 giây, một ý. Cắt nhanh hơn bản ngang một chút nhưng chữ vẫn đứng yên đủ 0,3 giây mỗi từ.
- Tốc độ giọng giữ 1,3. Có thể đề nghị 1,4 cho bản dọc ngắn, nói rõ khi giao.

**Chữ trên màn hình bắt buộc.** Phần lớn người xem dọc tắt tiếng. Bản dọc phải đọc hiểu trọn ý chỉ bằng chữ trên màn hình, mỗi ý chính có câu chữ hiện đủ, kể cả CTA. Nếu chữ trên cảnh chưa đủ ý so với lời đọc, thêm phụ đề đốt sẵn ở vùng giữa khung (cách mép dưới ít nhất 420px), chữ kem trên nền ink, hoặc ink trên nền kem, không dùng chữ tối trên nền đỏ.

**Kiểm tra riêng cho bản dọc.** Chụp snapshot mỗi cảnh ở khung dọc và xem có chữ, icon hay khối liên hệ nào nằm ngoài vùng an toàn không. Xem ảnh ở kích thước điện thoại (thu nhỏ còn khoảng 360px chiều rộng) để chắc chữ vẫn đọc được. Tên file đặt thêm hậu tố `-9x16`. Khi giao, ghi rõ khung 1080x1920 và hỏi Vũ Hải có cần thêm bản 16:9 từ cùng nội dung không.

#### Hiệu ứng và hình ảnh

Muốn video có thêm hiệu ứng và hình ảnh thì kê trước trong `video-plan.md`: mỗi cảnh ghi rõ hình gì, hiệu ứng gì, rồi mới dựng. Mọi thứ phải nằm trong luật NB ở trên. Danh sách chọn:

- Hình từ chính nội dung: sơ đồ vẽ bằng CSS và SVG cho khái niệm trong bài (bản đồ định vị, bông hoa dịch vụ, kiềng 3 chân, biểu đồ cột giờ đông giờ vắng). Sơ đồ ghép từ hình cơ bản (`rect`, `circle`, `line`, `polyline`) là được, nhưng đó là sơ đồ chứ không phải icon, và không dùng để thay icon hay logo. Số liệu trên biểu đồ phải lấy từ nguồn, không bịa. Kiềng 3 chân dựng bằng một thẻ đỏ ở trên, ba đường chân SVG nét 10px đầu vuông, ba thẻ trắng ở dưới.
- Ảnh thật: ảnh của Vũ Hải, ảnh chân dung nguyên màu, có khung 5px và bóng đổ 16px. Ảnh minh hoạ có khung, bóng và treatment theo skill NB. Có thể nghiêng nhẹ tối đa 2 độ. Không tự tải ảnh stock, dùng skill `tai-asset-getfile24h` hoặc ảnh Vũ Hải đưa. Ảnh nhúng thẳng vào cảnh dạng base64, thu về khoảng 720px chiều rộng (JPEG chất lượng 84, khoảng 70 tới 85 KB mỗi ảnh), không gọi mạng. Đặt ảnh ở cảnh khớp nghĩa: ảnh người rời phòng tập ở cảnh hook, ảnh quẹt thẻ ở cảnh nói về quyền được dùng. Luật khung và bóng chỉ dành cho ảnh thật và ảnh minh họa chữ nhật. Ảnh mascot đã tách nền thì không khung, không bóng.
- Ảnh do AI vẽ: dùng skill `chatgpt-images-prompt` để viết prompt, Vũ Hải tạo ảnh rồi đưa lại, sau đó nhúng vào cảnh. Ảnh trong carousel có sẵn cũng dùng được, nhớ cắt bỏ phần chữ nếu chữ đó sẽ trùng với chữ của cảnh.
- Nhân vật mascot Vũ Hải: ảnh của anh, tách nền trong suốt và giữ nguyên tỷ lệ gốc, dùng ở một số cảnh chọn lọc theo mục "Nhân vật mascot Vũ Hải", không phải mọi cảnh.
- Chuyển động chữ và số: số đếm lên, từ khóa được gạch đỏ quét ngang, dòng gõ chữ, thanh tiến độ, nhãn nghiêng nhẹ tối đa 1,5 độ.
- Mô phỏng thao tác: con trỏ bấm nút, thẻ được kéo vào chỗ, nhãn dán đáp xuống. Với video giới thiệu công cụ hoặc giao diện, để con trỏ dẫn cả chuỗi bằng thao tác thật (bấm, gõ, kéo), dữ liệu hiển thị là dữ liệu thật.
- Giao diện app hoặc công cụ của Vũ Hải: chụp giao diện thật bằng Playwright vào `assets/`, lấy màu bằng cách lấy mẫu pixel, dựng lại từng thành phần để chuyển động theo từng phần tử, rồi so cạnh nhau với ảnh gốc. Không bịa màn hình hay tính năng chưa có.

Giữ tiết chế: không quá hai hiệu ứng nổi bật mỗi cảnh, và hiệu ứng không được làm chữ khó đọc.
