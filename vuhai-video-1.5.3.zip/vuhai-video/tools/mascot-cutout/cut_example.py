import numpy as np, sys
from PIL import Image
from scipy import ndimage as ndi
from rembg import remove, new_session
U="/root/.claude/uploads/cb019150-f992-5e0f-96f2-17f47c8a34b8/"
SRC={"n1":"df240ec7-image.png","n2":"695b722a-image.png","n3":"0463c35b-image.png","n4":"a984e56f-image.png"}
OUT="/home/claude/video-output/work/gym90/assets/"
s1=new_session("u2net"); s2=new_session("isnet-general-use")
def ss(x,a,b):
    t=np.clip((x-a)/(b-a),0,1); return t*t*(3-2*t)
for k,f in SRC.items():
    im=Image.open(U+f).convert("RGB"); rgb=np.array(im)
    a1=np.array(remove(im,session=s1,alpha_matting=True,only_mask=True))/255.
    a2=np.array(remove(im,session=s2,only_mask=True))/255.
    a=np.maximum(a1,a2); a=ss(a,0.18,0.45)
    m=a>0.5
    lab,n=ndi.label(m); sz=ndi.sum(m,lab,range(1,n+1))
    keep=np.isin(lab,[i+1 for i,s in enumerate(sz) if s>0.01*m.size])
    keep=ndi.binary_closing(keep,iterations=15); keep=ndi.binary_fill_holes(keep)
    R,G,B=[rgb[...,i].astype(int) for i in range(3)]
    mx=rgb.max(2).astype(int); mn=rgb.min(2).astype(int)
    from PIL import ImageDraw
    POLY={
"n2":[(278,790),(255,900),(247,1000),(247,1100),(238,1200),(222,1285),(218,1300),(200,1330),(160,1380),(145,1405),(145,1445),(155,1490),(290,1500),(365,1475),(402,1450),(402,1230),(405,1100),(415,1000),(425,940),(432,930),(445,940),(480,1000),(520,1080),(530,1150),(527,1250),(524,1290),(540,1320),(535,1420),(560,1450),(650,1475),(740,1480),(790,1465),(822,1430),(820,1390),(800,1340),(760,1300),(722,1290),(708,1200),(668,1100),(650,1000),(612,900),(585,790)],
"n3":[(348,790),(335,900),(318,1000),(305,1100),(298,1200),(290,1260),(265,1278),(262,1330),(240,1335),(185,1400),(178,1430),(180,1452),(300,1465),(400,1448),(458,1422),(458,1395),(440,1370),(448,1310),(462,1275),(470,1200),(475,1100),(490,1000),(500,940),(507,925),(520,950),(560,1050),(580,1100),(590,1200),(588,1262),(585,1280),(607,1350),(597,1405),(610,1432),(700,1470),(840,1472),(872,1442),(870,1405),(855,1380),(830,1345),(800,1330),(790,1290),(740,1275),(722,1200),(722,1100),(715,1000),(690,900),(655,790)],
"n4":[(255,790),(235,900),(215,1000),(200,1100),(185,1200),(170,1250),(160,1285),(158,1310),(165,1340),(120,1370),(100,1400),(82,1415),(82,1450),(100,1462),(225,1472),(330,1448),(325,1400),(320,1330),(335,1290),(346,1260),(348,1200),(350,1100),(380,1000),(420,930),(436,925),(445,1000),(442,1100),(440,1200),(437,1270),(437,1395),(500,1402),(535,1420),(600,1436),(690,1433),(745,1422),(750,1395),(742,1360),(700,1305),(640,1285),(635,1230),(612,1200),(612,1100),(608,1000),(600,900),(585,790)]}
    add=np.zeros(m.shape,bool)
    if k in POLY:
        pm=Image.new("L",(m.shape[1],m.shape[0]),0); ImageDraw.Draw(pm).polygon(POLY[k],fill=255)
        pm=np.array(pm)>0
        lg=ndi.binary_erosion(pm,iterations=2)
        add|=lg
    skin=((R>185)&(G>135)&(B>75)&(R-B>50))|((R>170)&(G>105)&(B>60)&(R-B>60)&(mx>150))
    metal=(mn>100)&((mx-mn)<40)
    def rect(y0,y1,x0,x1):
        z=np.zeros(m.shape,bool); z[y0:y1,x0:x1]=True; return z
    if k=="n1": add|=rect(600,880,460,920)&(skin|metal)
    if k=="n3": add|=rect(560,780,130,330)&(skin|metal)
    if k=="n3":
        r=np.zeros(m.shape,bool); r[420:690,120:420]=True
        add|=r&(((R>150)&(G>90)&(B<150)&(R-B>50))|(((mn>185)|((R>150)&(G<100)))&(np.arange(m.shape[1])[None,:]>=215)))
    if k=="n4":
        sp=Image.new("L",(m.shape[1],m.shape[0]),0); ImageDraw.Draw(sp).polygon([(160,415),(220,385),(300,365),(360,380),(390,420),(400,460),(210,450),(160,422)],fill=255); add|=np.array(sp)>0
        r=np.zeros(m.shape,bool); r[850:1150,520:1024]=True
        add|=r&((mn>120)|((R>150)&(G<100)&(B<100)))
    add=ndi.binary_closing(add,iterations=6); add=ndi.binary_fill_holes(add)
    l2,n2_=ndi.label(add); s2_=ndi.sum(add,l2,range(1,n2_+1))
    add=np.isin(l2,[i+1 for i,v in enumerate(s2_) if v>3000])
    keep=keep|add
    if k in POLY:
        if k=='n4': keep[800:850,:760]=add[800:850,:760]; keep[850:,:]=add[850:,:]
        elif k=='n2': keep[800:,:700]=add[800:,:700]; keep[860:,700:]=add[860:,700:]
        else: keep[800:,:]=add[800:,:]
    if k=='n4': keep[735:800,262:585]=True
    if k=='n3':
        hz=rect(380,800,0,262)&(((R>170)&(R-B>85)&(G>100))|((mx<70)&(mx>20)&(np.arange(m.shape[1])[None,:]>150)))
        hz=ndi.binary_closing(hz,iterations=6); hz=ndi.binary_fill_holes(hz); hz=ndi.binary_opening(hz,iterations=3); hz|=add&rect(380,470,200,262)
        lh,nh=ndi.label(hz); sh=ndi.sum(hz,lh,range(1,nh+1)); hz=np.isin(lh,[i+1 for i,v in enumerate(sh) if v>20000])|(add&rect(380,470,200,262))
        keep[380:800,0:262]=hz[380:800,0:262]
    keep=ndi.binary_closing(keep,iterations=10); keep=ndi.binary_fill_holes(keep)
    from skimage.filters import sobel
    from skimage.segmentation import watershed
    H_,W_=m.shape
    REG={"n1":(430,380,1024,900),"n3":(0,330,330,800),"n4":(240,540,1024,1200)}
    if k in REG:
        x0,y0,x1,y1=REG[k]; pad=40
        Y0,Y1,X0,X1=max(0,y0-pad),min(H_,y1+pad),max(0,x0-pad),min(W_,x1+pad)
        sub=keep[Y0:Y1,X0:X1]; img=rgb[Y0:Y1,X0:X1].astype(float)/255
        g=sum(sobel(ndi.gaussian_filter(img[...,c],1.2)) for c in range(3))
        mk=np.zeros(sub.shape,np.int32); mk[~ndi.binary_dilation(sub,iterations=14)]=1; mk[ndi.binary_erosion(sub,iterations=20)]=2
        ws=watershed(g,mk)==2
        newk=keep.copy(); newk[Y0:Y1,X0:X1]=ws
        reg=np.zeros(keep.shape,bool); reg[y0:y1,x0:x1]=True
        prot=pm if (k in POLY) else np.zeros(keep.shape,bool)
        keep=np.where(reg&~prot,newk,keep)
        keep=ndi.binary_opening(keep,iterations=2)
        import colorsys
        rf=rgb.astype(float)/255; Vv=rf.max(2); Sv=(Vv-rf.min(2))/np.maximum(Vv,1e-6)
        Hh=np.zeros_like(Vv); dd=Vv-rf.min(2)+1e-9
        Hh=np.where(Vv==rf[...,0],((rf[...,1]-rf[...,2])/dd)%6,np.where(Vv==rf[...,1],(rf[...,2]-rf[...,0])/dd+2,(rf[...,0]-rf[...,1])/dd+4))/6
        warm=(Hh<0.12)|(Hh>0.93)
        glow=warm&(((Vv<0.62)&(Sv>0.25))|((Sv>0.74)&(Vv<0.97)))
        band=keep&~ndi.binary_erosion(keep,iterations=22)
        rem=glow&band&reg&~prot
        keep=keep&~ndi.binary_dilation(rem,iterations=1)
        keep=ndi.binary_opening(keep,iterations=3)
        from PIL import ImageDraw as _ID
        from polys import ARM1,ARM4
        def pmask(P):
            q=Image.new("L",(keep.shape[1],keep.shape[0]),0); _ID.Draw(q).polygon(P,fill=255); return np.array(q)>0
        yy,xx=np.mgrid[0:keep.shape[0],0:keep.shape[1]]
        if k=='n1':
            P=pmask(ARM1); z=ndi.binary_dilation(P,iterations=90)&(yy>=640)
            cb=np.where(xx<640,656,np.where(xx<800,664,694)); cards=(yy<cb)
            dark=keep&(Sv<0.16)&(Vv<0.45)
            newz=(keep&ndi.binary_dilation(P,iterations=14))|P|(keep&cards)|dark
            keep=np.where(z,newz,keep)
        if k=='n4':
            P=pmask(ARM4); z=ndi.binary_dilation(P,iterations=90)&(yy<866)
            dark=keep&(Sv<0.16)&(Vv<0.45)&((xx<600)|(yy<740))
            newz=(keep&ndi.binary_dilation(P,iterations=14)&~glow)|P|dark
            keep=np.where(z,newz,keep)
        if k=='n4':
            R4=lambda y0,y1,x0,x1: (yy>=y0)&(yy<y1)&(xx>=x0)&(xx<x1)
            wz=R4(740,868,600,1024)
            keep=np.where(wz,(keep&(Sv<0.16)&(Vv<0.45))|P,keep)
            nz=R4(735,815,262,590)
            keep=keep|(nz&ndi.binary_dilation(keep,iterations=1)) if False else (keep|nz)
        keep=ndi.binary_opening(keep,iterations=2)
        if k=='n4':
            keep=keep|R4(735,812,270,585)
            keep=ndi.binary_fill_holes(keep)
            tz=R4(690,840,262,600)
            vc=ndi.binary_closing(keep,structure=np.ones((61,1),bool))
            keep=keep|(tz&vc&(Vv<0.5))
            keep=ndi.binary_fill_holes(keep)
            keep=ndi.median_filter(keep.astype(np.uint8),size=11)>0
    if k!='n4': keep=ndi.median_filter(keep.astype(np.uint8),size=9)>0
    lab2,n2c=ndi.label(keep); sz2=ndi.sum(keep,lab2,range(1,n2c+1)); keep=np.isin(lab2,[i+1 for i,v in enumerate(sz2) if v>0.01*keep.size])
    a=np.where(keep,np.maximum(a,(m|add).astype(float)),0)
    if k=='n4':
        zz=np.zeros(keep.shape,bool); zz[690:840,262:600]=True; a=np.where(zz&keep,1.0,a)
    a=ndi.binary_erosion(a>0.5,iterations=3).astype(float)
    a=ndi.gaussian_filter(a,1.2)
    dbg=rgb.copy().astype(float); rm=(a<0.5); dbg[rm]=dbg[rm]*0.4+np.array([255,0,255])*0.6; Image.fromarray(dbg.astype(np.uint8)).resize((512,768)).save(f'dbg_{k}.png')
    out=np.dstack([rgb,(a*255).astype(np.uint8)]); o=Image.fromarray(out,"RGBA")
    bb=Image.fromarray((a*255).astype(np.uint8)).point(lambda v:255 if v>20 else 0).getbbox()
    if k=='n4': print('bb',bb, 'col350', ''.join('1' if keep[y,350] else '0' for y in range(700,860,4)))
    o=o.crop(bb); o.save(OUT+k+".png"); print(k,o.size,flush=True)
    bg=Image.new("RGBA",o.size,(247,244,239,255)); bg.alpha_composite(o); bg.convert("RGB").save(f"chk_{k}.png")
