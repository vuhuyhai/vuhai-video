#!/usr/bin/env python3
"""Sinh index.html và timing.json: nối template/_head.py + scenes.py + template/_tail.py rồi chạy.
Chạy trong thư mục video (có vo.json, durs_t.json, pauses.json, video.json, scenes.py, assets/, fonts/)."""
import os, sys
T = os.path.join(os.path.dirname(os.path.abspath(__file__)), "template")
src = open(f"{T}/_head.py").read() + "\n" + open("scenes.py").read() + "\n" + open(f"{T}/_tail.py").read()
g = {"__file__": os.path.abspath("build_page.py"), "__name__": "__page__"}
exec(compile(src, "page", "exec"), g)
