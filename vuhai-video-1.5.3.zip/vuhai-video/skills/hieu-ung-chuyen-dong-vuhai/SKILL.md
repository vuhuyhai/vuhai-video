---
name: "hieu-ung-chuyen-dong-vuhai"
description: "10 hiệu ứng chuyển động từ prompt-motion.com, chỉnh theo luật Neo-Brutalism của Vũ Hải. Dùng cùng remotion-video-vuhai khi dựng video 16:9 hoặc 9:16."
---

# 10 hiệu ứng chuyển động cho video Vũ Hải

Nguồn ý tưởng: https://www.prompt-motion.com/ (đọc ngày 06/10/2026). Chỉ lấy ý tưởng kỹ thuật, không chép prompt hay mã của tác giả. Phần lớn mục trên trang chỉ ghi prompt chung, nên chỉ vài mục có mô tả kỹ thuật chi tiết (khối biến hình theo nhạc, lò xo, kéo thao tác, mờ chuyển động của @twoclipping; quay phim, quất, vạch tốc độ của @notdwd; chữ động của @shneural). Các hiệu ứng còn lại là ý tưởng suy ra, đã viết lại cho đường dựng setT(t) của Vũ Hải.

Luật chung: mọi hiệu ứng nằm trong luật NB của skill remotion-video-vuhai (kem, ink, đỏ, petrol; không gradient, không glow, không làm mờ trang trí, nảy rất nhẹ). Mỗi cảnh tối đa hai hiệu ứng nổi bật. Hiệu ứng không được làm chữ khó đọc hay phá khoảng đệm chữ trong thẻ: chạy lại script đo đệm sau khi thêm.

## 1. Lò xo dạng công thức (thay hàm nảy ob)
Dùng nghiệm đóng của lò xo: chuyển động có khối lượng, nảy rất nhẹ.
```js
function spring(u, z = 0.85, w = 16) { // u: giây từ lúc bắt đầu; trả về 0..1
  if (u <= 0) return 0;
  if (z >= 1) return 1 - (1 + w * u) * Math.exp(-w * u);
  const wd = w * Math.sqrt(1 - z * z);
  return 1 - Math.exp(-z * w * u) * (Math.cos(wd * u) + (z * w / wd) * Math.sin(wd * u));
}
```
Thẻ vào: z 0,85, w 16. Số lớn đáp: z 0,7, w 14. Nhãn: z 0,8, w 20. Cắt cảnh: z 1 (không nảy).

## 2. Khối biến hình (morph)
Một thẻ NB đổi kích thước và màu giữa các trạng thái (nút, thanh tải, trình phát) thay vì mỗi trạng thái một thẻ. Nội suy width, height và màu nền (kem, đỏ, petrol) cùng một tiến trình lò xo. Giữ viền 5px, bóng 16px, góc 4px. Hợp cảnh trước và sau, hoặc quy trình ba bước. Đo đệm chữ ở trạng thái cuối của từng bước.

## 3. Kéo thao tác trực tiếp
Con trỏ kéo thanh tiến độ, bật công tắc, kéo thanh trượt; giá trị hiển thị chạy theo con trỏ. Con trỏ đến trước giá trị 0,1 giây, nhấn xuống thì thu về 0,9 lần. Chỉ dùng cho video giới thiệu công cụ hay giao diện, dữ liệu hiển thị là dữ liệu thật.

## 4. Ống kính đóng khung
Bọc nội dung cảnh trong lớp world, phóng 1,0 lên 1,15 đến 1,3 về phía thẻ đang được đọc bằng lò xo, rồi trả về khi đọc xong. Đặt transform-origin tại tâm thẻ đích. Chữ phải còn trong lề an toàn sau khi phóng. Một lần phóng mỗi cảnh.

## 5. Mờ chuyển động theo khung con (mặc định tắt)
Đây là mờ theo thời gian, không phải làm mờ trang trí. Với đoạn chuyển động nhanh (cắt cảnh, đẩy), chụp 6 khung con cách nhau 1/180 giây quanh mỗi khung (màn trập 180 độ) rồi lấy trung bình bằng numpy hoặc ffmpeg tmix=frames=6. Tốn thời gian render khoảng 6 lần cho các đoạn đó. Chỉ bật khi Vũ Hải muốn mượt hơn, và chỉ ở các giây có chuyển động nhanh.

## 6. Chỉ báo chất lỏng hai mép lò xo
Thanh tiến trình là một đoạn, hai mép dùng hai lò xo khác nhau: mép dẫn đầu nhanh (w 22), mép đuôi chậm (w 12, trễ 0,06 giây). Thanh giãn ra rồi co lại khi chuyển bước.
```js
const head = spring(u, .9, 22), tail = spring(u - .06, .9, 12);
bar.style.left  = (a + (b - a) * tail) + 'px';
bar.style.width = ((a + (b - a) * head) - (a + (b - a) * tail) + w0) + 'px';
```

## 7. Hoán đổi chữ trong khung
Chữ cũ trượt lên và bị cắt (overflow:hidden) trong 0,15 giây, chữ mới trượt từ dưới lên. Đặt chiều cao dòng cố định, đo đệm cho cả hai nội dung, thẻ lấy chiều cao của nội dung dài hơn. Hợp danh sách luân phiên và so sánh hai gói.

## 8. Khớp nhịp nhạc
Phân tích nhạc nền bằng numpy (đỉnh năng lượng), lập lưới nhịp. Kéo mốc vào của thẻ và mốc cắt cảnh về nhịp gần nhất trong ±0,12 giây. Lời đọc luôn ưu tiên hơn: không dời cue quá 0,12 giây. Khi tự tổng hợp nhạc, chọn BPM sao cho một ô nhịp khớp độ dài cảnh trung bình.

## 9. Chuyển cảnh quất bằng vạch tốc độ
Thay làm mờ hướng bằng 3 đến 5 vạch ink ngang kéo theo mép cảnh. Cảnh cũ bị đẩy ra bằng ease mũ trong 0,3 giây, cảnh mới vào cùng hướng, vạch dài theo tốc độ. Không làm mờ, không đứng yên giữa hai cảnh. Tối đa hai lần mỗi video, ở các chỗ chuyển ý lớn.

## 10. Chữ động theo từ
Tiêu đề hook vào từng từ theo mốc từ của lời đọc: mỗi từ phóng 1,0 lên 1,12 rồi về bằng lò xo, từ khóa đổi sang đỏ hoặc có vạch đỏ quét ngang. Một dòng tiêu đề mỗi cảnh. Mỗi từ đứng yên tối thiểu 0,3 giây sau khi cả dòng hiện đủ.

## Kiểm tra sau khi thêm
- Chạy lại script đo đệm chữ và contact sheet, vì hiệu ứng 2, 4, 7 đổi kích thước hay vị trí.
- Contact sheet hai khung mỗi giây: không có hai ô liền nhau giống hệt nhau.
- Hiệu ứng 5 và 9 chỉ soi trên file MP4 cuối, vì ảnh chụp tĩnh không thấy được.