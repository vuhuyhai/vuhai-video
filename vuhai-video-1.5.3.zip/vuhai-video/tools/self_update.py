#!/usr/bin/env python3
"""Cập nhật plugin vuhai-video từ GitHub.
Dùng: python3 self_update.py [--check] [--force] [--quiet]
  --check  chỉ báo có bản mới hay không, không cài
  --force  cài lại kể cả khi cùng phiên bản
  --quiet  dùng cho hook đầu phiên: im lặng nếu không có gì, lưu kết quả 24 giờ, chỉ báo một dòng khi có bản mới
Nguồn đọc từ update.json (repo, branch). Chỉ dùng thư viện chuẩn."""
import sys, os, json, shutil, tempfile, zipfile, time, urllib.request, urllib.error
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ARGS = set(sys.argv[1:]); QUIET = "--quiet" in ARGS
KEEP_DIRS = ["skills", "tools", "brand", "mascot", "commands", "hooks", ".claude-plugin"]
KEEP_FILES = ["README.md", "CHANGELOG.md", "update.json"]
CACHE = os.path.join(os.path.expanduser("~"), ".claude", "vuhai-video-update-check.json")
def say(*a):
    if not QUIET: print(*a)
def ver(s): return tuple(int(x) for x in s.strip().split(".")[:3])
def get(url, timeout=20):
    rq = urllib.request.Request(url, headers={"User-Agent": "vuhai-video-updater"})
    return urllib.request.urlopen(rq, timeout=timeout).read()
def local_version(): return json.load(open(os.path.join(ROOT, ".claude-plugin", "plugin.json")))["version"]
def remote_version(repo, br):
    if U.get("goi"): return json.loads(get(f"https://raw.githubusercontent.com/{repo}/{br}/version.json", 8))["version"]
    return json.loads(get(f"https://raw.githubusercontent.com/{repo}/{br}/.claude-plugin/plugin.json", 8))["version"]
try: U = json.load(open(os.path.join(ROOT, "update.json")))
except Exception: sys.exit(0 if QUIET else "Thiếu update.json trong thư mục plugin.")
repo, br = U["repo"], U.get("branch", "main"); cur = local_version()
if QUIET:  # tối đa một lần kiểm mỗi 24 giờ, mọi lỗi mạng đều bỏ qua
    try:
        c = json.load(open(CACHE))
        if time.time() - c.get("t", 0) < 86400: new = c.get("v"); 
        else: raise KeyError
    except Exception:
        try: new = remote_version(repo, br)
        except Exception: sys.exit(0)
        try: os.makedirs(os.path.dirname(CACHE), exist_ok=True); json.dump({"t": time.time(), "v": new}, open(CACHE, "w"))
        except Exception: pass
    if new and ver(new) > ver(cur): print(f"vuhai-video có bản mới {new} (đang dùng {cur}). Gõ /vuhai-video:cap-nhat để cập nhật.")
    sys.exit(0)
try: new = remote_version(repo, br)
except urllib.error.HTTPError as e:
    sys.exit(f"Không đọc được bản mới từ github.com/{repo} (lỗi {e.code}). Repo chưa tạo, đang để private, hoặc sai tên branch. Kiểm tra update.json.")
except Exception as e: sys.exit(f"Không nối được GitHub: {e}")
print(f"Đang dùng {cur}, trên GitHub là {new}.")
if ver(new) <= ver(cur) and "--force" not in ARGS: print("Đã là bản mới nhất."); sys.exit(0)
if "--check" in ARGS: print("Có bản mới. Chạy lại không kèm --check để cập nhật."); sys.exit(0)
tmp = tempfile.mkdtemp(prefix="vhv-upd-")
try:
    zp = os.path.join(tmp, "r.zip")
    if U.get("goi"):  # gói zip chia phần, nối lại theo thứ tự
        with open(zp, "wb") as f:
            for part in U["goi"]: f.write(get(f"https://raw.githubusercontent.com/{repo}/{br}/{part}", 120))
    else: open(zp, "wb").write(get(f"https://codeload.github.com/{repo}/zip/refs/heads/{br}", 120))
    zipfile.ZipFile(zp).extractall(os.path.join(tmp, "x"))
    src = None
    for d, _, fs in os.walk(os.path.join(tmp, "x")):
        if os.path.basename(d) == ".claude-plugin" and "plugin.json" in fs: src = os.path.dirname(d); break
    if not src: sys.exit("Gói tải về không có .claude-plugin/plugin.json. Không cài.")
    pj = json.load(open(os.path.join(src, ".claude-plugin", "plugin.json")))
    if pj.get("name") != "vuhai-video": sys.exit("Gói tải về không phải plugin vuhai-video. Không cài.")
    bak = os.path.join(os.path.expanduser("~"), ".claude", "vuhai-video-backup", cur)
    shutil.rmtree(bak, ignore_errors=True); os.makedirs(os.path.dirname(bak), exist_ok=True)
    shutil.copytree(ROOT, bak, ignore=shutil.ignore_patterns("__pycache__"))
    for n in KEEP_DIRS:
        s, d = os.path.join(src, n), os.path.join(ROOT, n)
        if os.path.isdir(s): shutil.rmtree(d, ignore_errors=True); shutil.copytree(s, d, ignore=shutil.ignore_patterns("__pycache__"))
    for n in KEEP_FILES:
        s = os.path.join(src, n)
        if os.path.isfile(s): shutil.copy2(s, os.path.join(ROOT, n))
    print(f"Đã cập nhật {cur} sang {pj['version']}. Bản cũ lưu ở {bak}.")
    print("Mở phiên mới để Claude nạp skill và lệnh mới.")
    try: os.remove(CACHE)
    except Exception: pass
finally: shutil.rmtree(tmp, ignore_errors=True)
