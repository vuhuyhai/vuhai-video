# Bước 4, âm thanh (đọc khi làm giọng và nhạc)

**Giọng đọc.** VieNeu-TTS v3 Turbo, giọng "Thiện Minh", tốc độ 1,3 (anh Hải đã chọn, không hỏi lại trừ khi anh đổi ý; nói rõ giọng và tốc độ khi giao). Lý do: miễn phí, giấy phép Apache 2.0 cho dùng thương mại. VieNeu không có tham số tốc độ: tạo ở nhịp gốc rồi `atempo=1.3`, đổi sang wav 24000 Hz mono. Công cụ: `tools/gen_vo.py` (không đối số: tạo tất cả; có khóa cảnh: chỉ tạo lại cảnh đó). Chạy ở nền, vì tạo giọng mất vài phút.

Cài VieNeu một lần mỗi môi trường: tạo venv, `pip install vieneu` (đã dùng 3.8.3), tải mô hình ONNX và codec v3 Turbo từ Hugging Face, chép bằng `cp -rL` ra thư mục thật (symlink của bộ nhớ đệm làm ONNX không đọc được), đặt `VIENEU_DIR`. Gói này không chuyển tiếp `codec_dir` trong `vieneu/v3turbo.py`: vá bằng `sed`, đổi chỗ khởi tạo thành `threads=threads, codec_dir=kwargs.get("codec_dir")`.

Dự phòng khi VieNeu không chạy được, và phải nói rõ với anh: `edge-tts` `vi-VN-NamMinhNeural` `rate="+30%"` (có rủi ro điều khoản khi dùng thương mại), hoặc Piper. Hướng dẫn chi tiết nằm trong `_cu/voice-over.md`.

**Viết lời đọc cho tai nghe.**
- Số viết bằng chữ ("mười hai tháng", "năm một nghìn chín trăm chín mươi tám"). Số điện thoại đọc từng số.
- Bỏ câu tiếng Anh (tagline) và địa chỉ email khỏi lời đọc, chỉ hiện trên màn hình.
- Tên miền `vuhuyhai.com` đọc là "Vũ Huy Hải chấm com". Đường dẫn có gạch chéo đọc: "Vũ Huy Hải chấm com, gạch chéo, sản phẩm không một". Claude không nghe được audio nên luôn nhờ anh Hải nghe lại các chỗ có số, tên và link.
- Lời đọc của CTA lấy đúng chữ anh Hải cung cấp, chỉ đổi số và từ viết tắt thành dạng đọc được.
- Mỗi cảnh một khóa trong `vo.json`, mỗi khóa một file audio.

**Khóa thời lượng theo audio thật.** `tools/trim_vo.py` cắt khoảng lặng đầu và cuối (bản v1.3 chỉ cắt đuôi khi khoảng lặng kéo dài tới hết file, nên không còn cắt mất từ cuối như từ "một"), ghi `durs_t.json` và `pauses.json`. Khuôn trang tính `timing.json`: mở đầu 0,10 giây, đuôi 0,05 giây, cảnh có thời lượng tối thiểu khai báo ở `fixed` trong `video.json` (cảnh CTA đứng yên ít nhất 6 giây). Đổi giọng hoặc tốc độ thì tạo lại toàn bộ audio và chạy lại từ `trim`. Tổng dài hơn mục tiêu thì rút gọn lời đọc ở các cảnh dài nhất, không tăng tốc quá 1,3.

**Phụ đề (v1.5).** `tools/make_srt.py` ra `out/<tên>.srt`, `captions.json`, `words.json`. Mỗi dòng giữ tối thiểu 1,8 giây khi lời đọc còn chỗ; lời đọc nhanh làm dòng ngắn hơn thì `verify.py` ghi P2. `video.json` `"captions":"burn"` đốt phụ đề vào hình (cần chừa vùng 420 px đáy khung 9:16, 90 px khung ngang); mặc định chỉ xuất .srt.

**Mốc theo từng từ.** `cues()` trong khuôn lấy mốc từ quãng nghỉ trong lời đọc, sát hơn ước lượng theo số ký tự. Có whisper thì dùng để lấy mốc từng từ và để so chữ nghe được với `vo.json` (bắt được từ bị cắt hoặc đọc sai link). Máy chưa có whisper thì ghi rõ khi giao.

**Nhạc nền.** `tools/build_audio.py` ghép giọng theo `timing.json`, chuẩn hóa giọng -16 LUFS, tự tổng hợp nhạc bằng numpy (pad, bass, kick nhẹ, hat, pluck, 84 BPM, hạt giống cố định), có ducking hạ khoảng 60 phần trăm theo đường bao giọng, fade vào 1,5 giây, ra 3 giây. Nhạc thấp hơn giọng ít nhất 15 dB. Đường bao giọng `vo_env.npy` có tần số lấy mẫu 24000 Hz, nội suy theo thời gian khi áp lên nhạc 48000 Hz (nếu đổi nguồn giọng thì kiểm tra lại con số này, nếu không ducking lệch dần).

**Độ lớn.** `tools/mix_audio.py`: amix, `alimiter` (limit 0,38), `loudnorm` hai lượt dạng linear về -14 LUFS, đỉnh thật không quá -1,5 dBTP. `verify.py` đo lại trên MP4 cuối (chấp nhận -14 ±1 LUFS, đỉnh không quá -1 dBTP).

**Hiệu ứng âm.** Rất ít, nhỏ hơn nhạc. Khuôn có tiếng thịch trầm nhẹ mỗi lần chuyển cảnh.

**Xem tắt tiếng.** Phần lớn người xem tắt tiếng: chữ trên màn hình phải đủ ý, kể cả CTA. Bản dọc 9:16 là bắt buộc.


## Kiểm giọng bằng whisper
Sau khi sinh giọng, chạy `pip install faster-whisper` (một lần) rồi `python3 tools/check_vo.py`. Cảnh dưới 0.80 phải nghe lại hoặc sinh lại. Lệch ở tên riêng nước ngoài (McCollough, Bharadwaj) là bình thường; lệch ở số, từ khóa hoặc CTA thì sửa. Whisper cũng đoán sai, nên anh Hải vẫn nghe lại các chỗ có số.


## Luật âm thanh v1.5
- Khoảng lặng: tối thiểu 2 khoảng từ 0,35 giây trước điểm đáng giá nhất. Khai báo trong `video.json`: `"khoang_lang": {"s4": 0.5}` (giây thêm vào cuối cảnh s4; nhạc và tiếng hiệu ứng tắt, tiếng thịch chuyển cảnh trả lại đúng lúc cảnh sau vào).
- Tiếng theo sự kiện: `build_audio.py` đọc sự kiện hình trong index.html. Thẻ đáp (land) thịch 170 Hz, chữ bật (pop) 480 Hz, nhãn (tag) 900 Hz, cú đập (slam) 75 Hz, mascot vào (mas) tiếng gió. Cao độ đổi vòng tròn, trùng trong 0,12 giây chỉ giữ một, bỏ qua trong khoảng lặng. Tắt bằng `"sfx": false`.
- Chưa nghe bằng tai: mật độ tiếng cần anh Hải nghe thử ở video đầu tiên rồi chỉnh.
