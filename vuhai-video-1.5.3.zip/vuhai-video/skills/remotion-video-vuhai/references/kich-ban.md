# Bước 2, viết kế hoạch, kịch bản và beat map (đọc khi viết kịch bản)

Bước này phục vụ hai mục tiêu: giữ người xem đến hết video, và dẫn họ tới CTA mà Vũ Hải đã cung cấp. Nền tảng là các nguyên tắc rút từ kho Content Marketing của anh: file `3-kieu-kich-ban-video-tiktok.md` (ba kiểu kịch bản, năm kiểu hook, bảng CTA theo mục tiêu), lý thuyết khoảng trống tò mò (Made to Stick), xung đột giữ chân người nghe (TED Talks Storytelling), nguyên tắc cho trước rồi mới xin và xin nhỏ (Influence).

#### 2.1 Lập `facts.md`

Trước hết lập `facts.md`: mọi con số, tên riêng, mốc năm sẽ lên màn hình hoặc vào lời đọc, mỗi dòng kèm nguồn (link) và ngày lấy. Không có trong `facts.md` thì không lên màn hình. Câu trích dịch từ tiếng Anh ghi rõ "lược dịch" ngay trên khung hình.

#### 2.2 Chọn một trong ba kiểu kịch bản

Quét nguồn rồi chọn đúng một kiểu, ghi lý do vào `video-plan.md` và bài giao.

| Kiểu | Dùng khi nguồn có | Cấu trúc |
|---|---|---|
| **Trước, Sau, Cách làm** | Một kết quả đo được (con số, trạng thái trước và sau). | Hook bằng kết quả, tiết lộ phương pháp, tối đa 3 bước, chốt nhắc lại kết quả để khép vòng với hook, CTA. |
| **Lật ngược nhận thức** | Một quan niệm sai phổ biến hoặc một thông tin phản trực giác. | Hook nêu quan niệm sai, vì sao nhiều người tin, lật lại bằng sự thật và số liệu có trong nguồn, chốt cách hiểu đúng, CTA. |
| **Vấn đề, Cách giải quyết, Điểm chốt** | Nội dung hướng dẫn, danh sách bước, checklist. | Hook gọi đúng vấn đề, tối đa 3 cách xử lý xếp từ dễ làm đến hiệu quả nhất, một câu giải thích vì sao có hiệu quả, CTA. |

- Kiểu Trước, Sau, Cách làm chỉ chạy khi nguồn có kết quả cụ thể. Không có thì đổi sang một trong hai kiểu còn lại và ghi rõ.
- Hai kiểu còn lại chạy được với hầu hết nguồn, dùng làm lựa chọn mặc định.
- Nguồn quá dài thì tóm thành tối đa 3 ý chính trước khi viết.

#### 2.3 Tìm xung đột và chọn điểm trả lời

- Tìm trong nguồn **một xung đột**: hai lực đối nghịch làm kết quả chưa chắc chắn (ví dụ gói rõ ràng và gói chung chung, giá và giá trị khách thấy, điều người ta tin và điều số liệu cho thấy). Không xung đột thì không tò mò, không tò mò thì không còn lý do để xem tiếp.
- Tìm **một số liệu phản trực giác** có trong nguồn. Số này thường là hook hoặc là đảo chiều giữa video.
- Xác định **điểm trả lời** của video: điều đáng giá nhất người xem sẽ nhận được. Điểm này đặt ở gần cuối, ngay trước CTA, không đặt ở giữa.

#### 2.4 Viết hook

- Viết **3 hook** theo năm kiểu: tuyên bố mạnh, câu hỏi, phá khuôn mẫu, bằng chứng (kết quả hoặc số liệu), nêu vấn đề. Chọn một dùng cho video, ghi hai bản còn lại vào `hook-options.md` để Vũ Hải thử.
- Hook dưới 15 từ, vào trong 1,5 tới 3 giây đầu, là một con số, một khẳng định trái với điều người xem nghĩ, một câu hỏi cụ thể hoặc ảnh có người. Không mở bằng tuyên ngôn hay câu hỏi tu từ sáo rỗng.
- Hook chỉ dùng chữ và số có trong `facts.md`.
- Hook là một lời hứa. Điểm trả lời ở phần chốt phải trả lời đúng lời hứa đó. Câu hook đã chọn cũng là câu hook duy nhất trên banner.

#### 2.5 Giữ người xem đến hết (mục tiêu 1)

- **Mở khoảng trống rồi mới đóng.** Trong 10 giây đầu, cho người xem thấy họ đang thiếu một mẩu hiểu biết: một câu hỏi, một con số chưa giải thích, hoặc lời hứa kiểu "cuối video tôi chỉ ba việc làm được ngay". Đừng trình bày thông tin trước khi người xem thấy mình cần thông tin đó. Câu hỏi để tự kiểm: "người xem đang tự hỏi điều gì ở giây này?"
- **Cứ 8 tới 10 giây có một điều mới:** một con số, một đảo chiều, một câu hỏi nhỏ, một ví dụ. Hình đổi cùng nhịp. Cảnh nào không có lý do để người xem ở lại thì bỏ.
- **Không mở bài dài, không tóm tắt lại giữa chừng.**
- **Để điều đáng giá nhất ở cuối.** Gợi sớm, trả sau.
- Mỗi cảnh một ý, và mỗi cảnh có một ý tưởng hình ảnh rõ (một thẻ đổi hình, một biểu đồ, một ảnh), không phải chữ trượt trên nền. Mỗi khung hình dừng lại đều đáng để đăng làm ảnh tĩnh.
- Thà ít cảnh mà làm tốt hơn nhiều cảnh làm vừa. Ba khoảnh khắc đáng nhớ hơn mười cảnh bình thường.
- Ý nào có nhiều mục thì cho từng mục hiện lần lượt theo lời đọc, không đặt một trang tĩnh.
- Chữ trên màn hình đủ ý để xem tắt tiếng vẫn hiểu, cả bản ngang lẫn bản dọc.

#### 2.6 CTA hấp dẫn (mục tiêu 2)

Dùng đúng CTA Vũ Hải cung cấp ở Bước 1. Dựng CTA theo bốn nhịp, theo nguyên tắc cho trước rồi mới xin, và xin một bước nhỏ:

1. **Nhắc lại vấn đề** người xem vừa thấy trong video, bằng chính lời của video, làm câu nối tự nhiên từ điểm trả lời sang CTA.
2. **Món cho trước:** nói rõ họ nhận được gì (tài liệu, checklist, tư vấn, chỗ trong khóa học), đúng như Vũ Hải đã nêu.
3. **Một bước nhỏ duy nhất:** bình luận một từ khóa, bấm một link, lưu video. Không đưa hai hành động cùng lúc.
4. **Hạn thật, nếu có,** để người xem làm ngay (ví dụ ngày khai giảng). Không bịa khan hiếm, không bịa số chỗ, không bịa ưu đãi.

Cách đặt CTA trong video:

- **Hai lần:** một lần nhẹ ở khoảng 40% video, đúng lúc khoảng trống đang mở, một câu như "cuối video tôi gửi bạn ..." (chỉ khi món cho trước có thật); một lần đầy đủ ở cuối.
- Cảnh CTA cuối đứng yên ít nhất 6 giây, chữ trên màn hình trùng với lời đọc, hành động và nơi làm hiện rõ cỡ lớn.
- Khối liên hệ chỉ hiện khi khớp với hành động của CTA. Video nghe thử giọng nội bộ thì được bỏ khối này.
- Kết bằng một hành động người xem làm được, không phải khẩu hiệu. Tagline Human first. Profit follows. chỉ đứng sau CTA, không thay CTA.

#### 2.7 Tỷ lệ thời lượng

- Hook: 1 tới 3 giây.
- Thân bài: khoảng 70 tới 80 phần trăm thời lượng, giao đủ giá trị đã hứa.
- Điểm chốt và CTA: khoảng 10 tới 20 phần trăm thời lượng, trả lời trọn lời hứa của hook rồi kêu gọi.

Với video 60 tới 90 giây, phần CTA cuối có thể dài 6 tới 12 giây vì cần đứng yên đủ để đọc. Nếu vượt tỷ lệ, rút lời đọc ở thân bài.

#### 2.8 Luật nội dung bắt buộc

- Ngôn ngữ theo `references/ngon-ngu-vuhai.md`. Tuyệt đối không dùng em-dash.
- Chỉ dùng chữ, số liệu, tên riêng có trong nguồn. Không thêm nhãn, ví dụ hay số liệu cho đẹp. Ví dụ đã gặp: ảnh carousel có nhãn Spa, Lớp học, Nhà hàng nhưng bài gốc không nhắc, nên video bỏ đi. Biểu đồ minh họa không có số đo thì ghi rõ "Minh họa, không phải số đo" ngay trên khung hình.
- Chữ cần đọc phải hiện đủ và đứng yên tối thiểu 0,3 giây mỗi từ, tính từ lúc cả dòng đã hiện xong. Nhãn ngắn giữ ít nhất 0,8 giây. Vào nhanh rồi giữ, không vào nhanh rồi biến mất.
- Không dùng mẹo bán hàng không có thật: khan hiếm bịa, đếm ngược giả, "chỉ còn N chỗ" khi không đúng.

#### 2.9 Viết `video-plan.md` và beat map

`video-plan.md` gồm: kiểu kịch bản đã chọn và lý do, xung đột, điểm trả lời, hook đã chọn (kèm hai hook dự phòng), các ý chính, câu chốt, CTA nguyên văn của Vũ Hải, thông điệp chính và hook của banner, danh sách chữ và số lấy từ nguồn, phong cách tham chiếu có tên (mặc định là Neo-Brutalism của Vũ Hải), các trạng thái chính của video kèm mốc giờ, danh sách lớp hình (nền, thẻ, chữ, icon, đồ thị), kế hoạch âm thanh (giọng, nhạc, hiệu ứng, chỗ im lặng), hướng hiệu ứng và hình ảnh.

Sau đó viết beat map theo khuôn `references/beat-map-template.md`. Ngoài các cột của khuôn và cột "mascot" (có hoặc không, kèm tên tư thế, theo mục "Nhân vật mascot Vũ Hải"), **thêm hai cột**:

- **Vai trò giữ chân:** hook, mở khoảng trống, điều mới, đảo chiều, đóng khoảng trống, CTA nhẹ, CTA đầy đủ.
- **Lý do ở lại:** một câu nói người xem đang chờ điều gì ở cảnh này.

Viết thẳng theo mốc thời gian, không viết văn xuôi rồi cắt. Nếu file `references/beat-map-template.md` chưa có hai cột này, thêm chúng khi lập beat map.

#### 2.10 Tự soát kịch bản trước khi đưa Vũ Hải duyệt

1. Có một xung đột rõ không?
2. Hook có số, khẳng định trái ý hoặc câu hỏi cụ thể, dưới 15 từ, và số đó có trong `facts.md` không?
3. Khoảng trống có được mở trong 10 giây đầu và đóng ở phần chốt không? Hook có được trả lời trọn không?
4. Có đoạn nào hơn 10 giây mà không có điều mới không?
5. Điều đáng giá nhất có nằm ở cuối, ngay trước CTA không?
6. CTA có đúng nguyên văn Vũ Hải đưa, đúng một bước, có món cho trước, và hạn có thật không? Có hai lần nhắc không?
7. Cảnh CTA cuối có đứng yên đủ 6 giây không?
8. Có chỗ nào bịa số liệu, khan hiếm hay ưu đãi không?
9. Xem tắt tiếng có hiểu hết ý và biết phải làm gì không?
10. Banner đã có đúng một thông điệp chính và một câu hook (chính là hook đã chọn) chưa?

Trình kế hoạch, beat map, danh sách lớp, kế hoạch âm thanh và ba hook cho Vũ Hải duyệt trước khi dựng, trừ khi anh đã bảo dựng luôn. Đây là bước rẻ nhất để sửa.

#### 2.11 Độ dài

Bản mạng xã hội 60 tới 90 giây chỉ giữ hook, khoảng ba ý và CTA. Nếu Vũ Hải muốn đủ ý bài dài, video có giọng đọc sẽ dài theo lời đọc (bài khóa học 5 buổi, 14 cảnh, tốc độ 1,3 ra 3 phút 6 giây; bài Phòng gym đóng cửa, 16 cảnh, ra 120 giây sau khi rút gọn lời đọc). Báo trước độ dài và thời gian render. Nên đề nghị thêm một bản teaser 15 giây (hook 2 giây, một khoảnh khắc, một CTA), vì dạng ngắn này được làm nhiều nhất và dễ đăng nhất, và dẫn người xem về bản dài hoặc bài viết.

Viết lời đọc cho tai nghe (chi tiết ở Bước 4, mục lời đọc).
