#!/usr/bin/env python3
"""Tạo thư mục video mới. Dùng: python3 new_video.py <tên-video> [--dọc|--ngang] [--dir work]
Sinh: video.json, cta.json, banner.json, vo.json, scenes.py (mẫu), fonts/, assets/, hook-options.md, facts.md.
Sau đó: đưa ảnh mascot PNG nền trong suốt vào assets/ (lấy từ thư mục máy anh: Mô hình Vũ Hải minecraft), sửa vo.json + scenes.py + cta.json, chạy make_video.py."""
import sys, os, json, shutil
H = os.path.dirname(os.path.abspath(__file__)); a = [x for x in sys.argv[1:] if not x.startswith("--")]
if not a: sys.exit(__doc__)
name = a[0]; land = "--ngang" in sys.argv; base = sys.argv[sys.argv.index("--dir") + 1] if "--dir" in sys.argv else "."
d = os.path.join(base, name); os.makedirs(d + "/assets", exist_ok=True)
shutil.copytree(f"{H}/template/fonts", d + "/fonts", dirs_exist_ok=True)
size = [1920, 1080] if land else [1080, 1920]
def w(p, o):
    if not os.path.exists(f"{d}/{p}"): open(f"{d}/{p}", "w").write(o if isinstance(o, str) else json.dumps(o, ensure_ascii=False, indent=1))
w("video.json", {"name": name + ("-16x9" if land else "-9x16"), "title": name, "size": size, "fixed": {}, "dark": [], "procs": 2})
w("cta.json", {"lam_gi": "", "o_dau": "", "nhan_gi": "", "han": "", "ghi_chu": "Anh Hải điền. Để trống = CTA trung tính và phải nói rõ khi giao.", "must": [], "share": []})
w("banner.json", {"template": "B", "msg": "", "red": "", "hook": "", "label": "", "stats": [], "mascot": "auto", "tag": "", "size": [1920, 1080]})
w("vo.json", {"g1": "", "g2": ""})
w("facts.md", "# Số liệu và nguồn\n(mỗi dòng: số hoặc tên, link nguồn, ngày lấy)\n")
w("hook-options.md", "# 3 hook\n1. (dùng)\n2. (dự phòng)\n3. (dự phòng)\n")
if not os.path.exists(d + "/scenes.py"): shutil.copy(f"{H}/template/scenes_example.py", d + "/scenes.py")
print("Đã tạo", d, "\nBước tiếp: python3 setup_env.py ; python3 fetch_icon.py <tên icon...> ; đưa mascot vào assets/ ; điền vo.json, scenes.py, cta.json ; python3 make_video.py")
