# Thay đổi

## 1.5.3
- Ghép lại hai nhánh phiên bản. Bản GitHub 1.5.2 thiếu Cổng 1, bản trên máy anh thiếu phụ đề, khung mẫu, dải ảnh và nút cập nhật. Bản này có đủ cả hai.
- Đưa lại skill `chon-tin-vuhai` và `tools/lay_tin.py` (Cổng 1: lấy tin từ app SỨC BẬT, xếp hạng, chờ anh Hải chốt tin và CTA). Giữ nguyên từ bản trên máy.
- README ghi đủ 6 skill và bước 0 lấy tin.

## 1.5.2
- Nút cập nhật đọc được repo kiểu gói zip chia phần (update.json mục `goi`, file version.json), để đẩy lên GitHub bằng trình duyệt mà không cần giữ cấu trúc thư mục.

## 1.5.1
- Nút cập nhật: lệnh `/vuhai-video:cap-nhat` (thêm `--check` để chỉ kiểm tra). Đọc update.json, so phiên bản với GitHub, tải bản mới, lưu bản cũ ở ~/.claude/vuhai-video-backup/<phiên bản>, rồi ghi đè. Chỉ chạy khi anh gõ lệnh, không tự chạy ngầm. Chỉ dùng thư viện chuẩn của Python.
- Cần tạo repo GitHub public khớp với update.json (mặc định vuhuyhai/vuhai-video, branch main).

## 1.5.0
Ý tưởng lấy từ lemo-opuscar (DIRECTOR.md, TECHNIQUE.md), viết lại cho khuôn Neo-Brutalism của anh Hải.
- Mục 1, phụ đề và mốc từ: thêm tools/make_srt.py (giai đoạn `srt`). Ra out/<tên>.srt, captions.json, words.json. Có faster-whisper thì mốc từng từ lấy từ giọng thật, không có thì ước lượng từ quãng nghỉ và ghi rõ. Mỗi dòng phụ đề giữ tối thiểu 1,8 giây khi còn chỗ. `video.json` có `"captions":"burn"` thì khuôn trang đốt phụ đề sẵn (từ đang đọc chuyển đỏ), mặc định `"srt"` chỉ xuất file. `cues()` dùng mốc từ của whisper khi có (hiệu ứng 10, chữ động theo từ, hết phải ước lượng).
- Mục 2, khung mẫu: `make_video.py mau` chạy vo, trim, srt, page, audit rồi chụp 3 khung (hook, cảnh đáng nhớ nhất, CTA) ra out/khung-mau.png và dừng để anh Hải duyệt. Chọn cảnh bằng `video.json` `"mau"`. Duyệt xong mới chạy cả chuỗi.
- Mục 3, dải ảnh: tools/strip.py (giai đoạn `strip`, chạy sau verify). Quanh mỗi chỗ chuyển cảnh và mỗi lần mascot vào, lấy khung cách nhau 0,2 giây từ chính file MP4, ra out/strip.png và out/strip/*.png.
- Mục 4, luật âm thanh: `video.json` `"khoang_lang": {"s4": 0.5}` thêm khoảng lặng cuối cảnh (nhạc và tiếng hiệu ứng tắt, tiếng thịch chuyển cảnh trả lại đúng lúc cảnh sau vào). build_audio.py đọc sự kiện hình trong index.html và đặt tiếng riêng cho mỗi thẻ đáp, chữ bật, nhãn, cú đập và mascot vào (đổi cao độ vòng tròn, tắt bằng `"sfx": false`). verify.py kiểm tối thiểu 2 khoảng lặng.
- Mục 5, thời gian giữ chữ: verify.py kiểm mỗi thẻ giữ trên màn hình tối thiểu số ký tự chia 15 cộng 1,5 giây (mức của tiếng Anh, chỉnh bằng `toc_do_doc`, `giu_chu_nen`). Mức P1, không chặn giao.
- verify.py thêm kiểm phụ đề (có .srt, không chồng dòng, vùng an toàn khi đốt sẵn) và mức P2 cho thông tin.
- Sửa lỗi: make_video.py chạy giọng VieNeu bằng Python của venv (VH_BASE/v/bin/python), không còn báo thiếu `vieneu`.
- Sửa lỗi: khuôn trang áp dụng fix.json (trước đây `audit.py --fix` không có tác dụng) và audit.py tính lại độ nới cho thẻ flex căn giữa; vòng sửa của make_video.py dựng lại trang không fix trước khi đo.
- Không làm (chờ anh Hải duyệt): kiểm số trên màn hình so với facts.md.

## 1.4.0
- Thêm tools/mascot_from_alpha.py: lấy mascot từ ảnh anh Hải gửi bằng chính kênh alpha, chỉ làm sắc mép và cắt sát, không tách lại.
- tach-nen-mascot-vuhai: thêm Bước 0 kiểm chế độ ảnh và alpha trước, cấm convert RGB rồi tách lại ảnh đã trong suốt, thêm bước soi ảnh phóng to trên nền đỏ và nền kem.
- quy-trinh-render-vuhai: thêm mục việc chạy dài (nohup, đọc log) và checklist giao file về máy (100 MB, fileUuid, stagedPath, không đè bằng unzip, tên file có dấu).
- Thêm tools/LESSONS.md ghi các lỗi của phiên Buổi 2 đến 5.

## 1.3.6
- mascot/pose: thêm 6 mascot có đạo cụ cho khóa Thiết kế sản phẩm Buổi 1 (soi-the-tap, cong-tap, hai-hop-goi, the-va-toa-nha, gio-dong-vang, bay-nut-p) kèm gợi ý chọn theo chủ đề. banner.json nhận thêm mascot_h (chiều cao mascot) cho ảnh có đạo cụ cần to hơn.

## 1.3.5
- Thumbnail: banner.py chỉ còn đúng 3 mẫu A giant-lon, B giant-ngang, C giant-dai (khớp design system Vũ Hải), 1920x1080, tự co chữ vừa khung, giãn dòng 1,04 cho dấu tiếng Việt, chữ trên nền đỏ luôn trắng. banner.json mới: template, msg, hook, label, stats, mascot, tag. Bỏ mẫu cũ (nền kẻ ô, sân khấu petrol, thẻ hook).
- Thêm mascot/pose (7 tư thế nền trong suốt, kèm catalog.json) và brand/ (logo Vũ Hải gốc: bản chính và bản kem).
- mux.py và verify.py: banner 16:9 trong video dọc được đặt giữa nền kem, không kéo méo; verify so khung 0 theo cùng cách.
- new_video.py: banner.json mặc định theo mẫu B.

## 1.3.4
- Banner ưu tiên ảnh toàn thân: thêm kho mascot/full (10 ảnh toàn thân mới của anh Hải, đã cắt sát nền trong suốt) và mascot/catalog.json. banner.py nhận mascot "auto" kèm tag, tự cắt sát ảnh, tăng cỡ mascot cho ảnh toàn thân (cao hơn 1000px). new_video.py đặt mặc định mascot auto.

## 1.3.3
- banner.py dựng lại: không còn khoảng trống. Thông điệp cỡ lớn tự co vừa khung, cụm đỏ thành khối đỏ chữ kem, mascot to đứng trên nền petrol, thẻ hook neo ở đáy, thanh chân trang VŨ HẢI và Human first. Profit follows. Đo bằng số, thông điệp không đè mascot. Dấu câu sau cụm đỏ tự bỏ.

## 1.3.2
- check_vo.py: kiểm giọng bằng whisper (faster-whisper, mô hình small, chạy CPU). So lời nghe được với vo.json từng cảnh, quy số về chữ, báo cảnh dưới 0.80 cần nghe lại. Chạy sau bước vo: `python3 tools/check_vo.py`.

## 1.3.1
- setup_env.py: dựng lại môi trường (Playwright, Pillow, numpy, venv VieNeu đã vá codec_dir, mô hình) trong container mới bằng một lệnh.
- fetch_icon.py: tải icon Tabler thật. new_video.py: tạo thư mục video mới (video.json, cta.json, banner.json, vo.json, scenes.py, fonts).
- template/fonts: 8 font có sẵn trong plugin.

## 1.3.0
- Skill chính từ 73 KB còn 9,6 KB (bản lõi). Phần còn lại tách vào references/, chỉ mở khi tới bước đó. Hyperframes và Remotion chuyển vào engines-khac.md, tài liệu cũ (edge-tts, nền tối) vào _cu/.
- Sửa mâu thuẫn trong skill: giọng (bỏ Nam Minh 1,15 và 1,2), đỉnh âm -1,5 dBTP, bỏ phần dựng bằng npm của Hyperframes khỏi đường chính.
- Công cụ mới: make_video.py, build_page.py + template/ (khuôn flex tự đệm chữ, dựng lại đúng từng byte trang v4), verify.py, mix_audio.py, mux.py, banner.py, dupcheck.py, GRADER.md.
- trim_vo.py: sửa lỗi cắt mất từ cuối clip.
- render.py: JPEG 95 thay PNG, chụp theo cảnh (--scenes), kích thước theo timing.json.
- audit.py, build_audio.py: chạy theo thư mục video, kích thước theo timing.json, danh sách cảnh lấy từ vo.json.
- Người chấm độc lập: chỉ nhận hình và số đo do verify.py tạo, dùng mô hình nhỏ, chấm đầy đủ video đầu của một khuôn.

## 1.5.0 (nhánh trên máy, đã gộp vào 1.5.3)
- Thêm Cổng 1 vào plugin: skill `chon-tin-vuhai` và `tools/lay_tin.py`. `lay_tin.py` đọc `tin-cong-khai.json` và `tin-the-gioi.json` của app SỨC BẬT, chỉ dùng thư viện chuẩn, mọi từ khóa tiếng Anh khớp trọn từ.
