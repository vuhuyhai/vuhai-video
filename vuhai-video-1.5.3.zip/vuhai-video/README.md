# vuhai-video 1.5.3

Plugin dựng video cho Vũ Hải: 16:9 và 9:16, Neo-Brutalism, mascot Minecraft, giọng VieNeu Thiện Minh 1,3.

## Skill (6)
- chon-tin-vuhai: Cổng 1, lấy tin ngành từ app SỨC BẬT, trình 5 tin ứng viên, chờ anh Hải chốt tin và CTA rồi giao sang dựng video.
- remotion-video-vuhai: bản lõi (luật cứng, thứ tự việc, brief) cộng `references/` mở theo bước (kịch bản, dựng cảnh, mascot, âm thanh, duyệt và giao).
- quy-trinh-render-vuhai: chạy cả chuỗi bằng `tools/make_video.py`.
- tach-nen-mascot-vuhai, chay-online-drive-vuhai, hieu-ung-chuyen-dong-vuhai: như cũ.

## Công cụ (tools/)
lay_tin.py (Cổng 1: lấy và xếp hạng tin), make_video.py (cả chuỗi; `mau` chỉ chạy tới 3 khung mẫu để duyệt), make_srt.py (phụ đề, mốc từ), style_frames.py (khung mẫu), strip.py (dải ảnh 0,2 giây từ MP4), gen_vo.py, trim_vo.py (đã sửa lỗi cắt mất từ cuối), build_page.py và template/ (khuôn trang, ví dụ cảnh), audit.py (đệm chữ), build_audio.py và mix_audio.py (giọng, nhạc, loudnorm), render.py (JPEG, chụp theo cảnh), mux.py (banner thay khung 0), banner.py (3 mẫu thumbnail A, B, C), verify.py (kiểm tự động, ra hình cho người chấm), dupcheck.py (việc trùng trong hàng đợi), GRADER.md (mẫu lệnh cho người chấm), mascot-cutout/.

## Cần có
Python 3, playwright và Chromium, Pillow, numpy, ffmpeg, model VieNeu (biến VIENEU_DIR). Tùy chọn: whisper (so chữ nghe được với lời đọc), rembg và onnxruntime (tách nền).

Xem CHANGELOG.md.

## Bắt đầu một video (phiên mới)
0. `python3 tools/lay_tin.py` rồi chốt tin và CTA theo skill `chon-tin-vuhai`. Đã có sẵn nội dung thì bỏ qua.
1. `python3 tools/setup_env.py` (lần đầu mỗi phiên, vài phút để tải mô hình).
2. `python3 tools/new_video.py <tên> --dọc` (hoặc `--ngang`), rồi `cd <tên>`.
3. `python3 ../tools/fetch_icon.py <tên icon Tabler...>`; đưa mascot PNG nền trong suốt vào `assets/`.
4. Điền `vo.json`, `scenes.py`, `cta.json`, `banner.json`.
5. `python3 ../tools/make_video.py mau`, gửi out/khung-mau.png cho anh Hải duyệt.
6. `python3 ../tools/make_video.py` (cả chuỗi). Kèm out/<tên>.srt và out/strip.png.

## Cập nhật
Gõ `/vuhai-video:cap-nhat` để lấy bản mới nhất từ GitHub (nguồn ở update.json). `--check` chỉ kiểm tra, không cài.
