import os
import sys, json
from playwright.sync_api import sync_playwright
from PIL import Image
T=json.load(open("timing.json")); S,D=T["START"],T["DUR"]
ts=[float(x) for x in sys.argv[1:]] or [S[k]+D[k]-0.4 for k in S]
with sync_playwright() as p:
    b=p.chromium.launch(args=["--allow-file-access-from-files"]); pg=b.new_page(viewport={'width':1920,'height':1080})
    pg.goto('file://'+os.path.abspath('index.html')); pg.evaluate("document.fonts.ready"); pg.wait_for_timeout(700)
    ims=[]
    for i,t in enumerate(ts):
        pg.evaluate(f"setT({t})"); pg.screenshot(path=f"snap_{i}.png"); ims.append(Image.open(f"snap_{i}.png").resize((640,360)))
    b.close()
w=min(3,len(ims)); rows=(len(ims)+w-1)//w
sheet=Image.new("RGB",(640*w,360*rows),"white")
for i,im in enumerate(ims): sheet.paste(im,((i%w)*640,(i//w)*360))
sheet.save("sheet.png")
