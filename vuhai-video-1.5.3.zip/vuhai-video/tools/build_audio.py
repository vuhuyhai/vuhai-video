#!/usr/bin/env python3
# Ghép giọng đọc theo timing.json, tổng hợp nhạc nền (numpy) có ducking theo đường bao giọng.
import json, wave, subprocess, os, re
import numpy as np

W = os.getcwd()  # chạy trong thư mục video
P = f"{W}/mix"
os.makedirs(P, exist_ok=True)
T = json.load(open(f"{W}/timing.json"))
START, DUR, TOTAL, LEAD = T["START"], T["DUR"], T["TOTAL"], T["LEAD"]
KEYS = list(json.load(open(f"{W}/vo.json")))
CFG = json.load(open(f"{W}/video.json")); LANG = T.get("LANG", {})
# sự kiện hình (thẻ đáp, chữ bật, mascot vào) do khuôn trang ghi trong index.html: tiếng hiệu ứng đặt đúng khung hình đó
EVJ = json.loads(re.search(r"const EV=(\{.*?\});\r?\nconst ", open(f"{W}/index.html", encoding="utf-8").read(), re.S).group(1)) if os.path.exists(f"{W}/index.html") else {}
SIL = [(round(START[k] + DUR[k] - x, 3), round(START[k] + DUR[k], 3)) for k, x in LANG.items() if k in START and x > 0]

VSR = 24000  # đúng tần số của file giọng, dùng để đọc đường bao


def readwav(p):
    with wave.open(p) as w:
        assert w.getframerate() == VSR and w.getnchannels() == 1, (p, w.getframerate(), w.getnchannels())
        a = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768
    return a


def writewav(p, a, sr):
    a = np.clip(a, -1, 1)
    with wave.open(p, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes((a * 32767).astype(np.int16).tobytes())


# ---------- giọng đọc ----------
n = int((TOTAL + 0.5) * VSR)
vo = np.zeros(n, dtype=np.float32)
for k in KEYS:
    a = readwav(f"{W}/audio/{k}_t.wav")
    i0 = int((START[k] + LEAD) * VSR)
    vo[i0:i0 + len(a)] += a
writewav(f"{P}/vo_raw.wav", vo, VSR)
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", f"{P}/vo_raw.wav", "-af",
                "loudnorm=I=-16:TP=-1.5:LRA=7", "-ar", str(VSR), "-ac", "1", f"{P}/vo_n.wav"], check=True)
vo = readwav(f"{P}/vo_n.wav")[:n]
if len(vo) < n:
    vo = np.pad(vo, (0, n - len(vo)))
writewav(f"{P}/vo.wav", vo, VSR)

# đường bao giọng (24000 Hz) làm mịn
win = int(0.12 * VSR)
env = np.convolve(np.abs(vo), np.ones(win) / win, mode="same")
env = np.clip(env / 0.05, 0, 1)
np.save(f"{W}/vo_env.npy", env)

# ---------- nhạc nền ----------
SR = 48000
L = int((TOTAL + 0.5) * SR)
tt = np.arange(L) / SR
BPM = 84
beat = 60 / BPM
bar = 4 * beat
rng = np.random.default_rng(7)  # cố định hạt giống để render lặp lại giống hệt
mus = np.zeros(L, dtype=np.float64)


def note(f):
    return 440.0 * 2 ** ((f - 69) / 12)


# Am - F - C - G
chords = [[57, 60, 64], [53, 57, 60], [48, 52, 55], [55, 59, 62]]
roots = [45, 41, 36, 43]
nb = int(np.ceil((TOTAL + 0.5) / bar))
for b in range(nb):
    t0 = b * bar
    ch = chords[b % 4]
    i0, i1 = int(t0 * SR), min(L, int((t0 + bar) * SR))
    seg = tt[i0:i1] - t0
    ln = len(seg)
    atk = np.minimum(1, seg / 0.6)
    rel = np.minimum(1, (bar - seg) / 0.5)
    pad = np.zeros(ln)
    for m in ch:
        f = note(m)
        pad += np.sin(2 * np.pi * f * seg) + 0.5 * np.sin(2 * np.pi * f * 2 * seg + 0.3) + 0.25 * np.sin(2 * np.pi * f * 1.004 * seg)
    mus[i0:i1] += 0.10 * pad * atk * rel / 3
    # bass trên phách 1 và 3
    for bt in (0, 2):
        s0 = int((t0 + bt * beat) * SR)
        s1 = min(L, s0 + int(beat * 1.6 * SR))
        s = tt[s0:s1] - (t0 + bt * beat)
        mus[s0:s1] += 0.30 * np.sin(2 * np.pi * note(roots[b % 4]) * s) * np.exp(-s * 2.2)
    # kick nhẹ phách 1 và 3
    for bt in (0, 2):
        s0 = int((t0 + bt * beat) * SR)
        s1 = min(L, s0 + int(0.28 * SR))
        s = tt[s0:s1] - (t0 + bt * beat)
        ph = 2 * np.pi * (45 * s + (110 - 45) * (1 - np.exp(-s * 28)) / 28)
        mus[s0:s1] += 0.42 * np.sin(ph) * np.exp(-s * 13)
    # hat nhẹ trên nốt móc đơn
    for e in range(8):
        s0 = int((t0 + e * beat / 2) * SR)
        s1 = min(L, s0 + int(0.05 * SR))
        if s1 <= s0:
            continue
        nz = rng.standard_normal(s1 - s0)
        nz = np.diff(nz, prepend=0)
        mus[s0:s1] += 0.05 * nz * np.exp(-np.arange(s1 - s0) / SR * 70) * (1.0 if e % 2 else 0.6)
    # pluck rải nốt
    for e in range(8):
        s0 = int((t0 + e * beat / 2) * SR)
        s1 = min(L, s0 + int(0.5 * SR))
        s = tt[s0:s1] - (t0 + e * beat / 2)
        m = ch[[0, 1, 2, 1, 0, 2, 1, 2][e]] + 12
        mus[s0:s1] += 0.07 * np.sin(2 * np.pi * note(m) * s) * np.exp(-s * 6)

# SFX rất nhẹ ở mỗi lần chuyển cảnh: tiếng thịch trầm + quét nhẹ
for k in KEYS:
    s0 = int(START[k] * SR)
    s1 = min(L, s0 + int(0.45 * SR))
    s = tt[s0:s1] - START[k]
    mus[s0:s1] += 0.35 * np.sin(2 * np.pi * 70 * s) * np.exp(-s * 9)
    nz = np.convolve(rng.standard_normal(s1 - s0), np.ones(40) / 40, mode="same")
    mus[s0:s1] += 0.10 * nz * np.sin(np.pi * np.clip(s / 0.4, 0, 1)) ** 2

# tiếng hiệu ứng theo sự kiện hình (v1.5): mỗi thẻ đáp xuống có một tiếng riêng, đổi cao độ vòng tròn để không thành súng máy
sf = np.zeros(L, dtype=np.float64)
if CFG.get("sfx", True):
    pit = [1.0, 1.12, 0.94, 1.06]; last = -9; n_sf = 0
    def seg(t, dur):
        s0 = int(t * SR); s1 = min(L, s0 + int(dur * SR)); return s0, s1, tt[s0:s1] - t
    for e in sorted(EVJ.values(), key=lambda e: e["t"]):
        t, kd = e["t"], e["k"]
        if kd not in ("land", "pop", "tag", "slam", "mas") or t < 0.05 or t > TOTAL - 0.2: continue
        if any(a - 0.1 <= t <= b - 0.05 for a, b in SIL): continue  # trong khoảng lặng thì im
        if kd != "mas" and t - last < 0.12: continue
        pm = pit[n_sf % 4]; n_sf += 1; last = t
        if kd == "land":
            s0, s1, s = seg(t, 0.16); sf[s0:s1] += 0.55 * np.sin(2 * np.pi * 170 * pm * s) * np.exp(-s * 26)
            c0, c1, c = seg(t, 0.008); sf[c0:c1] += 0.25 * rng.standard_normal(c1 - c0) * np.exp(-c * 300)
        elif kd == "pop":
            s0, s1, s = seg(t, 0.10); sf[s0:s1] += 0.40 * np.sin(2 * np.pi * 480 * pm * s) * np.exp(-s * 34)
        elif kd == "tag":
            s0, s1, s = seg(t, 0.06); sf[s0:s1] += 0.25 * np.sin(2 * np.pi * 900 * pm * s) * np.exp(-s * 60)
        elif kd == "slam":
            s0, s1, s = seg(t, 0.32); sf[s0:s1] += 0.85 * np.sin(2 * np.pi * 75 * s) * np.exp(-s * 12)
        elif kd == "mas":
            s0, s1, s = seg(t, 0.42); nz = np.convolve(rng.standard_normal(s1 - s0), np.ones(60) / 60, mode="same")
            sf[s0:s1] += 0.30 * nz * np.sin(np.pi * np.clip(s / 0.4, 0, 1)) ** 2
    if np.abs(sf).max() > 0: sf *= 10 ** (-20 / 20) / np.abs(sf).max()  # đỉnh -20 dBFS, nhỏ hơn giọng
print("tiếng hiệu ứng theo sự kiện:", n_sf if CFG.get("sfx", True) else "tắt (video.json sfx=false)", "| khoảng lặng:", SIL)

# chuẩn hóa mức nhạc: RMS khoảng -28 dBFS trước ducking
rms = np.sqrt(np.mean(mus ** 2))
mus *= (10 ** (-28 / 20)) / rms

# ducking: hạ khoảng 60% khi có giọng, nội suy đường bao theo thời gian (không lệch nhịp)
env_t = np.arange(len(env)) / VSR
env_m = np.interp(tt, env_t, env)
gain = 1 - 0.6 * env_m
gain = np.convolve(gain, np.ones(int(0.05 * SR)) / int(0.05 * SR), mode="same")
mus *= gain

# tiếng hiệu ứng vào sau ducking, nhạc hạ xuống 0 ở khoảng lặng (trả lại đúng lúc cảnh sau vào để tiếng thịch chuyển cảnh nổi bật)
mus += sf * (1 - 0.35 * env_m)
for a, b in SIL:
    mus *= np.interp(tt, [a - 0.15, a + 0.05, b - 0.04, b], [1, 0, 0, 1])

# fade vào 1.5 s, ra 3 s
fi = np.minimum(1, tt / 1.5)
fo = np.minimum(1, np.maximum(0, (TOTAL + 0.5 - tt)) / 3.0)
mus *= fi * fo
writewav(f"{P}/music_48k.wav", mus, SR)
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", f"{P}/music_48k.wav", "-ar", "48000", "-ac", "1", f"{P}/music.wav"], check=True)
print("ok", TOTAL, "voice rms dB", 20 * np.log10(np.sqrt(np.mean(vo ** 2)) + 1e-9), "music rms dB", 20 * np.log10(np.sqrt(np.mean(mus ** 2)) + 1e-9))
