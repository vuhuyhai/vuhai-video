#!/usr/bin/env python3
"""Trộn mix/vo.wav và mix/music.wav thành mix/final.wav: amix, alimiter, loudnorm hai lượt (I=-14, TP=-1.5, linear)."""
import subprocess, json, re, sys
I, TP, LRA = -14.0, -1.5, 11
def run(args): return subprocess.run(["ffmpeg","-y","-hide_banner"] + args, capture_output=True, text=True)
base = "[0:a][1:a]amix=inputs=2:duration=longest:normalize=0,alimiter=limit=0.38:attack=5:release=80"
inp = ["-i","mix/vo.wav","-i","mix/music.wav"]
r = run(inp + ["-filter_complex", base + f",loudnorm=I={I}:TP={TP}:LRA={LRA}:print_format=json", "-f","null","-"])
j = json.loads(re.search(r"\{[^{}]*input_i[^{}]*\}", r.stderr, re.S).group(0))
ln = f"loudnorm=I={I}:TP={TP}:LRA={LRA}:measured_I={j['input_i']}:measured_TP={j['input_tp']}:measured_LRA={j['input_lra']}:measured_thresh={j['input_thresh']}:offset={j['target_offset']}:linear=true"
r2 = run(inp + ["-filter_complex", base + "," + ln, "-ar","48000","-ac","2","mix/final.wav"])
assert r2.returncode == 0, r2.stderr[-500:]
print("final.wav xong, đo lượt một:", j["input_i"], "LUFS")
