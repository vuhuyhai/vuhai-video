# Cảnh có ảnh thật + hiệu ứng (Photo Scenes)

Dùng khi Vũ Hải nói "muốn có hình", "video có ảnh thật", hoặc chủ đề cần minh hoạ bằng ảnh chụp/vệ tinh/bản đồ (theo đúng kiểu video mẫu "50 năm TP.HCM": ảnh thật trong khung bo góc có badge, nền ảnh full khung có overlay tối, zoom Ken Burns nhẹ).

## Luật bắt buộc về nguồn ảnh, không thương lượng

- KHÔNG tự tải ảnh stock/ảnh từ web về gắn vào video mà không hỏi Vũ Hải trước. Ảnh dùng trong video công khai (Facebook) cần anh xác nhận có quyền sử dụng (ảnh anh chụp, ảnh mua license, ảnh báo chí có ghi nguồn và được phép trích dẫn, hoặc ảnh dữ liệu mở như bản đồ GADM).
- Khi Vũ Hải đồng ý dùng ảnh stock có giấy phép miễn phí (Pexels, Pixabay...): kiểm tra kỹ nội dung ảnh trước khi gắn caption cụ thể lên nó. Hai lỗi đã gặp thực tế:
  - Ảnh có chữ/biển hiệu thật của một địa điểm/thương hiệu KHÔNG liên quan (ví dụ ảnh có chữ tên một cửa hàng khác) rồi gắn caption như thể đó là địa điểm đang nói tới, sai sự thật dù ảnh có giấy phép hợp lệ. Luôn xem kỹ ảnh có chữ đọc được hay không trước khi chọn.
  - Ảnh có gương mặt người thật rõ ràng (ảnh mẫu chụp cho stock) rồi gắn caption ngụ ý họ là nhân sự/đại diện của một công ty cụ thể, ngụ ý sai một cách không công bằng cho người trong ảnh. Với các beat cần "người", ưu tiên ảnh không lộ mặt rõ, ảnh chụp từ xa/góc nghiêng, hoặc quay về ảnh minh hoạ trừu tượng tự vẽ.
- Nếu chưa có ảnh thật, dựng bằng ảnh minh hoạ gốc tự tạo (silhouette, gradient, hình khối trừu tượng vẽ bằng code, xem `scripts/` nếu skill có sẵn mẫu) để demo bố cục, rồi nói rõ với Vũ Hải đây là placeholder cần thay trước khi đăng. Ảnh minh hoạ PHẢI đủ sáng và đủ chi tiết để nhận ra ngay là gì, tránh tông quá tối/quá trừu tượng, nếu không người xem sẽ tưởng video lỗi, không có hình.
- Khi dùng ảnh báo chí/nguồn mở: luôn có dòng ghi nguồn nhỏ trong khung (như video mẫu ghi "Ảnh: VnExpress...", "Dữ liệu outline: GADM 4.1").

## Component: PhotoBgScene, ảnh nền full khung

Dùng cho cảnh mở đầu, cảnh chuyển ý lớn, cảnh cần không khí (địa điểm, bối cảnh).

- `<Img src={staticFile(...)}>` phủ full `AbsoluteFill`, `objectFit: cover`.
- Zoom Ken Burns: `interpolate(frame, [0, durationInFrames], [zoomFrom, zoomTo])` áp vào `transform: scale()`. Zoom nhẹ (1.0 → 1.1-1.15), không zoom mạnh gây chóng mặt.
- Lớp phủ tối để chữ đọc rõ: dùng gradient NHẸ, chỉ đậm ở dải có chữ (đáy khung). Ví dụ đã kiểm chứng: `linear-gradient(180deg, rgba(26,26,26,0.05) 0%, rgba(26,26,26,0.15) 55%, rgba(26,26,26,0.75) 100%)`. Lỗi từng gặp: phủ gradient đậm ngay từ đầu khung (opacity 0.15→0.9 tính từ đỉnh) làm ảnh gần như biến mất, người xem tưởng video không có hình. Luôn xem lại 1 khung hình tĩnh sau khi dựng để tự kiểm ảnh có thật sự "nhìn thấy" hay không, đừng chỉ tin vào code đúng cú pháp.
- Chữ headline neo dưới, `spring()` vào chậm hơn ảnh một chút (delay ~6 frame) để có lớp lang.

## Component: PhotoCardScene, ảnh bo góc kèm số liệu

Dùng cho cảnh dẫn chứng cụ thể (một địa điểm, một mốc thời gian, một minh hoạ đi kèm số liệu), bố cục 2 cột: ảnh bên trái, số liệu/text bên phải (hoặc đảo chiều).

- Khung ảnh: `borderRadius: 20`, viền `2px solid accent2`, `overflow: hidden`.
- Badge góc trên trái: nền tối trong suốt, viền accent, chữ hoa nhỏ (kiểu "ĐÃ ĐÓNG CỬA", "ẢNH TRƯỚC/SAU" như video mẫu).
- Caption dưới ảnh: gradient tối từ dưới lên, chữ trắng, 1 dòng ngắn (tên địa điểm/mốc thời gian).
- Zoom Ken Burns nhẹ hơn PhotoBgScene (1.0 → 1.08) vì khung nhỏ hơn, zoom mạnh dễ vỡ bố cục.
- Cột số liệu: số lớn màu accent + nhãn dưới, `spring()` vào trễ hơn khung ảnh ~15 frame.

## Khi nào dùng ảnh, khi nào dùng chữ thuần

- Có địa điểm, con người, hiện vật cụ thể cần hình dung → PhotoBgScene/PhotoCardScene.
- Số liệu trừu tượng, lập luận, câu hỏi phản biện → giữ nguyên các scene chữ thuần trong `Scenes.tsx` gốc (StatementScene, QuestionScene, FourListScene...). Không ép ảnh vào mọi beat, video mẫu cũng xen kẽ bản đồ/ảnh với những khung chỉ có chữ + badge khi nội dung là số liệu hay nhãn.
